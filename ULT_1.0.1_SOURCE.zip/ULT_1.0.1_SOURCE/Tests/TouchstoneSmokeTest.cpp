#include <cstddef>
#include "../Sources/ThirdParty/Touchstone/refcomp/Engine.h"
#include <array>
int main(){ refcomp::Engine<float, refcomp::FastMath> e; e.prepare(48000.0, 16384, 2); refcomp::Parameters p; p.mode=refcomp::Mode::FET; p.ratio=4.0f; p.thresholdDb=-18.0f; p.attackMs=0.02f; p.releaseMs=55.0f; p.driveDb=12.0f; p.makeupDb=-7.0f; p.mix=1.0f; e.setParameters(p); std::array<float,512> l{},r{}; float* c[2]={l.data(),r.data()}; e.process(c,2,512); return 0; }
