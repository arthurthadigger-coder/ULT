#include "../Sources/ThirdParty/Airwindows/AirwindowsAdapters.h"
#include <vector>
#include <cmath>
#include <iostream>
int main() {
  struct Module {const char* name;void* (*create)(double);void (*destroy)(void*);void (*process)(void*,float*,float*,int);} mods[] = {
    {"DeBess",ult_DeBess_create,ult_DeBess_destroy,ult_DeBess_process},
    {"Density3",ult_Density3_create,ult_Density3_destroy,ult_Density3_process},
    {"StereoDoubler",ult_StereoDoubler_create,ult_StereoDoubler_destroy,ult_StereoDoubler_process},
    {"StereoChorus",ult_StereoChorus_create,ult_StereoChorus_destroy,ult_StereoChorus_process},
    {"Verbity",ult_Verbity_create,ult_Verbity_destroy,ult_Verbity_process}
  };
  for(auto& m:mods) {
    auto* engine=m.create(48000);
    if(!engine){std::cerr<<m.name<<" failed create\n";return 1;}
    std::vector<float> l(4096),r(4096);
    for(int i=0;i<4096;++i){l[i]=.05f*std::sin(2*3.141592653589793*440*i/48000.0);r[i]=.05f*std::sin(2*3.141592653589793*330*i/48000.0);}
    for(int n=0;n<8;++n) m.process(engine,l.data()+n*512,r.data()+n*512,512);
    for(int i=0;i<4096;++i)if(!std::isfinite(l[i])||!std::isfinite(r[i])){std::cerr<<m.name<<" nonfinite\n";return 2;}
    m.destroy(engine);
    std::cout<<m.name<<" finite processing OK\n";
  }
}
