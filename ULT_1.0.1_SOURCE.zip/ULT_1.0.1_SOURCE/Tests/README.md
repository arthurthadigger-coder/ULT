# Standalone DSP checks

These small tests can be compiled without the JUCE plugin target to validate isolated DSP logic.

## Reverb stereo test

From the project root with a C++17 compiler:

```bash
g++ -std=c++17 -O2 Tests/ReverbStereoTest.cpp Sources/DSP/UltReverb.cpp -o reverb_stereo_test
./reverb_stereo_test
```

The test feeds a mono impulse into Room, Hall, and Space, then checks that both wet channels contain energy, the side field is non-trivial, the output remains finite, and the peak stays bounded. This is a signal-integrity check, not a substitute for listening in FL Studio.

Other existing tests cover Airwindows adapter smoke checks and Touchstone compressor headers.
