#include "../Sources/DSP/UltReverb.h"
#include <cmath>
#include <cstdio>
#include <algorithm>

int main()
{
    for (const int sr : { 44100, 48000, 96000 })
    {
        for (int mode = 0; mode < 3; ++mode)
        {
            UltReverb reverb;
            reverb.prepare (sr);
            reverb.setParameters (mode, 4200.0f, 65.0f);
            const int count = sr * 3;
            double eL = 0.0, eR = 0.0, eSide = 0.0, eMid = 0.0, cross = 0.0;
            float peak = 0.0f;
            for (int i = 0; i < count; ++i)
            {
                // A mono impulse tests whether the reverb itself creates a stereo field.
                const float in = i == 0 ? 1.0f : 0.0f;
                float l = 0.0f, r = 0.0f;
                reverb.processSample (in, in, l, r);
                eL += l * l; eR += r * r;
                const float mid = 0.5f * (l + r);
                const float side = 0.5f * (l - r);
                eMid += mid * mid; eSide += side * side; cross += l * r;
                peak = std::max (peak, std::max (std::abs (l), std::abs (r)));
            }
            const double corr = cross / std::sqrt (std::max (1.0e-30, eL * eR));
            const double sideRatio = eSide / std::max (1.0e-30, eMid + eSide);
            std::printf ("sr=%d mode=%d energyL=%.6f energyR=%.6f sideRatio=%.4f corr=%.4f peak=%.4f\n",
                         sr, mode, eL, eR, sideRatio, corr, peak);
            if (! std::isfinite (eL) || ! std::isfinite (eR) || ! std::isfinite (peak)) return 2;
            if (eL < 1.0e-7 || eR < 1.0e-7 || sideRatio < 0.05 || peak > 8.0f) return 3;
        }
    }
    return 0;
}
