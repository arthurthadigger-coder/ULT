#pragma once
#include <juce_dsp/juce_dsp.h>
#include <array>

// C++ adaptation of David Braun's xfer_ott processor from Faust compressors.lib.
// The per-band transfer curves, thresholds, attack/release constants and Depth/Time
// laws follow the MIT-declared xfer_ott function. Crossovers use JUCE LR4 filters.
class FaustOtt
{
public:
    struct Parameters
    {
        float depth = 0.0f;       // 0..1
        float time = 1.0f;        // Faust units: 0..10 (100% == 1.0)
        float inputDb = 0.0f;
        float outputDb = 0.0f;
        float upward = 1.0f;      // 0..2
        float downward = 1.0f;    // 0..2
        std::array<float, 3> threshold { 1.0f, 1.0f, 1.0f };
        std::array<float, 3> gainDb { 0.0f, 0.0f, 0.0f };
    };

    void prepare (double sampleRate, int channels);
    void reset();
    void setParameters (const Parameters& p) noexcept { params = p; }
    void process (juce::AudioBuffer<float>& buffer) noexcept;

private:
    static float softplus (float width, float z) noexcept;
    static float interpolateRelease (int band, float percent) noexcept;
    static float makeupShape (int band, float depth) noexcept;
    static float downShape (int band, float depth) noexcept;
    static float downwardStrength (float p) noexcept;
    static float thresholdShift (int band, float p) noexcept;
    float bandGain (int band, float energyDb) const noexcept;

    double sampleRate = 44100.0;
    Parameters params;
    std::array<juce::dsp::LinkwitzRileyFilter<float>, 2> lowSplitLP, lowSplitHP, highSplitLP, highSplitHP;
    std::array<float, 3> envelope {};
};
