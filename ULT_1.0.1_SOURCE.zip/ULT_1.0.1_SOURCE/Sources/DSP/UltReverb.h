#pragma once

#include <array>
#include <vector>

// Original stereo algorithmic reverb for ult.
// A stereo input diffuser feeds an 8-line orthogonal FDN; independent output
// diffusers and asymmetric early reflections create a wide return from mono
// material as well as preserving stereo information from stereo sources.
// All memory is allocated in prepare(); processSample() is allocation-free.
class UltReverb
{
public:
    void prepare (double sampleRate);
    void reset() noexcept;
    void setParameters (int mode, float decayMs, float character) noexcept;
    void processSample (float inputL, float inputR, float& outputL, float& outputR) noexcept;

private:
    static constexpr int lineCount = 8;
    static constexpr int inputDiffuserCount = 3;
    static constexpr int outputDiffuserCount = 2;

    struct DelayLine
    {
        std::vector<float> data;
        int write = 0;
        float dampingState = 0.0f;
        float currentDelay = 0.0f;
        float targetDelay = 0.0f;
        double phase = 0.0;
    };

    struct Diffuser
    {
        std::vector<float> data;
        int write = 0;
        float feedback = 0.68f;

        void prepare (int samples, float coefficient);
        void reset() noexcept;
        float process (float input) noexcept;
    };

    static float readDelay (const std::vector<float>& data, int write, float delaySamples) noexcept;
    static int parity (unsigned int value) noexcept;

    std::array<DelayLine, lineCount> lines;
    std::array<float, lineCount> delayed {};
    std::array<float, lineCount> transformed {};
    std::array<std::array<Diffuser, inputDiffuserCount>, 2> inputDiffusers;
    std::array<std::array<Diffuser, outputDiffuserCount>, 2> outputDiffusers;
    std::vector<float> earlyLeft, earlyRight;
    int earlyWrite = 0;
    double sampleRate = 48000.0;
    float dampingCoefficient = 0.25f;
    float feedbackGain = 0.72f;
    float delaySmoothing = 0.001f;
    float modulationDepthSamples = 0.25f;
    float earlyReflectionGain = 0.40f;
    float tailGain = 0.92f;
    int currentMode = -1;
};
