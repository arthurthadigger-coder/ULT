#include "UltReverb.h"
#include <algorithm>
#include <cmath>

namespace
{
constexpr float pi = 3.14159265358979323846f;
constexpr float invSqrt8 = 0.3535533905932737622f;

float clamp (float value, float lo, float hi) noexcept
{
    return std::max (lo, std::min (hi, value));
}

float onePole (float milliseconds, double sampleRate) noexcept
{
    const double time = std::max (0.01, (double) milliseconds * 0.001);
    return (float) (1.0 - std::exp (-1.0 / (time * sampleRate)));
}
}

void UltReverb::Diffuser::prepare (int samples, float coefficient)
{
    data.assign ((size_t) std::max (1, samples), 0.0f);
    write = 0;
    feedback = clamp (coefficient, 0.0f, 0.85f);
}

void UltReverb::Diffuser::reset() noexcept
{
    std::fill (data.begin(), data.end(), 0.0f);
    write = 0;
}

float UltReverb::Diffuser::process (float input) noexcept
{
    if (data.empty()) return input;
    const float delayedSample = data[(size_t) write];
    const float output = delayedSample - feedback * input;
    data[(size_t) write] = input + feedback * output;
    if (++write >= (int) data.size()) write = 0;
    return output;
}

void UltReverb::prepare (double newSampleRate)
{
    sampleRate = std::max (8000.0, newSampleRate);
    const auto delayCapacity = (size_t) std::ceil (sampleRate * 0.25) + 8;
    const auto earlyCapacity = (size_t) std::ceil (sampleRate * 0.16) + 8;

    for (auto& line : lines)
    {
        line.data.assign (delayCapacity, 0.0f);
        line.write = 0;
        line.dampingState = 0.0f;
        line.phase = 0.0;
    }

    // Unequal left/right diffuser lengths are intentional: a mono source enters
    // two different phase-dispersion paths before reaching the late field.
    static constexpr float inputMs[2][inputDiffuserCount] = {
        { 5.3f, 8.1f, 12.7f },
        { 6.7f, 9.7f, 14.9f }
    };
    static constexpr float outputMs[2][outputDiffuserCount] = {
        { 3.1f, 4.9f },
        { 3.7f, 5.7f }
    };

    for (int ch = 0; ch < 2; ++ch)
    {
        for (int i = 0; i < inputDiffuserCount; ++i)
            inputDiffusers[(size_t) ch][(size_t) i].prepare (
                (int) std::lround (inputMs[ch][i] * 0.001 * sampleRate), 0.70f - 0.025f * i);
        for (int i = 0; i < outputDiffuserCount; ++i)
            outputDiffusers[(size_t) ch][(size_t) i].prepare (
                (int) std::lround (outputMs[ch][i] * 0.001 * sampleRate), 0.66f - 0.035f * i);
    }

    earlyLeft.assign (earlyCapacity, 0.0f);
    earlyRight.assign (earlyCapacity, 0.0f);
    earlyWrite = 0;
    delaySmoothing = onePole (32.0f, sampleRate);
    currentMode = -1;
    setParameters (1, 2400.0f, 62.0f);
    reset();
}

void UltReverb::reset() noexcept
{
    for (auto& line : lines)
    {
        std::fill (line.data.begin(), line.data.end(), 0.0f);
        line.write = 0;
        line.dampingState = 0.0f;
        line.phase = 0.0;
    }
    for (auto& channel : inputDiffusers)
        for (auto& diffuser : channel) diffuser.reset();
    for (auto& channel : outputDiffusers)
        for (auto& diffuser : channel) diffuser.reset();
    std::fill (earlyLeft.begin(), earlyLeft.end(), 0.0f);
    std::fill (earlyRight.begin(), earlyRight.end(), 0.0f);
    earlyWrite = 0;
}

void UltReverb::setParameters (int mode, float decayMs, float character) noexcept
{
    mode = (int) clamp ((float) mode, 0.0f, 2.0f);
    decayMs = clamp (decayMs, 100.0f, 10000.0f);
    character = clamp (character, 0.0f, 100.0f);

    // Room is reflection-forward and compact; Hall balances early and late
    // energy; Space lengthens and modulates the diffuse tail for a lush wash.
    static constexpr float roomMs[lineCount] =
        { 17.9f, 21.7f, 25.3f, 29.9f, 33.7f, 38.9f, 43.1f, 47.3f };
    static constexpr float hallMs[lineCount] =
        { 31.1f, 37.3f, 41.9f, 47.9f, 53.3f, 59.9f, 67.1f, 73.7f };
    static constexpr float spaceMs[lineCount] =
        { 43.7f, 51.1f, 59.3f, 67.9f, 77.3f, 89.9f, 101.3f, 113.9f };
    const auto* delays = mode == 0 ? roomMs : (mode == 1 ? hallMs : spaceMs);

    for (int i = 0; i < lineCount; ++i)
    {
        auto& line = lines[(size_t) i];
        const float target = delays[i] * 0.001f * (float) sampleRate;
        if (currentMode < 0)
            line.currentDelay = target;
        line.targetDelay = target;
    }

    const float averageDelaySeconds = mode == 0 ? 0.034f : (mode == 1 ? 0.052f : 0.078f);
    const float decaySeconds = decayMs * 0.001f;
    feedbackGain = clamp (std::pow (0.001f, averageDelaySeconds / decaySeconds), 0.0f, 0.994f);

    const float dampingHz = 1700.0f + (character / 100.0f) * 16800.0f;
    dampingCoefficient = 1.0f - std::exp (-2.0f * pi * dampingHz / (float) sampleRate);
    modulationDepthSamples = (mode == 0 ? 0.06f : (mode == 1 ? 0.28f : 0.82f))
                           * 0.001f * (float) sampleRate;
    earlyReflectionGain = mode == 0 ? 0.78f : (mode == 1 ? 0.54f : 0.34f);
    tailGain = mode == 0 ? 0.72f : (mode == 1 ? 0.96f : 1.12f);
    currentMode = mode;
}

float UltReverb::readDelay (const std::vector<float>& data, int write, float delaySamples) noexcept
{
    if (data.empty()) return 0.0f;
    const int size = (int) data.size();
    float position = (float) write - std::max (1.0f, delaySamples);
    while (position < 0.0f) position += (float) size;
    while (position >= (float) size) position -= (float) size;
    const int index0 = (int) position;
    const int index1 = index0 + 1 == size ? 0 : index0 + 1;
    const float fraction = position - (float) index0;
    return data[(size_t) index0] + (data[(size_t) index1] - data[(size_t) index0]) * fraction;
}

int UltReverb::parity (unsigned int value) noexcept
{
    value ^= value >> 16;
    value ^= value >> 8;
    value ^= value >> 4;
    value &= 0x0fu;
    return (0x6996u >> value) & 1u;
}

void UltReverb::processSample (float inputL, float inputR, float& outputL, float& outputR) noexcept
{
    if (earlyLeft.empty() || lines[0].data.empty())
    {
        outputL = outputR = 0.0f;
        return;
    }

    float diffusedL = inputL;
    float diffusedR = inputR;
    for (int i = 0; i < inputDiffuserCount; ++i)
    {
        diffusedL = inputDiffusers[0][(size_t) i].process (diffusedL);
        diffusedR = inputDiffusers[1][(size_t) i].process (diffusedR);
    }

    earlyLeft[(size_t) earlyWrite] = inputL;
    earlyRight[(size_t) earlyWrite] = inputR;

    const float sr = (float) sampleRate;
    const float roomScale = currentMode == 0 ? 0.78f : (currentMode == 1 ? 1.0f : 1.24f);
    const float erL =
        0.31f * readDelay (earlyLeft, earlyWrite,  7.9f * roomScale * 0.001f * sr) +
        0.24f * readDelay (earlyRight, earlyWrite, 13.7f * roomScale * 0.001f * sr) +
        0.19f * readDelay (earlyLeft, earlyWrite, 22.3f * roomScale * 0.001f * sr) +
        0.15f * readDelay (earlyRight, earlyWrite, 31.9f * roomScale * 0.001f * sr) +
        0.11f * readDelay (earlyLeft, earlyWrite, 47.3f * roomScale * 0.001f * sr);
    const float erR =
        0.31f * readDelay (earlyRight, earlyWrite,  9.7f * roomScale * 0.001f * sr) +
        0.24f * readDelay (earlyLeft, earlyWrite, 15.9f * roomScale * 0.001f * sr) +
        0.19f * readDelay (earlyRight, earlyWrite, 27.1f * roomScale * 0.001f * sr) +
        0.15f * readDelay (earlyLeft, earlyWrite, 39.7f * roomScale * 0.001f * sr) +
        0.11f * readDelay (earlyRight, earlyWrite, 53.9f * roomScale * 0.001f * sr);

    for (int i = 0; i < lineCount; ++i)
    {
        auto& line = lines[(size_t) i];
        line.currentDelay += delaySmoothing * (line.targetDelay - line.currentDelay);
        const float modulation = std::sin ((float) line.phase) * modulationDepthSamples;
        const float raw = readDelay (line.data, line.write, line.currentDelay + modulation);
        line.dampingState += dampingCoefficient * (raw - line.dampingState);
        delayed[(size_t) i] = line.dampingState;
        line.phase += (2.0 * 3.14159265358979323846 * (0.071 + 0.013 * i)) / sampleRate;
        if (line.phase >= 2.0 * 3.14159265358979323846)
            line.phase -= 2.0 * 3.14159265358979323846;
    }

    // Orthogonal 8x8 Hadamard feedback matrix keeps the loop diffuse and
    // energy-stable. Independent stereo injection vectors preserve width even
    // when inputL and inputR carry the same mono signal.
    for (int i = 0; i < lineCount; ++i)
    {
        float mixed = 0.0f;
        for (int j = 0; j < lineCount; ++j)
            mixed += (parity ((unsigned int) (i & j)) == 0 ? 1.0f : -1.0f) * delayed[(size_t) j];
        transformed[(size_t) i] = mixed * invSqrt8;
    }

    static constexpr float injectL[lineCount] = { 1.0f, 1.0f, -1.0f, 1.0f, -1.0f, -1.0f, 1.0f, -1.0f };
    static constexpr float injectR[lineCount] = { 1.0f, -1.0f, 1.0f, -1.0f, -1.0f, 1.0f, 1.0f, -1.0f };
    for (int i = 0; i < lineCount; ++i)
    {
        auto& line = lines[(size_t) i];
        const float excitation = 0.155f * (diffusedL * injectL[i] + diffusedR * injectR[i]);
        const float writeValue = excitation + feedbackGain * transformed[(size_t) i];
        line.data[(size_t) line.write] = clamp (writeValue, -8.0f, 8.0f);
        if (++line.write >= (int) line.data.size()) line.write = 0;
    }

    static constexpr float decodeL[lineCount] = { 1.0f, 1.0f, 1.0f, 1.0f, -1.0f, -1.0f, -1.0f, -1.0f };
    static constexpr float decodeR[lineCount] = { 1.0f, -1.0f, 1.0f, -1.0f, 1.0f, -1.0f, 1.0f, -1.0f };
    float tailL = 0.0f, tailR = 0.0f;
    for (int i = 0; i < lineCount; ++i)
    {
        tailL += delayed[(size_t) i] * decodeL[i];
        tailR += delayed[(size_t) i] * decodeR[i];
    }
    tailL *= invSqrt8;
    tailR *= invSqrt8;

    for (int i = 0; i < outputDiffuserCount; ++i)
    {
        tailL = outputDiffusers[0][(size_t) i].process (tailL);
        tailR = outputDiffusers[1][(size_t) i].process (tailR);
    }

    outputL = erL * earlyReflectionGain + tailL * tailGain;
    outputR = erR * earlyReflectionGain + tailR * tailGain;

    if (++earlyWrite >= (int) earlyLeft.size()) earlyWrite = 0;
}
