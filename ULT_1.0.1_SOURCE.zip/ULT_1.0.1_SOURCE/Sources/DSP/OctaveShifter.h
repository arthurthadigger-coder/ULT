#pragma once
#include <juce_audio_basics/juce_audio_basics.h>
#include "../ThirdParty/SnapTune/AutoTuneEngine.h"

// Octave Shifter uses two instances of the integrated SnapTune pitch engine.
// The small upstream extension `transposeSemitones` provides a fixed transposition
// while retaining the original Live delay-line and Studio TD-PSOLA paths.
class OctaveShifter
{
public:
    void prepare (double sampleRate, int maxChannels, int maxBlockSize);
    void reset();
    int getLatencySamples() const noexcept { return downEngine.getLatencySamples(); }
    void process (juce::AudioBuffer<float>& buffer, float originalPct, float downPct, float upPct,
                  bool qualityMode, bool femaleVoice) noexcept;

private:
    snaptune::AutoTuneEngine downEngine, upEngine;
    juce::AudioBuffer<float> downBuffer, upBuffer;
    double sr = 44100.0;
    int channels = 2;
};
