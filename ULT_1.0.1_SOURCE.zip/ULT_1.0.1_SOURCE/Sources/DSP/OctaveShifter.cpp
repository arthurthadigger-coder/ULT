#include "OctaveShifter.h"
#include <algorithm>

void OctaveShifter::prepare (double sampleRate, int maxChannels, int maxBlockSize)
{
    sr = juce::jmax (8000.0, sampleRate);
    channels = juce::jlimit (1, 2, maxChannels);
    downBuffer.setSize (2, maxBlockSize, false, true, false);
    upBuffer.setSize (2, maxBlockSize, false, true, false);
    downEngine.prepare (sr, channels);
    upEngine.prepare (sr, channels);
}

void OctaveShifter::reset()
{
    downEngine.reset();
    upEngine.reset();
    downBuffer.clear();
    upBuffer.clear();
}

void OctaveShifter::process (juce::AudioBuffer<float>& buffer, float originalPct, float downPct, float upPct,
                             bool qualityMode, bool femaleVoice) noexcept
{
    const int nc = juce::jmin (channels, buffer.getNumChannels());
    const int ns = buffer.getNumSamples();
    if (nc <= 0 || ns <= 0 || ns > downBuffer.getNumSamples()) return;

    downBuffer.clear (0, 0, ns); downBuffer.clear (1, 0, ns);
    upBuffer.clear (0, 0, ns); upBuffer.clear (1, 0, ns);
    for (int ch = 0; ch < nc; ++ch)
    {
        downBuffer.copyFrom (ch, 0, buffer, ch, 0, ns);
        upBuffer.copyFrom (ch, 0, buffer, ch, 0, ns);
    }
    if (nc == 1)
    {
        downBuffer.copyFrom (1, 0, downBuffer, 0, 0, ns);
        upBuffer.copyFrom (1, 0, upBuffer, 0, 0, ns);
    }

    snaptune::EngineSettings downSettings;
    downSettings.key = 0;
    downSettings.scale = snaptune::Scale::chromatic;
    downSettings.retuneMs = 0.0f;
    downSettings.transitionMs = 0.0f;
    downSettings.humanize = 0.0f;
    downSettings.amount = 0.0f; // no note correction; only the fixed octave transpose is active
    downSettings.transposeSemitones = -12.0f;
    downSettings.formantSemitones = qualityMode ? -12.0f : 0.0f;
    downSettings.mix = 1.0f;
    downSettings.tracking = 0.35f;
    downSettings.voice = femaleVoice ? snaptune::VoiceType::soprano : snaptune::VoiceType::altoTenor;
    downSettings.mode = qualityMode ? snaptune::LatencyMode::studio : snaptune::LatencyMode::live;
    downSettings.referenceHz = 440.0f;

    auto upSettings = downSettings;
    upSettings.transposeSemitones = 12.0f;
    upSettings.formantSemitones = qualityMode ? 12.0f : 0.0f;
    downEngine.setSettings (downSettings);
    upEngine.setSettings (upSettings);
    downEngine.process (downBuffer.getArrayOfWritePointers(), nc, 0, ns, false);
    upEngine.process (upBuffer.getArrayOfWritePointers(), nc, 0, ns, false);

    const float dry = juce::jlimit (0.0f, 1.0f, originalPct * 0.01f);
    const float lo = juce::jlimit (0.0f, 1.0f, downPct * 0.01f);
    const float hi = juce::jlimit (0.0f, 1.0f, upPct * 0.01f);
    for (int ch = 0; ch < nc; ++ch)
    {
        auto* out = buffer.getWritePointer (ch);
        const auto* down = downBuffer.getReadPointer (ch);
        const auto* up = upBuffer.getReadPointer (ch);
        for (int i = 0; i < ns; ++i)
            out[i] = out[i] * dry + down[i] * lo + up[i] * hi;
    }
}
