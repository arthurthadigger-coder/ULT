#include "FaustOtt.h"
#include <algorithm>
#include <cmath>

namespace
{
constexpr float kAttack[3] = { 0.00621537f, 0.006f, 0.0096577f };
constexpr float kTu[3] = { -46.0171f, -46.5885f, -47.4393f };
constexpr float kWu[3] = { 0.0552f, 0.4509f, 0.0338f };
constexpr float kSu[3] = { 0.74786f, 0.75601f, 0.74738f };
constexpr float kTd[3] = { -38.9401f, -34.8204f, -41.6879f };
constexpr float kWd[3] = { 0.5f, 0.530023f, 0.5f };
constexpr float kMk[3] = { 14.0348f, 9.05203f, 14.064f };
constexpr float kCu[3] = { 35.901f, 36.285f, 35.872f };
constexpr float kMin[3] = { -26.26f, -31.70f, -25.95f };
constexpr float kTShift[3] = { 23.009f, 23.743f, 24.021f };
inline float dbToGain (float db) noexcept { return std::pow (10.0f, db / 20.0f); }
}

void FaustOtt::prepare (double sr, int channels)
{
    sampleRate = juce::jmax (8000.0, sr);
    const int numChannels = juce::jlimit (1, 2, channels);
    juce::dsp::ProcessSpec spec { sampleRate, 512u, (juce::uint32) numChannels };
    for (int ch = 0; ch < 2; ++ch)
    {
        lowSplitLP[(size_t) ch].prepare (spec); lowSplitLP[(size_t) ch].setType (juce::dsp::LinkwitzRileyFilter<float>::Type::lowpass); lowSplitLP[(size_t) ch].setCutoffFrequency (88.3f);
        lowSplitHP[(size_t) ch].prepare (spec); lowSplitHP[(size_t) ch].setType (juce::dsp::LinkwitzRileyFilter<float>::Type::highpass); lowSplitHP[(size_t) ch].setCutoffFrequency (88.3f);
        highSplitLP[(size_t) ch].prepare (spec); highSplitLP[(size_t) ch].setType (juce::dsp::LinkwitzRileyFilter<float>::Type::lowpass); highSplitLP[(size_t) ch].setCutoffFrequency (2500.0f);
        highSplitHP[(size_t) ch].prepare (spec); highSplitHP[(size_t) ch].setType (juce::dsp::LinkwitzRileyFilter<float>::Type::highpass); highSplitHP[(size_t) ch].setCutoffFrequency (2500.0f);
    }
    juce::ignoreUnused (numChannels);
    reset();
}

void FaustOtt::reset()
{
    envelope.fill (0.0f);
    for (auto& f : lowSplitLP) f.reset();
    for (auto& f : lowSplitHP) f.reset();
    for (auto& f : highSplitLP) f.reset();
    for (auto& f : highSplitHP) f.reset();
}

float FaustOtt::softplus (float width, float z) noexcept
{
    const float a = std::abs (z);
    return std::max (z, 0.0f) + width * std::log (1.0f + std::exp (-a / width));
}

float FaustOtt::interpolateRelease (int band, float pct) noexcept
{
    pct = juce::jlimit (0.0f, 100.0f, pct);
    if (band == 0)
    {
        if (pct <= 50.0f) return juce::jmap (pct, 0.0f, 50.0f, 0.0100376f, 0.0148167f);
        return juce::jmap (pct, 50.0f, 100.0f, 0.0148167f, 0.030877f);
    }
    if (band == 1)
    {
        if (pct <= 50.0f) return juce::jmap (pct, 0.0f, 50.0f, 0.0118089f, 0.0174314f);
        return juce::jmap (pct, 50.0f, 100.0f, 0.0174314f, 0.030877f);
    }
    if (pct <= 50.0f) return 0.00702632f;
    return juce::jmap (pct, 50.0f, 100.0f, 0.00702632f, 0.0103717f);
}

float FaustOtt::makeupShape (int band, float d) noexcept
{
    if (band == 0) return d * (1.83819f + d * (-1.21424f + d * 0.37606f));
    if (band == 1) return d * (1.63851f + d * (-0.83224f + d * 0.19373f));
    return d * (1.84440f + d * (-1.22723f + d * 0.38284f));
}
float FaustOtt::downShape (int band, float d) noexcept
{
    if (band == 0) return d * (0.96509f + d * (0.03154f + d * 0.00337f));
    if (band == 1) return d * (0.96161f + d * (0.02205f + d * 0.01634f));
    return d * (0.97286f + d * (0.05778f + d * -0.03064f));
}
float FaustOtt::downwardStrength (float p) noexcept
{
    static constexpr float x[] = { 0.0f, 0.2f, 0.4f, 0.6f, 0.8f, 1.0f, 2.0f };
    static constexpr float y[] = { 0.0f, 0.189716f, 0.389364f, 0.590038f, 0.793116f, 1.0f, 2.0f };
    p = juce::jlimit (0.0f, 2.0f, p);
    for (int i = 0; i < 6; ++i) if (p <= x[i + 1]) return juce::jmap (p, x[i], x[i + 1], y[i], y[i + 1]);
    return p;
}
float FaustOtt::thresholdShift (int band, float p) noexcept { return (p - 1.0f) * kTShift[band]; }

float FaustOtt::bandGain (int band, float eDb) const noexcept
{
    const float depth = juce::jlimit (0.0f, 1.0f, params.depth);
    const float ups = depth * juce::jlimit (0.0f, 2.0f, params.upward);
    const float dns = std::min (1.0f, downShape (band, depth) * downwardStrength (params.downward));
    const float threshold = juce::jlimit (0.0f, 2.0f, params.threshold[(size_t) band]);
    const float shift = thresholdShift (band, threshold);
    const float mk = makeupShape (band, depth) * kMk[band];
    const float up = std::min (kCu[band], ups * kSu[band] * softplus (kWu[band], kTu[band] + shift - eDb));
    const float down = dns * softplus (kWd[band], eDb - kTd[band] - shift);
    const float gainDb = std::max (kMin[band], mk + up - down) + params.gainDb[(size_t) band];
    return dbToGain (gainDb);
}

void FaustOtt::process (juce::AudioBuffer<float>& buffer) noexcept
{
    const int channels = juce::jmin (2, buffer.getNumChannels());
    const int samples = buffer.getNumSamples();
    if (channels == 0 || samples == 0) return;
    const float inGain = dbToGain (params.inputDb);
    const float outGain = dbToGain (params.outputDb);
    const float timePct = 100.0f * std::max (0.0f, params.time);
    const float pct = std::min (100.0f, timePct);
    std::array<float, 3> attackCoeffs {}, releaseCoeffs {};
    for (int b = 0; b < 3; ++b)
    {
        const float relTau = interpolateRelease (b, pct) * std::max (1.0f, timePct / 100.0f);
        attackCoeffs[(size_t) b] = 1.0f - std::exp (-1.0f / (kAttack[b] * (float) sampleRate));
        releaseCoeffs[(size_t) b] = 1.0f - std::exp (-1.0f / (std::max (1.0e-5f, relTau) * (float) sampleRate));
    }

    for (int i = 0; i < samples; ++i)
    {
        std::array<float, 3> bandL {}, bandR {};
        float energy[3] {};
        for (int ch = 0; ch < channels; ++ch)
        {
            const float x = buffer.getSample (ch, i) * inGain;
            const float low = lowSplitLP[(size_t) ch].processSample (ch, x);
            const float rest = lowSplitHP[(size_t) ch].processSample (ch, x);
            const float mid = highSplitLP[(size_t) ch].processSample (ch, rest);
            const float high = highSplitHP[(size_t) ch].processSample (ch, rest);
            if (ch == 0) { bandL = { low, mid, high }; }
            else { bandR = { low, mid, high }; }
        }
        for (int b = 0; b < 3; ++b)
        {
            const float l = bandL[(size_t) b];
            const float r = channels > 1 ? bandR[(size_t) b] : l;
            const float x2 = 0.5f * (l * l + r * r);
            const float c = x2 > envelope[(size_t) b] ? attackCoeffs[(size_t) b] : releaseCoeffs[(size_t) b];
            envelope[(size_t) b] += c * (x2 - envelope[(size_t) b]);
            if (envelope[(size_t) b] < 1.0e-30f) envelope[(size_t) b] = 0.0f;
            energy[b] = 10.0f * std::log10 (std::max (envelope[(size_t) b], 1.0e-20f));
        }
        const float gl = bandGain (0, energy[0]);
        const float gm = bandGain (1, energy[1]);
        const float gh = bandGain (2, energy[2]);
        buffer.setSample (0, i, outGain * (bandL[0] * gl + bandL[1] * gm + bandL[2] * gh));
        if (channels > 1)
            buffer.setSample (1, i, outGain * (bandR[0] * gl + bandR[1] * gm + bandR[2] * gh));
    }
}
