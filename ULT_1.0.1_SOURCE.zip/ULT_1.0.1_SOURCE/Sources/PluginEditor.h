#pragma once
#include "PluginProcessor.h"
#include <memory>

class UltLookAndFeel final : public juce::LookAndFeel_V4
{
public:
    UltLookAndFeel();
    juce::Font getTextButtonFont (juce::TextButton&, int buttonHeight) override;
    juce::Font getLabelFont (juce::Label&) override;
    juce::Slider::SliderLayout getSliderLayout (juce::Slider&) override;
    juce::Font getComboBoxFont (juce::ComboBox&) override;
    juce::Font getPopupMenuFont() override;
    void drawPopupMenuBackground (juce::Graphics&, int, int) override;
    void drawPopupMenuItem (juce::Graphics&, const juce::Rectangle<int>&, bool, bool, bool, bool, bool,
                            const juce::String&, const juce::String&, const juce::Drawable*, const juce::Colour*) override;
    float popupScale = 1.0f;
    float popupFontMultiplier = 1.0f;
    juce::Typeface::Ptr getTypefaceForFont (const juce::Font&) override;
    void drawRotarySlider (juce::Graphics&, int x, int y, int width, int height,
                           float sliderPosProportional, float rotaryStartAngle,
                           float rotaryEndAngle, juce::Slider&) override;
    void drawButtonBackground (juce::Graphics&, juce::Button&, const juce::Colour&,
                               bool shouldDrawButtonAsHighlighted, bool shouldDrawButtonAsDown) override;
    void drawButtonText (juce::Graphics&, juce::TextButton&, bool isHighlighted, bool isDown) override;
    void drawComboBox (juce::Graphics&, int width, int height, bool isButtonDown,
                       int buttonX, int buttonY, int buttonW, int buttonH,
                       juce::ComboBox&) override;
    void drawToggleButton (juce::Graphics&, juce::ToggleButton&, bool isHighlighted, bool isDown) override;
};

class UltAudioProcessorEditor final : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit UltAudioProcessorEditor (UltAudioProcessor&);
    ~UltAudioProcessorEditor() override;
    void paint (juce::Graphics&) override;
    void resized() override;
    void mouseDown (const juce::MouseEvent&) override;
    bool keyPressed (const juce::KeyPress&) override;
    void parentHierarchyChanged() override;
    void visibilityChanged() override;

private:
    struct Control
    {
        std::unique_ptr<juce::Slider> slider;
        std::unique_ptr<juce::Label> value;
        std::unique_ptr<juce::ComboBox> combo;
        std::unique_ptr<juce::Label> label;
        std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> sliderAttachment;
        std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> comboAttachment;
    };

    class AddEffectOverlay;
    class LayoutEditOverlay;
    class MeterView final : public juce::Component
    {
    public:
        explicit MeterView (UltAudioProcessor& p) : processor (p) {}
        void paint (juce::Graphics&) override;
        void refresh();
    private:
        UltAudioProcessor& processor;
        float inputHoldDb = -90.0f, outputHoldDb = -90.0f;
        double inputClipUntil = 0.0, outputClipUntil = 0.0;
    };

    class ChainView final : public juce::Component
    {
    public:
        explicit ChainView (UltAudioProcessorEditor& owner);
        void paint (juce::Graphics&) override;
        void mouseDown (const juce::MouseEvent&) override;
        void mouseDrag (const juce::MouseEvent&) override;
        void mouseUp (const juce::MouseEvent&) override;
        bool keyPressed (const juce::KeyPress&) override;
        void syncFromProcessor (bool forceRefresh = false);
        void animate();
        std::function<void (int)> onSelect;
        std::function<void (int)> onAddAt;
    private:
        UltAudioProcessorEditor& editor;
        std::vector<int> visualOrder;
        int draggedIndex = -1;
        int keyboardSelectedIndex = -1;
        bool dragChanged = false;
        uint32_t lastChainRevision = 0;
        std::array<float, UltAudioProcessor::NumEffects> animatedX {};
        std::array<bool, UltAudioProcessor::NumEffects> animatedPositionInitialised {};
        float targetCardX (int visualIndex) const;
        juce::Rectangle<int> cardBounds (int visualIndex) const;
        juce::Rectangle<int> plusBounds (int gapIndex) const;
        int indexAt (juce::Point<int> point) const;
    };

    class EqGraph final : public juce::Component
    {
    public:
        explicit EqGraph (UltAudioProcessor& p) : processor (p) {}
        void paint (juce::Graphics&) override;
        void mouseDown (const juce::MouseEvent&) override;
        void mouseDrag (const juce::MouseEvent&) override;
        void mouseUp (const juce::MouseEvent&) override;
        void mouseWheelMove (const juce::MouseEvent&, const juce::MouseWheelDetails&) override;
        int selectedBand = 0;
        std::function<void (int)> onBandSelected;
        void updateSpectrum();
    private:
        UltAudioProcessor& processor;
        juce::dsp::FFT spectrumFft { 13 };
        std::array<float, UltAudioProcessor::eqSpectrumSize * 2> spectrumWork {};
        std::array<float, UltAudioProcessor::eqSpectrumSize / 2> spectrumSmoothed {};
        uint64_t spectrumLastCount = 0;
        bool draggingNode = false;
        float xForHz (float hz) const;
        float yForGain (float gain) const;
        float nodeYForBand (int band) const;
        float responseAt (float hz) const;
        void change (const juce::MouseEvent&);
    };

    // v0.9.13: five-second, stage-aware IN/OUT history and live meters.
    // UI-only history: audio thread only publishes atomic peaks.
    class StageHistoryGraph final : public juce::Component
    {
    public:
        explicit StageHistoryGraph (UltAudioProcessor& p) : processor (p) {}
        void setEffect (int effect) { if (effectId == effect) return; effectId = effect; writeIndex = 0; count = 0; repaint(); }
        void tick();
        void paint (juce::Graphics&) override;
        void mouseDown (const juce::MouseEvent&) override;
        void mouseDrag (const juce::MouseEvent&) override;
    private:
        UltAudioProcessor& processor;
        int effectId = -1, writeIndex = 0, count = 0;
        static constexpr int historySize = 1024;
        std::array<double, historySize> historyTime {};
        std::array<float, historySize> inputHistory {}, outputHistory {};
        juce::dsp::FFT deFft { 13 };
        std::array<float, UltAudioProcessor::eqSpectrumSize * 2> deWork {};
        std::array<float, UltAudioProcessor::eqSpectrumSize / 2> deInputSpectrum {}, deOutputSpectrum {};
        uint64_t deLastInput = 0, deLastOutput = 0;
        void updateDeSpectrum();
        void dragDeFrequency (const juce::MouseEvent&);

        void dragThreshold (const juce::MouseEvent&);
    };

    class PitchDisplay final : public juce::Component
    {
    public:
        explicit PitchDisplay (UltAudioProcessor& p) : processor (p) {}
        void tick();
        void paint (juce::Graphics&) override;
    private:
        UltAudioProcessor& processor;
        uint64_t lastCount = 0;
        float smoothedMidi = -1.0f;
        bool hasPitch = false;
    };

    UltAudioProcessor& processor;
    UltLookAndFeel look;
    UltLookAndFeel presetLook;
    ChainView chainView;
    EqGraph eqGraph;
    StageHistoryGraph stageHistory;
    PitchDisplay pitchDisplay;
    MeterView meter;
    juce::TextButton brand, signature;
    juce::Label panelTitle;
    juce::Slider inputGain, outputGain;
    juce::Label inputGainLabel, outputGainLabel, inputGainValue, outputGainValue;
    void configureValue (juce::Slider&, juce::Label&, const juce::String&, bool editable);
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> inputGainAttachment, outputGainAttachment;
    juce::TextButton savePreset { "SAVE PRESET" };
    struct LayoutToolbarButton : juce::TextButton
    {
        using juce::TextButton::TextButton;
        bool altGesture = false;
        void mouseDown (const juce::MouseEvent& e) override
        { altGesture = e.mods.isAltDown(); if (! altGesture) juce::TextButton::mouseDown (e); }
        void mouseDrag (const juce::MouseEvent& e) override
        { if (! altGesture) juce::TextButton::mouseDrag (e); }
        void mouseUp (const juce::MouseEvent& e) override
        { if (! altGesture) juce::TextButton::mouseUp (e); altGesture = false; }
    };
    LayoutToolbarButton editLayoutButton { "EDIT LAYOUT" };
    LayoutToolbarButton saveLayoutButton { "SAVE LAYOUT" };
    LayoutToolbarButton resetLayoutButton { "RESET LAYOUT" };
    LayoutToolbarButton layoutMenuButton { "LAYOUT FILE..." };
    LayoutToolbarButton accentButton { "ACCENT COLOR" };
    juce::Colour selectedAccent { 0xffa6ff00 };
    void setAccentColour (juce::Colour colour);
    std::unique_ptr<LayoutEditOverlay> layoutEditOverlay;
    bool windowPersistenceReady = false;
    int lastWindowWidth = 0, lastWindowHeight = 0;
    bool layoutEditMode = false;
    bool editShortcutDown = false;
    bool layoutRebuilding = false;
    bool layoutForceReload = false;
    std::unique_ptr<juce::XmlElement> layoutDraft;
    juce::Time observedLayoutModification;
    juce::int64 observedLayoutSize = -1;
    bool layoutFileWasPresent = false;
    bool layoutSyncInitialized = false;
    void observeCurrentLayoutFile();
    void synchronizeSharedLayout();
    juce::TextButton presetSelector { "PRESETS" };
    juce::ToggleButton delayPower { "DELAY" }, reverbPower { "REVERB" };
    std::vector<std::unique_ptr<Control>> dynamicControls;
    std::vector<std::unique_ptr<Control>> delayControls, reverbControls;
    juce::ComboBox eqBandSelector;
    juce::Label eqBandLabel;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> delayPowerAttachment, reverbPowerAttachment;
    std::unique_ptr<juce::FileChooser> chooser;
    std::unique_ptr<AddEffectOverlay> addEffectOverlay;
    std::vector<juce::File> presetFiles;
    juce::Rectangle<int> chainArea, panelArea, sendsArea;
    juce::String currentPresetName { "Init" };
    juce::String presetStateSnapshot;
    int selectedEffect = -1;
    int selectedEqBand = 0;

    juce::String makePresetFingerprint() const;
    void setCurrentPresetName (const juce::String& name);
    void updatePresetDisplay();
    void showAddEffectWindow (int position);
    void selectEffect (int id);
    void rebuildParameterControls();
    void addFloatControl (std::vector<std::unique_ptr<Control>>& destination, const juce::String& id,
                          const juce::String& label, float min, float max, float step = 0.0f);
    void addChoiceControl (std::vector<std::unique_ptr<Control>>& destination, const juce::String& id,
                           const juce::String& label, const juce::StringArray& options);
    void addChoiceKnobControl (std::vector<std::unique_ptr<Control>>& destination, const juce::String& id,
                               const juce::String& label, const juce::StringArray& options);
    void buildSendControls();
    juce::File getPresetFolder() const;
    void refreshPresetList();
    void showPresetMenu();
    void savePresetFile();
    void loadPresetFile (const juce::File& file);
    void loadFactoryPreset (int presetIndex);
    void timerCallback() override;
    juce::File getLayoutFile() const;
    void applySavedLayout();
    void applyLayoutGeometry (const juce::XmlElement&);
    void captureLayoutDraft();
    void assignLayoutIds();
    bool validLayout (const juce::XmlElement&) const;
    std::unique_ptr<juce::XmlElement> captureLayout (const juce::XmlElement* previous = nullptr) const;
    void saveCurrentLayout();
    void showLayoutMenu();

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (UltAudioProcessorEditor)
};
