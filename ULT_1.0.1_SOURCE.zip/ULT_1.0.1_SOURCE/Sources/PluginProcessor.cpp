#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "ThirdParty/Airwindows/AirwindowsAdapters.h"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <numeric>

namespace
{
using APVTS = juce::AudioProcessorValueTreeState;
void addFloat (APVTS::ParameterLayout& layout, const juce::String& id, const juce::String& name,
               float lo, float hi, float def, float step = 0.0f)
{
    const juce::NormalisableRange<float> range (lo, hi, step);

    if (id.startsWith ("eqFreq"))
    {
        const auto attributes = juce::AudioParameterFloatAttributes()
            .withStringFromValueFunction ([] (float value, int)
            {
                return juce::String (value, 2);
            })
            .withValueFromStringFunction ([] (const juce::String& value)
            {
                return value.getFloatValue();
            });

        layout.add (std::make_unique<juce::AudioParameterFloat> (
            juce::ParameterID { id, 1 }, name, range, def, attributes));
        return;
    }

    layout.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { id, 1 }, name, range, def));
}
void addBool (APVTS::ParameterLayout& layout, const juce::String& id, bool def = false)
{
    layout.add (std::make_unique<juce::AudioParameterBool> (juce::ParameterID { id, 1 }, id, def));
}
void addChoice (APVTS::ParameterLayout& layout, const juce::String& id, const juce::StringArray& options, int def)
{
    layout.add (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { id, 1 }, id, options, def));
}
float dbToGain (float db) noexcept { return juce::Decibels::decibelsToGain (db); }
float clamp01 (float x) noexcept { return juce::jlimit (0.0f, 1.0f, x); }
float onePoleCoeff (float ms, double sr) noexcept
{
    return 1.0f - std::exp (-1.0f / (juce::jmax (0.01f, ms) * 0.001f * (float) sr));
}
void copyToStereoScratch (juce::AudioBuffer<float>& dst, const juce::AudioBuffer<float>& src, int samples)
{
    dst.clear (0, 0, samples); dst.clear (1, 0, samples);
    const int channels = juce::jmin (2, src.getNumChannels());
    for (int ch = 0; ch < channels; ++ch) dst.copyFrom (ch, 0, src, ch, 0, samples);
    if (channels == 1) dst.copyFrom (1, 0, src, 0, 0, samples);
}
}

const char* UltAudioProcessor::effectName (int id) noexcept
{
    static constexpr const char* names[NumEffects] = {
        "Gate / Expander", "Autotune", "Octave Shifter", "EQ", "Removed Effect",
        "1176 Compressor", "De-Esser", "Saturator", "OTT", "Modulation"
    };
    return id >= 0 && id < NumEffects ? names[id] : "Unknown";
}

APVTS::ParameterLayout UltAudioProcessor::createLayout()
{
    APVTS::ParameterLayout l;
    addFloat (l, "inputGain", "Input Gain", -24.0f, 24.0f, 0.0f, 0.1f);
    addFloat (l, "outputGain", "Output Gain", -24.0f, 24.0f, 0.0f, 0.1f);

    // A new instance starts with an empty chain. Insert parameters remain off until the user adds a module; addEffectAt enables it.
    for (auto* id : { "gateOn", "autotuneOn", "octaveOn", "eqOn", "compOn", "deOn", "satOn", "ottOn", "modOn", "delayOn", "reverbOn" })
        addBool (l, id, false);
    // Hidden v0.3 compatibility parameters, used only when migrating older DAW projects.
    addBool (l, "doublerOn", false);
    addFloat (l, "doubleMix", "Legacy Doubler Send", 0.0f, 100.0f, 20.0f, 1.0f);

    addFloat (l, "gateThreshold", "Gate Threshold", -70.0f, -20.0f, -48.0f, 0.1f);
    addFloat (l, "gateRelease", "Gate Release", 10.0f, 500.0f, 120.0f, 1.0f);

    addChoice (l, "tuneKey", { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" }, 0);
    addChoice (l, "tuneScale", { "MAJOR", "MINOR" }, 1);
    addFloat (l, "tuneDetune", "Reference Tuning", 415.0f, 467.0f, 440.0f, 0.1f);
    addFloat (l, "tuneRetune", "Retune Speed", 0.0f, 500.0f, 20.0f, 0.1f);
    addFloat (l, "tuneHumanize", "Humanize", 0.0f, 100.0f, 0.0f, 1.0f);
    addChoice (l, "tuneVoice", { "MALE", "FEMALE" }, 0);

    addFloat (l, "octaveOriginal", "Original Level", 0.0f, 100.0f, 100.0f, 1.0f);
    addFloat (l, "octaveDown", "Octave Down Level", 0.0f, 100.0f, 0.0f, 1.0f);
    addFloat (l, "octaveUp", "Octave Up Level", 0.0f, 100.0f, 0.0f, 1.0f);

    for (int i = 0; i < 5; ++i)
    {
        const auto s = juce::String (i + 1);
        addFloat (l, "eqFreq" + s, "EQ " + s + " Frequency", 20.0f, 20000.0f,
                  (float) std::array<int, 5> { 80, 220, 950, 3500, 11000 }[(size_t) i], 0.0f);
        addFloat (l, "eqGain" + s, "EQ " + s + " Gain", -18.0f, 18.0f, 0.0f, 0.1f);
        addFloat (l, "eqQ" + s, "EQ " + s + " Q", 0.2f, 12.0f, 0.85f, 0.01f);
    }
    addChoice (l, "eqType1", { "LOW CUT", "LOW SHELF", "BELL" }, 0);
    addChoice (l, "eqType5", { "HIGH CUT", "HIGH SHELF", "BELL" }, 0);
    const juce::StringArray eqSlopes { "12 dB/oct", "18 dB/oct", "24 dB/oct", "36 dB/oct", "48 dB/oct" };
    addChoice (l, "eqSlope1", eqSlopes, 2);
    addChoice (l, "eqSlope5", eqSlopes, 2);

    addFloat (l, "compInput", "1176 Input", -12.0f, 36.0f, 18.0f, 0.1f);
    addFloat (l, "compOutput", "1176 Output", -24.0f, 12.0f, 0.0f, 0.1f);
    addChoice (l, "compRatio", { "4:1", "8:1", "20:1" }, 0);

    addFloat (l, "deFreq", "De-Esser Frequency", 2000.0f, 12000.0f, 6200.0f, 1.0f);
    addFloat (l, "deThreshold", "De-Esser Threshold", -48.0f, 0.0f, -22.0f, 0.1f);
    addFloat (l, "deAmount", "De-Esser Amount", 0.0f, 100.0f, 75.0f, 1.0f);

    addChoice (l, "satMode", { "TRIODE", "PENTODE", "TAPE" }, 0);
    addFloat (l, "satDrive", "Saturation Drive", 0.0f, 48.0f, 5.0f, 0.1f);
    addFloat (l, "satMix", "Saturation Mix", 0.0f, 100.0f, 23.0f, 1.0f);
    addFloat (l, "satCharacter", "Saturation Character", 0.0f, 100.0f, 50.0f, 1.0f);

    addFloat (l, "ottDepth", "OTT Depth", 0.0f, 100.0f, 100.0f, 1.0f);
    addFloat (l, "ottTime", "OTT Time", 0.0f, 1000.0f, 100.0f, 1.0f);
    addFloat (l, "ottInput", "OTT Input", -24.0f, 19.1f, 0.0f, 0.1f);
    addFloat (l, "ottOutput", "OTT Output", -24.0f, 19.1f, 0.0f, 0.1f);
    addFloat (l, "ottUpward", "OTT Upward", 0.0f, 200.0f, 100.0f, 1.0f);
    addFloat (l, "ottDownward", "OTT Downward", 0.0f, 200.0f, 100.0f, 1.0f);
    for (auto* band : { "Low", "Mid", "High" })
    {
        addFloat (l, juce::String ("ottThreshold") + band, juce::String ("OTT ") + band + " Threshold", 0.0f, 200.0f, 100.0f, 1.0f);
        addFloat (l, juce::String ("ottGain") + band, juce::String ("OTT ") + band + " Gain", -24.0f, 6.0f, 0.0f, 0.1f);
    }

    addChoice (l, "modModeV06", { "DOUBLER", "CHORUS" }, 0);
    addFloat (l, "modSend", "Modulation Send", 0.0f, 100.0f, 0.0f, 1.0f);
    addFloat (l, "doubleDetune", "Doubler Detune", 0.0f, 50.0f, 23.0f, 0.1f);
    addFloat (l, "doubleDelay", "Doubler Delay", 0.0f, 50.0f, 7.0f, 0.1f);
    addFloat (l, "doubleOriginal", "Doubler Original Level", 0.0f, 100.0f, 100.0f, 1.0f);
    addFloat (l, "modCharacter", "Modulation Character", 0.0f, 100.0f, 50.0f, 1.0f);

    addChoice (l, "delayMode", { "STANDARD", "PING PONG" }, 0);
    addChoice (l, "delayNote", { "1/64", "1/32", "1/16", "1/8", "1/4", "1/2", "1/1" }, 3);
    addChoice (l, "delayFeel", { "STRAIGHT", "DOTTED", "TRIPLET" }, 0);
    addFloat (l, "delayFeedback", "Delay Feedback", 0.0f, 90.0f, 24.0f, 1.0f);
    addFloat (l, "delayMix", "Delay Send", 0.0f, 100.0f, 15.0f, 1.0f);

    addChoice (l, "reverbMode", { "ROOM", "HALL", "SPACE" }, 1);
    addFloat (l, "reverbDecay", "Reverb Decay", 100.0f, 10000.0f, 1700.0f, 1.0f);
    addFloat (l, "reverbCharacter", "Reverb Character", 0.0f, 100.0f, 60.0f, 1.0f);
    addFloat (l, "reverbMix", "Reverb Send", 0.0f, 100.0f, 18.0f, 1.0f);
    addFloat (l, "reverbDucking", "Smart Reverb Ducking", 0.0f, 100.0f, 35.0f, 1.0f);
    for (int i = 1; i <= 5; ++i)
        addChoice (l, "eqBandEnabled" + juce::String (i), { "OFF", "ON" }, 1);
    return l;
}

UltAudioProcessor::UltAudioProcessor()
    : AudioProcessor (BusesProperties().withInput ("Input", juce::AudioChannelSet::stereo(), true)
                                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "ULT_PARAMS", createLayout())
{
    for (auto& v : publishedOrder) v.store (-1, std::memory_order_relaxed);
    for (auto& v : bypassMix) v.store (0.0f, std::memory_order_relaxed);
    audioOrder.fill (-1);
    static constexpr const char* parameterIds[] = {
        "inputGain", "outputGain", "gateOn", "autotuneOn", "octaveOn", "eqOn", "compOn", "deOn", "satOn", "ottOn", "modOn", "delayOn", "reverbOn", "doublerOn", "doubleMix",
        "gateThreshold", "gateRelease", "tuneKey", "tuneScale", "tuneDetune", "tuneRetune", "tuneHumanize", "tuneVoice",
        "octaveOriginal", "octaveDown", "octaveUp", "eqFreq1", "eqGain1", "eqQ1", "eqFreq2", "eqGain2", "eqQ2", "eqFreq3", "eqGain3", "eqQ3", "eqFreq4", "eqGain4", "eqQ4", "eqFreq5", "eqGain5", "eqQ5", "eqType1", "eqType5", "eqSlope1", "eqSlope5",
        "compInput", "compOutput", "compRatio", "deFreq", "deThreshold", "deAmount", "satMode", "satDrive", "satMix", "satCharacter",
        "ottDepth", "ottTime", "ottInput", "ottOutput", "ottUpward", "ottDownward", "ottThresholdLow", "ottThresholdMid", "ottThresholdHigh", "ottGainLow", "ottGainMid", "ottGainHigh",
        "modModeV06", "modSend", "doubleDetune", "doubleDelay", "doubleOriginal", "modCharacter", "delayMode", "delayNote", "delayFeel", "delayFeedback", "delayMix", "reverbMode", "reverbDecay", "reverbCharacter", "reverbMix", "reverbDucking",
        "eqBandEnabled1", "eqBandEnabled2", "eqBandEnabled3", "eqBandEnabled4", "eqBandEnabled5"
    };
    for (const auto* id : parameterIds)
        if (auto* raw = apvts.getRawParameterValue (id)) parameterCache.emplace (id, raw);

    // Poll latency requests on JUCE's message thread. processBlock() only sets
    // an atomic flag; it never posts messages or takes a message-manager lock.
    startTimerHz (30);
}

UltAudioProcessor::~UltAudioProcessor()
{
    stopTimer();
    releaseResources();

    // JUCE hosts must stop processing before destroying an AudioProcessor.
    // Keep releaseResources() lightweight/non-blocking and free the external
    // DSP instances here, at final destruction, after the host has quiesced it.
    auto destroy = [] (void*& handle, auto fn)
    {
        if (handle != nullptr)
        {
            fn (handle);
            handle = nullptr;
        }
    };
    destroy (airDeBess, ult_DeBess_destroy);
    destroy (airDensity3, ult_Density3_destroy);
    destroy (airDoubler, ult_StereoDoubler_destroy);
    destroy (airChorus, ult_StereoChorus_destroy);
}

bool UltAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto in = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();
    const bool monoIn = in == juce::AudioChannelSet::mono();
    const bool stereoIn = in == juce::AudioChannelSet::stereo();
    const bool monoOut = out == juce::AudioChannelSet::mono();
    const bool stereoOut = out == juce::AudioChannelSet::stereo();
    return (monoIn && (monoOut || stereoOut)) || (stereoIn && stereoOut);
}

float UltAudioProcessor::pFast (const char* id) const noexcept
{
    for (const auto& item : parameterCache)
        if (std::strcmp (item.first.c_str(), id) == 0 && item.second != nullptr)
            return item.second->load (std::memory_order_relaxed);
    return 0.0f;
}
bool UltAudioProcessor::enabledParam (const char* id) const noexcept { return pFast (id) >= 0.5f; }

std::vector<int> UltAudioProcessor::getChainOrder() const
{
    std::vector<int> result;
    for (;;)
    {
        const auto before = orderSequence.load (std::memory_order_acquire);
        if (before & 1u) continue;
        const int count = juce::jlimit (0, maxEffects, publishedCount.load (std::memory_order_relaxed));
        result.clear();
        for (int i = 0; i < count; ++i)
        {
            const int id = publishedOrder[(size_t) i].load (std::memory_order_relaxed);
            if (id >= 0 && id < NumEffects) result.push_back (id);
        }
        const auto after = orderSequence.load (std::memory_order_acquire);
        if (before == after && !(after & 1u)) break;
    }
    return result;
}

void UltAudioProcessor::setChainOrder (const std::vector<int>& newOrder)
{
    std::array<int, maxEffects> clean {};
    clean.fill (-1);
    int count = 0;
    for (auto id : newOrder)
    {
        if (id < 0 || id >= NumEffects || id == Resonance) continue;
        bool duplicate = false;
        for (int i = 0; i < count; ++i) duplicate = duplicate || clean[(size_t) i] == id;
        if (! duplicate && count < maxEffects) clean[(size_t) count++] = id;
    }
    orderSequence.fetch_add (1, std::memory_order_acq_rel); // odd: writer owns the snapshot
    for (int i = 0; i < maxEffects; ++i) publishedOrder[(size_t) i].store (clean[(size_t) i], std::memory_order_relaxed);
    publishedCount.store (count, std::memory_order_relaxed);
    orderSequence.fetch_add (1, std::memory_order_release); // even: publish once, after mouse-up
    chainRevision.fetch_add (1, std::memory_order_release);
    updateLatencyAsync();
}

bool UltAudioProcessor::isInChain (int id) const
{
    const auto order = getChainOrder();
    return std::find (order.begin(), order.end(), id) != order.end();
}

void UltAudioProcessor::addEffectAt (int id, int position)
{
    auto order = getChainOrder();
    if (id < 0 || id >= NumEffects || id == Resonance
        || std::find (order.begin(), order.end(), id) != order.end()) return;
    position = juce::jlimit (0, (int) order.size(), position);
    order.insert (order.begin() + position, id);
    setChainOrder (order);
    if (id == Compressor)
    {
        if (auto* input = apvts.getParameter ("compInput"))
            input->setValueNotifyingHost (input->convertTo0to1 (18.0f));
        if (auto* output = apvts.getParameter ("compOutput"))
            output->setValueNotifyingHost (output->convertTo0to1 (0.0f));
    }
    setEffectEnabled (id, true); // newly inserted modules start active; Power provides bypass
}

void UltAudioProcessor::removeEffect (int id)
{
    auto order = getChainOrder();
    order.erase (std::remove (order.begin(), order.end(), id), order.end());
    setChainOrder (order);
    setEffectEnabled (id, false);
    if (id >= 0 && id < NumEffects) bypassMix[(size_t) id].store (0.0f, std::memory_order_relaxed);
    if (id == Modulation) modPowerResetRequested.store (true, std::memory_order_release);
}

const char* UltAudioProcessor::enabledParameterId (int id) noexcept
{
    // Resonance remains a reserved enum slot for state compatibility. Use an
    // explicit mapping rather than indexing a compact array with EffectId.
    switch (id)
    {
        case Gate:             return "gateOn";
        case Autotune:         return "autotuneOn";
        case OctaveShifterId:  return "octaveOn";
        case EQ:               return "eqOn";
        case Compressor:       return "compOn";
        case DeEsser:          return "deOn";
        case Saturator:        return "satOn";
        case OTT:              return "ottOn";
        case Modulation:       return "modOn";
        case Resonance:
        default:               return nullptr;
    }
}

bool UltAudioProcessor::isEffectEnabled (int id) const
{
    const auto* parameterId = enabledParameterId (id);
    return parameterId != nullptr && enabledParam (parameterId);
}

void UltAudioProcessor::setEffectEnabled (int id, bool state)
{
    const auto* parameterId = enabledParameterId (id);
    if (parameterId == nullptr)
        return;

    if (auto* parameter = apvts.getParameter (parameterId))
    {
        parameter->beginChangeGesture();
        parameter->setValueNotifyingHost (state ? 1.0f : 0.0f);
        parameter->endChangeGesture();
    }

    updateLatencyAsync();
}

void UltAudioProcessor::consumeChainOrder() noexcept
{
    const auto before = orderSequence.load (std::memory_order_acquire);
    if (before & 1u) return;
    const int count = juce::jlimit (0, maxEffects, publishedCount.load (std::memory_order_relaxed));
    std::array<int, maxEffects> snapshot {};
    snapshot.fill (-1);
    for (int i = 0; i < count; ++i) snapshot[(size_t) i] = publishedOrder[(size_t) i].load (std::memory_order_relaxed);
    const auto after = orderSequence.load (std::memory_order_acquire);
    if (before == after && !(after & 1u))
    {
        audioOrder = snapshot;
        audioOrderCount = count;
    }
}

void UltAudioProcessor::updateLatencyAsync()
{
    // Safe from any thread, including the realtime audio callback.
    latencyUpdateRequested.store (true, std::memory_order_release);
}

void UltAudioProcessor::timerCallback()
{
    if (! resourcesPrepared.load (std::memory_order_acquire))
        return;
    if (! latencyUpdateRequested.exchange (false, std::memory_order_acq_rel))
        return;

    int latency = 0;
    if (isInChain (Autotune) && (isEffectEnabled (Autotune) || bypassMix[(size_t) Autotune].load (std::memory_order_relaxed) > 0.001f))
        latency += juce::jmax (0, autotune.getLatencySamples());
    if (isInChain (OctaveShifterId) && (isEffectEnabled (OctaveShifterId) || bypassMix[(size_t) OctaveShifterId].load (std::memory_order_relaxed) > 0.001f))
        latency += octave.getLatencySamples();
    if (latency != lastReportedLatency)
    {
        lastReportedLatency = latency;
        setLatencySamples (latency);
    }
}

void UltAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    // JUCE calls prepareToPlay() with processing stopped. Mark inactive while
    // resizing buffers and rebuilding sample-rate-dependent DSP resources.
    resourcesPrepared.store (false, std::memory_order_release);
    sr = juce::jmax (8000.0, sampleRate);
    maxBlock = juce::jmax (16384, samplesPerBlock);
    preparedChannels = juce::jlimit (1, 2, getTotalNumOutputChannels());
    tempA.setSize (2, maxBlock, false, true, false);
    tempB.setSize (2, maxBlock, false, true, false);
    bypassDry.setSize (2, maxBlock, false, true, false);
    sendSource.setSize (2, maxBlock, false, true, false);
    bypassCoeff = onePoleCoeff (5.0f, sr);
    delayPowerCoeff = onePoleCoeff (5.0f, sr);
    reverbPowerCoeff = onePoleCoeff (5.0f, sr);
    delayPowerMix = enabledParam ("delayOn") ? 1.0f : 0.0f;
    reverbPowerMix = enabledParam ("reverbOn") ? 1.0f : 0.0f;
    for (int i = 0; i < NumEffects; ++i)
        bypassMix[(size_t) i].store (isEffectEnabled (i) ? 1.0f : 0.0f, std::memory_order_relaxed);
    const int maxDelay = (int) std::ceil (sr * 16.0) + maxBlock + 8;
    for (auto& ch : delayBuffer) ch.assign ((size_t) maxDelay, 0.0f);
    reverbPowerCurve.assign ((size_t) maxBlock, 0.0f);
    delayWrite.fill (0);
    gateEnvelope = {};
    gateGainEnvelope.fill (0.0f);
    deEssLowpass.fill (0.0f);
    deEssEnvelope.fill (0.0f);
    deEssGain.fill (1.0f);
    reverbDuckEnvelope.fill (0.0f);
    modPowerMix = 0.0f; modCurrentMode = 0; modPreviousMode = 0; modTransitionRemaining = 0;
    modPowerResetRequested.store (false, std::memory_order_relaxed);
    modPowerCoeff = onePoleCoeff (10.0f, sr);
    modTransitionTotal = juce::jmax (1, (int) std::lround (0.02 * sr));

    for (int ch = 0; ch < 2; ++ch)
    {
        for (auto& band : eqFilters[(size_t) ch])
            for (auto& f : band)
            {
                f.setSmoothing (onePoleCoeff (5.0f, sr));
                f.reset();
            }
    }
    eqValuesInitialised = false;
    updateEqIfNeeded();

    octave.prepare (sr, preparedChannels, maxBlock);
    reverb.prepare (sr);
    autotune.prepare (sr, preparedChannels);
    fetCompressor.prepare (sr, maxBlock, preparedChannels);
    compressorGrTap.assign ((size_t) maxBlock, 0.0f);
    compressorBlockGrDb = 0.0f;
    ott.prepare (sr, preparedChannels);

    auto destroy = [] (void*& handle, auto fn) { if (handle != nullptr) { fn (handle); handle = nullptr; } };
    destroy (airDeBess, ult_DeBess_destroy); destroy (airDensity3, ult_Density3_destroy);
    destroy (airDoubler, ult_StereoDoubler_destroy); destroy (airChorus, ult_StereoChorus_destroy);
    airDeBess = ult_DeBess_create (sr); airDensity3 = ult_Density3_create (sr);
    airDoubler = ult_StereoDoubler_create (sr); airChorus = ult_StereoChorus_create (sr);
    audioOrderCount = 0;
    audioOrder.fill (-1);
    consumeChainOrder();
    resourcesPrepared.store (true, std::memory_order_release);
    updateLatencyAsync();
}

void UltAudioProcessor::releaseResources()
{
    // Do not wait here and do not destroy external DSP handles. Some hosts call
    // releaseResources() as part of graph teardown; blocking for an in-flight
    // processBlock() can deadlock the host. Existing callbacks may finish using
    // still-valid handles; later callbacks return silence. Handles are reclaimed
    // by the next prepareToPlay() or the processor destructor.
    resourcesPrepared.store (false, std::memory_order_release);
}

// RBJ biquad coefficient helpers. Coefficients update only when a parameter changes;
// the sample loop itself performs no allocation.
void UltAudioProcessor::Biquad::setFirstOrderLowPass (double sr, float hz) noexcept
{
    const float k = std::tan (juce::MathConstants<float>::pi * juce::jlimit (10.0f, (float) sr * 0.45f, hz) / (float) sr);
    const float norm = 1.0f / (1.0f + k);
    tb0 = k * norm; tb1 = tb0; tb2 = 0.0f;
    ta1 = (k - 1.0f) * norm; ta2 = 0.0f;
}
void UltAudioProcessor::Biquad::setFirstOrderHighPass (double sr, float hz) noexcept
{
    const float k = std::tan (juce::MathConstants<float>::pi * juce::jlimit (10.0f, (float) sr * 0.45f, hz) / (float) sr);
    const float norm = 1.0f / (1.0f + k);
    tb0 = norm; tb1 = -norm; tb2 = 0.0f;
    ta1 = (k - 1.0f) * norm; ta2 = 0.0f;
}
void UltAudioProcessor::Biquad::setLowPass (double sr, float hz, float q) noexcept
{
    const float w = juce::MathConstants<float>::twoPi * juce::jlimit (10.0f, (float) sr * 0.45f, hz) / (float) sr;
    const float c = std::cos (w), a = std::sin (w) / (2.0f * juce::jmax (0.1f, q));
    const float a0 = 1.0f + a; tb0 = ((1.0f - c) * 0.5f) / a0; tb1 = (1.0f - c) / a0; tb2 = tb0; ta1 = (-2.0f * c) / a0; ta2 = (1.0f - a) / a0;
}
void UltAudioProcessor::Biquad::setHighPass (double sr, float hz, float q) noexcept
{
    const float w = juce::MathConstants<float>::twoPi * juce::jlimit (10.0f, (float) sr * 0.45f, hz) / (float) sr;
    const float c = std::cos (w), a = std::sin (w) / (2.0f * juce::jmax (0.1f, q));
    const float a0 = 1.0f + a; tb0 = ((1.0f + c) * 0.5f) / a0; tb1 = -(1.0f + c) / a0; tb2 = tb0; ta1 = (-2.0f * c) / a0; ta2 = (1.0f - a) / a0;
}
void UltAudioProcessor::Biquad::setBandPass (double sr, float hz, float q) noexcept
{
    const float w = juce::MathConstants<float>::twoPi * juce::jlimit (10.0f, (float) sr * 0.45f, hz) / (float) sr;
    const float c = std::cos (w), a = std::sin (w) / (2.0f * juce::jmax (0.1f, q));
    const float a0 = 1.0f + a;
    tb0 = a / a0; tb1 = 0.0f; tb2 = -a / a0;
    ta1 = (-2.0f * c) / a0; ta2 = (1.0f - a) / a0;
}
void UltAudioProcessor::Biquad::setPeak (double sr, float hz, float q, float gainDb) noexcept
{
    const float A = std::pow (10.0f, gainDb / 40.0f);
    const float w = juce::MathConstants<float>::twoPi * juce::jlimit (10.0f, (float) sr * 0.45f, hz) / (float) sr;
    const float c = std::cos (w), a = std::sin (w) / (2.0f * juce::jmax (0.1f, q));
    const float a0 = 1.0f + a / A;
    tb0 = (1.0f + a * A) / a0; tb1 = (-2.0f * c) / a0; tb2 = (1.0f - a * A) / a0;
    ta1 = (-2.0f * c) / a0; ta2 = (1.0f - a / A) / a0;
}
void UltAudioProcessor::Biquad::setLowShelf (double sr, float hz, float q, float gainDb) noexcept
{
    const float A = std::pow (10.0f, gainDb / 40.0f), w = juce::MathConstants<float>::twoPi * juce::jlimit (10.0f, (float) sr * 0.45f, hz) / (float) sr;
    const float c = std::cos (w), s = std::sin (w), alpha = s / (2.0f * juce::jmax (0.1f, q)), beta = 2.0f * std::sqrt (A) * alpha;
    const float a0 = (A + 1.0f) + (A - 1.0f) * c + beta;
    tb0 = A * ((A + 1.0f) - (A - 1.0f) * c + beta) / a0;
    tb1 = 2.0f * A * ((A - 1.0f) - (A + 1.0f) * c) / a0;
    tb2 = A * ((A + 1.0f) - (A - 1.0f) * c - beta) / a0;
    ta1 = -2.0f * ((A - 1.0f) + (A + 1.0f) * c) / a0;
    ta2 = ((A + 1.0f) + (A - 1.0f) * c - beta) / a0;
}
void UltAudioProcessor::Biquad::setHighShelf (double sr, float hz, float q, float gainDb) noexcept
{
    const float A = std::pow (10.0f, gainDb / 40.0f), w = juce::MathConstants<float>::twoPi * juce::jlimit (10.0f, (float) sr * 0.45f, hz) / (float) sr;
    const float c = std::cos (w), s = std::sin (w), alpha = s / (2.0f * juce::jmax (0.1f, q)), beta = 2.0f * std::sqrt (A) * alpha;
    const float a0 = (A + 1.0f) - (A - 1.0f) * c + beta;
    tb0 = A * ((A + 1.0f) + (A - 1.0f) * c + beta) / a0;
    tb1 = -2.0f * A * ((A - 1.0f) + (A + 1.0f) * c) / a0;
    tb2 = A * ((A + 1.0f) + (A - 1.0f) * c - beta) / a0;
    ta1 = 2.0f * ((A - 1.0f) - (A + 1.0f) * c) / a0;
    ta2 = ((A + 1.0f) - (A - 1.0f) * c - beta) / a0;
}

float UltAudioProcessor::getEqResponseDb (float hz) const noexcept
{
    const double rate = juce::jmax (1000.0, (double) eqSpectrumSampleRate.load (std::memory_order_relaxed));
    const double omega = juce::MathConstants<double>::twoPi * juce::jlimit (0.0, rate * 0.499, (double) hz) / rate;
    const double c = std::cos (omega), si = std::sin (omega), c2 = std::cos (2 * omega), s2 = std::sin (2 * omega);
    double db = 0;
    auto accumulate = [&] (const Biquad& f)
    {
        const double nr = f.tb0 + f.tb1 * c + f.tb2 * c2, ni = -f.tb1 * si - f.tb2 * s2;
        const double dr = 1 + f.ta1 * c + f.ta2 * c2, di = -f.ta1 * si - f.ta2 * s2;
        db += 10 * std::log10 (juce::jmax (1.0e-20, (nr * nr + ni * ni) / juce::jmax (1.0e-20, dr * dr + di * di)));
    };
    for (int i = 0; i < 5; ++i)
    {
        const auto suffix = juce::String (i + 1);
        auto value = [&] (const juce::String& id) { auto* p = apvts.getRawParameterValue (id); return p != nullptr ? p->load() : 0.0f; };
        if (value ("eqBandEnabled" + suffix) < 0.5f) continue;
        const float fc = juce::jlimit (20.0f, (float) rate * 0.45f, value ("eqFreq" + suffix));
        const float q = value ("eqQ" + suffix), gain = value ("eqGain" + suffix);
        const bool edge = i == 0 || i == 4;
        const float type = edge ? value ("eqType" + suffix) : 2.0f;
        Biquad f;
        if (edge && type < 0.5f)
        {
            const int order = std::array<int, 5>{2,3,4,6,8}[(size_t) juce::jlimit (0,4,(int) std::lround (value ("eqSlope" + suffix)))];
            if (order & 1) { if (i == 0) f.setFirstOrderHighPass (rate, fc); else f.setFirstOrderLowPass (rate, fc); accumulate (f); }
            for (int section = 0; section < order / 2; ++section)
            {
                const float bq = 1.0f / (2.0f * std::sin (juce::MathConstants<float>::pi * (2 * section + 1) / (2 * order)));
                if (i == 0) f.setHighPass (rate, fc, bq); else f.setLowPass (rate, fc, bq);
                accumulate (f);
            }
        }
        else
        {
            if (i == 0 && type < 1.5f) f.setLowShelf (rate, fc, q, gain);
            else if (i == 4 && type < 1.5f) f.setHighShelf (rate, fc, q, gain);
            else f.setPeak (rate, fc, q, gain);
            accumulate (f);
        }
    }
    return (float) juce::jlimit (-120.0, 120.0, db);
}

void UltAudioProcessor::updateEqIfNeeded() noexcept
{
    static constexpr const char* freqIds[5] = { "eqFreq1", "eqFreq2", "eqFreq3", "eqFreq4", "eqFreq5" };
    static constexpr const char* gainIds[5] = { "eqGain1", "eqGain2", "eqGain3", "eqGain4", "eqGain5" };
    static constexpr const char* qIds[5] = { "eqQ1", "eqQ2", "eqQ3", "eqQ4", "eqQ5" };
    static constexpr const char* enabledIds[5] = { "eqBandEnabled1", "eqBandEnabled2", "eqBandEnabled3", "eqBandEnabled4", "eqBandEnabled5" };
    std::array<float, 24> values {};
    for (int i = 0; i < 5; ++i)
    {
        values[19 + (size_t) i] = pFast (enabledIds[i]);
        values[(size_t) i * 3] = pFast (freqIds[i]);
        values[(size_t) i * 3 + 1] = pFast (gainIds[i]);
        values[(size_t) i * 3 + 2] = pFast (qIds[i]);
    }
    values[15] = pFast ("eqType1"); values[16] = pFast ("eqType5");
    values[17] = pFast ("eqSlope1"); values[18] = pFast ("eqSlope5");
    if (eqValuesInitialised && values == lastEqValues) return;
    lastEqValues = values; eqValuesInitialised = true;

    const float lowType = pFast ("eqType1");
    const float highType = pFast ("eqType5");
    const int lowOrder = std::array<int, 5> { 2, 3, 4, 6, 8 }[(size_t) juce::jlimit (0, 4, (int) std::lround (pFast ("eqSlope1")))];
    const int highOrder = std::array<int, 5> { 2, 3, 4, 6, 8 }[(size_t) juce::jlimit (0, 4, (int) std::lround (pFast ("eqSlope5")))];

    for (int i = 0; i < 5; ++i)
    {
        if (values[19 + (size_t) i] < 0.5f)
        {
            eqStageCounts[(size_t) i] = 0;
            for (auto& channel : eqFilters)
                for (auto& stage : channel[(size_t) i]) stage.reset();
            continue;
        }
        const float hz = juce::jlimit (20.0f, (float) sr * 0.45f, pFast (freqIds[i]));
        const float q = pFast (qIds[i]), gain = pFast (gainIds[i]);
        const bool lowCut = i == 0 && lowType < 0.5f;
        const bool highCut = i == 4 && highType < 0.5f;
        const int order = lowCut ? lowOrder : (highCut ? highOrder : 0);
        eqStageCounts[(size_t) i] = order > 0 ? (order + 1) / 2 : 1;
        for (int ch = 0; ch < 2; ++ch)
        {
            auto& stages = eqFilters[(size_t) ch][(size_t) i];
            for (auto& stage : stages) stage.setIdentity();

            if (order > 0)
            {
                const bool highPass = lowCut;
                int stageIndex = 0;
                if ((order & 1) != 0)
                {
                    if (highPass) stages[(size_t) stageIndex].setFirstOrderHighPass (sr, hz);
                    else          stages[(size_t) stageIndex].setFirstOrderLowPass (sr, hz);
                    ++stageIndex;
                }
                for (int section = 0; section < order / 2 && stageIndex < (int) stages.size(); ++section)
                {
                    const float angle = juce::MathConstants<float>::pi * (float) (2 * section + 1) / (2.0f * (float) order);
                    const float butterworthQ = 1.0f / (2.0f * std::sin (angle));
                    if (highPass) stages[(size_t) stageIndex].setHighPass (sr, hz, butterworthQ);
                    else          stages[(size_t) stageIndex].setLowPass (sr, hz, butterworthQ);
                    ++stageIndex;
                }
            }
            else if (i == 0 && lowType < 1.5f)
                stages[0].setLowShelf (sr, hz, q, gain);
            else if (i == 4 && highType < 1.5f)
                stages[0].setHighShelf (sr, hz, q, gain);
            else
                stages[0].setPeak (sr, hz, q, gain);
        }
    }
}

void UltAudioProcessor::processGate (juce::AudioBuffer<float>& buffer) noexcept
{
    const int nc = juce::jmin (2, buffer.getNumChannels()), ns = buffer.getNumSamples();
    const float threshold = dbToGain (pFast ("gateThreshold"));
    const float detectorAttack = onePoleCoeff (1.0f, sr);
    const float detectorRelease = onePoleCoeff (8.0f, sr);
    const float gateAttack = onePoleCoeff (0.7f, sr);
    const int releaseSamples = juce::jmax (1, (int) std::lround (pFast ("gateRelease") * 0.001 * sr));
    const float releaseStep = 1.0f / (float) releaseSamples;

    bool open = false;
    float maxGain = 0.0f;
    for (int ch = 0; ch < nc; ++ch)
        for (int i = 0; i < ns; ++i)
        {
            const float x = buffer.getSample (ch, i);
            const float env = gateEnvelope[(size_t) ch].process (std::abs (x), detectorAttack, detectorRelease);
            const bool shouldOpen = env >= threshold;
            float& gateGain = gateGainEnvelope[(size_t) ch];

            if (shouldOpen)
                gateGain += gateAttack * (1.0f - gateGain);
            else
                gateGain = juce::jmax (0.0f, gateGain - releaseStep);

            // The user-selected Release is the full close time, ending at exact silence.
            if (gateGain < 1.0e-6f)
                gateGain = 0.0f;

            buffer.setSample (ch, i, x * gateGain);
            if (i == ns - 1) { open = open || shouldOpen; maxGain = juce::jmax (maxGain, gateGain); }
        }
    gateDetectorOpen.store (open, std::memory_order_relaxed);
    gateBlockGrDb = -juce::Decibels::gainToDecibels (maxGain, -72.0f);
}

void UltAudioProcessor::processAutotune (juce::AudioBuffer<float>& buffer) noexcept
{
    snaptune::EngineSettings settings;
    settings.key = (int) pFast ("tuneKey");
    settings.scale = pFast ("tuneScale") < 0.5f ? snaptune::Scale::major : snaptune::Scale::minor;
    settings.referenceHz = pFast ("tuneDetune");
    settings.retuneMs = pFast ("tuneRetune");
    const float human = clamp01 (pFast ("tuneHumanize") * 0.01f);
    settings.humanize = human;
    settings.amount = 1.0f - 0.55f * human; // one control combines Flex-like amount and Humanize
    settings.voice = pFast ("tuneVoice") < 0.5f ? snaptune::VoiceType::altoTenor : snaptune::VoiceType::soprano;
    settings.tracking = 0.55f;
    settings.mix = 1.0f;
    settings.mode = snaptune::LatencyMode::live;
    autotune.setSettings (settings);
    autotune.process (buffer.getArrayOfWritePointers(), juce::jmin (2, buffer.getNumChannels()), 0, buffer.getNumSamples(), false);

}

void UltAudioProcessor::processEq (juce::AudioBuffer<float>& buffer) noexcept
{
    updateEqIfNeeded();
    const int nc = juce::jmin (2, buffer.getNumChannels()), ns = buffer.getNumSamples();
    for (int ch = 0; ch < nc; ++ch)
        for (int i = 0; i < ns; ++i)
        {
            float x = buffer.getSample (ch, i);
            for (int band = 0; band < 5; ++band)
                for (int stage = 0; stage < eqStageCounts[(size_t) band]; ++stage)
                    x = eqFilters[(size_t) ch][(size_t) band][(size_t) stage].process (x);
            buffer.setSample (ch, i, x);
        }
}

void UltAudioProcessor::processCompressor (juce::AudioBuffer<float>& buffer) noexcept
{
    refcomp::Parameters cp;
    cp.mode = refcomp::Mode::FET;
    cp.thresholdDb = -18.0f;
    const int ratio = (int) pFast ("compRatio");
    cp.ratio = ratio == 0 ? 4.0f : (ratio == 1 ? 8.0f : 20.0f);
    cp.attackMs = 0.02f;
    cp.releaseMs = 55.0f;
    cp.kneeDb = 0.0f;
    cp.driveDb = pFast ("compInput");
    cp.makeupDb = pFast ("compOutput");
    cp.mix = 1.0f;
    cp.hq = false; // zero-latency base-rate FET path for LIVE monitoring
    cp.flaws = false;
    fetCompressor.setParameters (cp);
    const int nc = juce::jmin (2, buffer.getNumChannels());
    const int ns = buffer.getNumSamples();
    compressorBlockGrDb = 0.0f;
    for (int offset = 0; offset < ns; offset += maxBlock)
    {
        const int count = juce::jmin (maxBlock, ns - offset);
        float* channels[2] = { buffer.getWritePointer (0) + offset,
                               nc > 1 ? buffer.getWritePointer (1) + offset : nullptr };
        // The reference engine reports detector gain reduction in dB,
        // independently of output makeup gain or input/output peak ratios.
        const bool measure = visualizationActive.load (std::memory_order_relaxed);
        fetCompressor.setGrTap (measure ? compressorGrTap.data() : nullptr);
        fetCompressor.process (channels, nc, count);
        if (measure) for (int i = 0; i < count; ++i)
            compressorBlockGrDb = juce::jmax (compressorBlockGrDb,
                juce::jmax (0.0f, compressorGrTap[(size_t) i]));
    }
    fetCompressor.setGrTap (nullptr);
}

void UltAudioProcessor::processDeEsser (juce::AudioBuffer<float>& buffer) noexcept
{
    deBlockGrDb = 0.0f;
    const int ns = buffer.getNumSamples(), nc = juce::jmin (2, buffer.getNumChannels());
    if (ns > tempA.getNumSamples()) return;
    const float freq = pFast ("deFreq");
    const float coeff = 1.0f - std::exp (-juce::MathConstants<float>::twoPi * freq / (float) sr);
    const float threshold = juce::jlimit (-48.0f, 0.0f, pFast ("deThreshold"));
    const float amount = clamp01 (pFast ("deAmount") * 0.01f);
    const float attack = std::exp (-1.0f / (0.0005f * (float) sr));
    const float release = std::exp (-1.0f / (0.035f * (float) sr));
    const bool measure = visualizationActive.load (std::memory_order_relaxed);
    double preEnergy = 0.0, postEnergy = 0.0;
    for (int ch = 0; ch < nc; ++ch)
    {
        auto* out = buffer.getWritePointer (ch);
        auto& low = deEssLowpass[(size_t) ch];
        auto& env = deEssEnvelope[(size_t) ch];
        auto& gain = deEssGain[(size_t) ch];
        for (int i = 0; i < ns; ++i)
        {
            const float input = out[i];
            low += coeff * (input - low);
            const float high = input - low;
            const float peak = std::abs (high);
            const float c = peak > env ? attack : release;
            env = c * env + (1.0f - c) * peak;
            const float over = juce::jmax (0.0f, juce::Decibels::gainToDecibels (env, -100.0f) - threshold);
            const float reduction = amount * juce::jmin (48.0f, over * 4.0f);
            const float target = juce::Decibels::decibelsToGain (-reduction);
            const float gc = target < gain ? attack : release;
            gain = gc * gain + (1.0f - gc) * target;
            const float processed = high * (amount > 0.0f ? gain : 1.0f);
            out[i] = low + processed;
            if (measure) { preEnergy += (double) high * high; postEnergy += (double) processed * processed; }
        }
    }
    if (preEnergy > 1.0e-12)
        deBlockGrDb = (float) juce::jlimit (0.0, 48.0, 10.0 * std::log10 (preEnergy / juce::jmax (postEnergy, 1.0e-12)));

}

void UltAudioProcessor::processSaturator (juce::AudioBuffer<float>& buffer) noexcept
{
    const int ns = buffer.getNumSamples(), nc = juce::jmin (2, buffer.getNumChannels());
    if (ns > tempA.getNumSamples()) return;
    if (airDensity3 == nullptr) return;
    copyToStereoScratch (tempA, buffer, ns);
    const int mode = (int) pFast ("satMode");
    const float drive = pFast ("satDrive");
    // Triode / Pentode / Tape are musical voicings over the original Density3 DSP.
    // They do not claim to be component-level circuit simulations.
    const float modeScale = mode == 0 ? 0.72f : (mode == 1 ? 1.00f : 1.28f);
    const float character = pFast ("satCharacter") * 0.01f;
    const float density = juce::jlimit (0.0f, 1.0f, 0.18f + (drive / 24.0f) * 0.82f * modeScale);
    const float voicedCharacter = mode == 0 ? character * 0.72f
                                  : (mode == 1 ? 0.25f + character * 0.55f
                                               : 0.62f + character * 0.30f);
    ult_Density3_set (airDensity3, 0, density);
    ult_Density3_set (airDensity3, 1, juce::jlimit (0.0f, 1.0f, voicedCharacter));
    ult_Density3_set (airDensity3, 2, 1.0f);
    ult_Density3_set (airDensity3, 3, 1.0f); // fully wet original Density3 output; ult applies the send/mix
    if (nc == 1) juce::FloatVectorOperations::copy (tempA.getWritePointer (1), tempA.getReadPointer (0), ns);
    const float extraDrive = juce::Decibels::decibelsToGain (juce::jmax (0.0f, drive - 24.0f));
    for (int ch = 0; ch < 2; ++ch)
        juce::FloatVectorOperations::multiply (tempA.getWritePointer (ch), extraDrive, ns);
    ult_Density3_process (airDensity3, tempA.getWritePointer (0), tempA.getWritePointer (1), ns);
    const float mix = clamp01 (pFast ("satMix") * 0.01f);
    for (int ch = 0; ch < nc; ++ch)
        for (int i = 0; i < ns; ++i)
            buffer.setSample (ch, i, buffer.getSample (ch, i) * (1.0f - mix) + tempA.getSample (ch, i) * mix);
}

void UltAudioProcessor::processOtt (juce::AudioBuffer<float>& buffer) noexcept
{
    FaustOtt::Parameters op;
    op.depth = pFast ("ottDepth") * 0.01f;
    op.time = pFast ("ottTime") * 0.01f; // 100% is Faust time=1.0
    op.inputDb = pFast ("ottInput"); op.outputDb = pFast ("ottOutput");
    op.upward = pFast ("ottUpward") * 0.01f; op.downward = pFast ("ottDownward") * 0.01f;
    op.threshold = { pFast ("ottThresholdLow") * 0.01f, pFast ("ottThresholdMid") * 0.01f, pFast ("ottThresholdHigh") * 0.01f };
    op.gainDb = { pFast ("ottGainLow"), pFast ("ottGainMid"), pFast ("ottGainHigh") };
    ott.setParameters (op);
    ott.process (buffer);
}

void UltAudioProcessor::processOctaveShifter (juce::AudioBuffer<float>& buffer) noexcept
{
    octave.process (buffer, pFast ("octaveOriginal"), pFast ("octaveDown"), pFast ("octaveUp"),
                    false, pFast ("tuneVoice") >= 0.5f);
}

void UltAudioProcessor::processModulation (juce::AudioBuffer<float>& buffer) noexcept
{
    if (modPowerResetRequested.exchange (false, std::memory_order_acq_rel))
    {
        modPowerMix = 0.0f;
        modCurrentMode = modPreviousMode = 0;
        modTransitionRemaining = 0;
    }

    // v0.6.1 has only Doubler (0) and Chorus (1). Bypass is controlled by Power.
    const int mode = juce::jlimit (0, 1, (int) pFast ("modModeV06"));
    if ((mode == 0 && airDoubler == nullptr) || (mode == 1 && airChorus == nullptr))
        return;
    const float send = clamp01 (pFast ("modSend") * 0.01f);
    const float powerTarget = enabledParam ("modOn") ? 1.0f : 0.0f;
    const int ns = buffer.getNumSamples(), nc = juce::jmin (2, buffer.getNumChannels());
    if (ns > tempA.getNumSamples()) return;

    if (mode != modCurrentMode)
    {
        modPreviousMode = modCurrentMode;
        modCurrentMode = mode;
        modTransitionRemaining = modTransitionTotal + 1;
    }
    if (modPowerMix < 0.0001f && powerTarget < 0.5f)
        return;

    auto renderMode = [this, &buffer, ns] (int renderModeId, juce::AudioBuffer<float>& scratch)
    {
        copyToStereoScratch (scratch, buffer, ns);
        if (renderModeId == 0)
        {
            const float cents = juce::jlimit (0.0f, 50.0f, pFast ("doubleDetune"));
            const float ratio = std::pow (2.0f, -cents / 1200.0f);
            const float trim = ratio - 1.0f;
            const float a = 0.5f + 0.5f * std::copysign (std::sqrt (std::abs (trim) * 32.0f), trim);
            ult_StereoDoubler_set (airDoubler, 0, juce::jlimit (0.0f, 1.0f, a));
            ult_StereoDoubler_set (airDoubler, 1, 1.0f);
            ult_StereoDoubler_set (airDoubler, 2, pFast ("doubleDelay") * 0.02f);
            ult_StereoDoubler_process (airDoubler, scratch.getWritePointer (0), scratch.getWritePointer (1), ns);
        }
        else
        {
            const float character = pFast ("modCharacter") * 0.01f;
            ult_StereoChorus_set (airChorus, 0, 0.08f + character * 0.84f);
            ult_StereoChorus_set (airChorus, 1, 0.15f + character * 0.75f);
            ult_StereoChorus_process (airChorus, scratch.getWritePointer (0), scratch.getWritePointer (1), ns);
        }
    };

    const bool transitioning = modTransitionRemaining > 0;
    if (transitioning)
    {
        renderMode (modPreviousMode, tempA);
        renderMode (modCurrentMode, tempB);
        for (int i = 0; i < ns; ++i)
        {
            modPowerMix += modPowerCoeff * (powerTarget - modPowerMix);
            const float alpha = juce::jlimit (0.0f, 1.0f,
                1.0f - (float) (modTransitionRemaining - 1) / (float) modTransitionTotal);
            const float oldOriginal = modPreviousMode == 0 ? clamp01 (pFast ("doubleOriginal") * 0.01f) : 1.0f;
            const float newOriginal = modCurrentMode == 0 ? clamp01 (pFast ("doubleOriginal") * 0.01f) : 1.0f;
            const float originalTarget = oldOriginal * (1.0f - alpha) + newOriginal * alpha;
            const float dryGain = 1.0f + (originalTarget - 1.0f) * modPowerMix;
            const float wetScale = send * modPowerMix;
            for (int ch = 0; ch < nc; ++ch)
            {
                const float oldWet = tempA.getSample (ch, i);
                const float newWet = tempB.getSample (ch, i);
                const float wet = oldWet * (1.0f - alpha) + newWet * alpha;
                buffer.setSample (ch, i, buffer.getSample (ch, i) * dryGain + wet * wetScale);
            }
            if (modTransitionRemaining > 0) --modTransitionRemaining;
        }
    }
    else
    {
        renderMode (modCurrentMode, tempA);
        const float originalTarget = modCurrentMode == 0 ? clamp01 (pFast ("doubleOriginal") * 0.01f) : 1.0f;
        for (int i = 0; i < ns; ++i)
        {
            modPowerMix += modPowerCoeff * (powerTarget - modPowerMix);
            const float dryGain = 1.0f + (originalTarget - 1.0f) * modPowerMix;
            const float wetScale = send * modPowerMix;
            for (int ch = 0; ch < nc; ++ch)
                buffer.setSample (ch, i, buffer.getSample (ch, i) * dryGain + tempA.getSample (ch, i) * wetScale);
        }
    }
}

void UltAudioProcessor::processDelaySend (juce::AudioBuffer<float>& buffer, double bpm) noexcept
{
    const int nc = juce::jmin (2, buffer.getNumChannels()), ns = buffer.getNumSamples();
    if (delayBuffer[0].empty()) return;
    const float powerTarget = enabledParam ("delayOn") ? 1.0f : 0.0f;
    const int note = juce::jlimit (0, 6, (int) pFast ("delayNote"));
    const double beat = 60.0 / juce::jlimit (20.0, 300.0, bpm);
    const double noteFactor[7] = { 1.0 / 16.0, 1.0 / 8.0, 1.0 / 4.0, 1.0 / 2.0, 1.0, 2.0, 4.0 };
    const double feel = pFast ("delayFeel") < 0.5f ? 1.0 : (pFast ("delayFeel") < 1.5f ? 1.5 : (2.0 / 3.0));
    const int delaySamples = juce::jlimit (1, (int) delayBuffer[0].size() - 2,
        (int) std::lround (beat * noteFactor[note] * feel * sr));
    const float feedback = pFast ("delayFeedback") * 0.01f;
    const float send = pFast ("delayMix") * 0.01f;
    const bool pingPong = pFast ("delayMode") > 0.5f && nc > 1;

    for (int i = 0; i < ns; ++i)
    {
        delayPowerMix += delayPowerCoeff * (powerTarget - delayPowerMix);
        float delayed[2] {};
        for (int ch = 0; ch < 2; ++ch)
        {
            const auto& ring = delayBuffer[(size_t) ch];
            int read = delayWrite[(size_t) ch] - delaySamples;
            if (read < 0) read += (int) ring.size();
            delayed[ch] = ring[(size_t) read];
        }

        const float inL = sendSource.getSample (0, i) * delayPowerMix;
        const float inR = sendSource.getSample (1, i) * delayPowerMix;
        const float fb = feedback * delayPowerMix;
        if (pingPong)
        {
            // Paired ping-pong repeats: L100, R100, L75, R75, L56, R56...
            // The L->R leg is unity; the R->L leg applies Feedback once per pair.
            // This keeps both sides of each pair equally loud, then fades the next pair.
            const float monoInput = 0.5f * (inL + inR);
            delayBuffer[0][(size_t) delayWrite[0]] = monoInput + delayed[1] * fb;
            delayBuffer[1][(size_t) delayWrite[1]] = delayed[0];
        }
        else
        {
            delayBuffer[0][(size_t) delayWrite[0]] = inL + delayed[0] * fb;
            delayBuffer[1][(size_t) delayWrite[1]] = inR + delayed[1] * fb;
        }

        for (int ch = 0; ch < 2; ++ch)
            delayWrite[(size_t) ch] = (delayWrite[(size_t) ch] + 1) % (int) delayBuffer[(size_t) ch].size();

        if (nc > 1)
        {
            buffer.setSample (0, i, buffer.getSample (0, i) + delayed[0] * send * delayPowerMix);
            buffer.setSample (1, i, buffer.getSample (1, i) + delayed[1] * send * delayPowerMix);
        }
        else
        {
            const float monoWet = pingPong ? 0.5f * (delayed[0] + delayed[1]) : delayed[0];
            buffer.setSample (0, i, buffer.getSample (0, i) + monoWet * send * delayPowerMix);
        }
    }
}

void UltAudioProcessor::processReverbSend (juce::AudioBuffer<float>& buffer) noexcept
{
    const int ns = buffer.getNumSamples(), nc = juce::jmin (2, buffer.getNumChannels());
    if (ns > tempA.getNumSamples()) return;

    const float powerTarget = enabledParam ("reverbOn") ? 1.0f : 0.0f;
    const float send = pFast ("reverbMix") * 0.01f;
    const int mode = (int) pFast ("reverbMode");
    reverb.setParameters (mode, pFast ("reverbDecay"), pFast ("reverbCharacter"));

    // Feed the reverb at unity and apply the smoothed power/send gain only on
    // the return. This avoids unintentionally multiplying the power ramp twice.
    for (int i = 0; i < ns; ++i)
    {
        const float inL = sendSource.getSample (0, i);
        const float inR = nc > 1 ? sendSource.getSample (1, i) : inL;
        float wetL = 0.0f, wetR = 0.0f;
        reverb.processSample (inL, inR, wetL, wetR);
        tempA.setSample (0, i, wetL);
        tempA.setSample (1, i, wetR);
    }

    const float attack = onePoleCoeff (2.0f, sr), release = onePoleCoeff (180.0f, sr);
    for (int i = 0; i < ns; ++i)
    {
        reverbPowerMix += reverbPowerCoeff * (powerTarget - reverbPowerMix);
        const float dryL = sendSource.getSample (0, i);
        const float dryR = nc > 1 ? sendSource.getSample (1, i) : dryL;
        const float dryLevel = nc > 1 ? 0.5f * (std::abs (dryL) + std::abs (dryR)) : std::abs (dryL);
        const float detectorCoeff = dryLevel > reverbDuckEnvelope[0] ? attack : release;
        reverbDuckEnvelope[0] += detectorCoeff * (dryLevel - reverbDuckEnvelope[0]);
        const float duckAmount = pFast ("reverbDucking") * 0.01f;
        const float duck = 1.0f - duckAmount * juce::jlimit (0.0f, 1.0f, reverbDuckEnvelope[0] * 3.0f);
        const float wetGain = send * reverbPowerMix * duck;
        const float wetL = tempA.getSample (0, i) * wetGain;
        const float wetR = tempA.getSample (1, i) * wetGain;

        if (nc > 1)
        {
            buffer.setSample (0, i, buffer.getSample (0, i) + wetL);
            buffer.setSample (1, i, buffer.getSample (1, i) + wetR);
        }
        else
            buffer.setSample (0, i, buffer.getSample (0, i) + 0.5f * (wetL + wetR));
    }
}

void UltAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    // A non-blocking lifecycle guard: never spin or take a mutex on the audio
    // thread while the host is removing/deactivating this processor.
    if (! resourcesPrepared.load (std::memory_order_acquire))
    {
        buffer.clear();
        return;
    }

    juce::ignoreUnused (midi);
    juce::ScopedNoDenormals noDenormals;
    const int inputChannels = getTotalNumInputChannels();
    const int outputChannels = getTotalNumOutputChannels();
    const int nc = juce::jmin (2, outputChannels);
    const int ns = buffer.getNumSamples();
    if (nc == 0 || ns == 0) return;
    if (inputChannels == 1 && outputChannels == 2)
        buffer.copyFrom (1, 0, buffer, 0, 0, ns); // mono source -> centred stereo image

    consumeChainOrder(); // one lock-free snapshot per audio block; the UI publishes only after mouse-up
    const bool visualize = visualizationActive.load (std::memory_order_relaxed);
    if (visualize)
    {
    float peakIn = 0.0f;
    for (int ch = 0; ch < juce::jmin (2, inputChannels); ++ch)
        peakIn = juce::jmax (peakIn, buffer.getMagnitude (ch, 0, ns));
    inputMeter.store (peakIn, std::memory_order_relaxed);

    // Clear only presence flags; peak values remain valid until their next update.
    // This avoids any allocation or UI lock on the real-time audio thread.
    for (auto& present : stagePresent)
        present.store (false, std::memory_order_relaxed);

    }

    const float inGain = dbToGain (pFast ("inputGain"));
    buffer.applyGain (inGain);

    for (int index = 0; index < audioOrderCount; ++index)
    {
        const int id = audioOrder[(size_t) index];
        if (id < 0 || id >= NumEffects) continue;
        if (id == Modulation)
        {
            float stageIn = 0.0f;
            if (visualize)
                for (int ch = 0; ch < nc; ++ch)
                stageIn = juce::jmax (stageIn, buffer.getMagnitude (ch, 0, ns));
            if (visualize) stageInputPeak[(size_t) id].store (stageIn, std::memory_order_relaxed);
            if (visualize) stagePresent[(size_t) id].store (true, std::memory_order_relaxed);
            processModulation (buffer); // its own parallel wet/power crossfade
            float stageOut = 0.0f;
            if (visualize)
                for (int ch = 0; ch < nc; ++ch)
                stageOut = juce::jmax (stageOut, buffer.getMagnitude (ch, 0, ns));
            if (visualize) stageOutputPeak[(size_t) id].store (stageOut, std::memory_order_relaxed);
            if (visualize) stageReductionDb[(size_t) id].store (0.0f, std::memory_order_relaxed);
            continue;
        }

        // Capture the signal at this exact position in the processing chain.
        float stageIn = 0.0f;
        if (visualize)
            for (int ch = 0; ch < nc; ++ch)
            stageIn = juce::jmax (stageIn, buffer.getMagnitude (ch, 0, ns));
        if (visualize) stageInputPeak[(size_t) id].store (stageIn, std::memory_order_relaxed);
        if (visualize) stagePresent[(size_t) id].store (true, std::memory_order_relaxed);

        if (visualize && id == DeEsser)
        {
            auto write = deInputCount.load (std::memory_order_relaxed);
            for (int i = 0; i < ns; ++i)
            {
                float sample = buffer.getSample (0, i);
                if (nc > 1) sample = 0.5f * (sample + buffer.getSample (1, i));
                deInputSamples[(size_t) (write++ % eqSpectrumSize)].store (sample, std::memory_order_relaxed);
            }
            deSpectrumSampleRate.store (getSampleRate(), std::memory_order_relaxed);
            deInputCount.store (write, std::memory_order_release);
        }
        const bool enabled = isEffectEnabled (id);
        float mix = bypassMix[(size_t) id].load (std::memory_order_relaxed);
        const float target = enabled ? 1.0f : 0.0f;
        if (! enabled && mix < 0.0001f)
        {
            if (visualize) stageOutputPeak[(size_t) id].store (stageIn, std::memory_order_relaxed);
            if (visualize && id == EQ)
            {
                auto write = eqSpectrumWriteCount.load (std::memory_order_relaxed);
                for (int i = 0; i < ns; ++i)
                {
                    float value = buffer.getSample (0, i);
                    if (nc > 1) value = 0.5f * (value + buffer.getSample (1, i));
                    eqSpectrumSamples[(size_t) (write++ % eqSpectrumSize)].store (value, std::memory_order_relaxed);
                }
                eqSpectrumSampleRate.store (getSampleRate(), std::memory_order_relaxed);
                eqSpectrumWriteCount.store (write, std::memory_order_release);
            }
            if (visualize && id == DeEsser)
            {
                auto write = deOutputCount.load (std::memory_order_relaxed);
                for (int i = 0; i < ns; ++i)
                {
                    float sample = buffer.getSample (0, i);
                    if (nc > 1) sample = 0.5f * (sample + buffer.getSample (1, i));
                    deOutputSamples[(size_t) (write++ % eqSpectrumSize)].store (sample, std::memory_order_relaxed);
                }
                deOutputCount.store (write, std::memory_order_release);
            }
            if (visualize) stageReductionDb[(size_t) id].store (0.0f, std::memory_order_relaxed);
            continue;
        }

        const bool canCrossfade = ns <= bypassDry.getNumSamples();
        if (canCrossfade)
        {
            bypassDry.clear (0, 0, ns); bypassDry.clear (1, 0, ns);
            for (int ch = 0; ch < nc; ++ch) bypassDry.copyFrom (ch, 0, buffer, ch, 0, ns);
            if (nc == 1) bypassDry.copyFrom (1, 0, bypassDry, 0, 0, ns);
        }

        switch (id)
        {
            case Gate: processGate (buffer); break;
            case Autotune: processAutotune (buffer); break;
            case OctaveShifterId: processOctaveShifter (buffer); break;
            case EQ: processEq (buffer); break;
            case Compressor: processCompressor (buffer); break;
            case DeEsser: processDeEsser (buffer); break;
            case Saturator: processSaturator (buffer); break;
            case OTT: processOtt (buffer); break;
            default: break;
        }

        if (canCrossfade)
        {
            for (int i = 0; i < ns; ++i)
            {
                mix += bypassCoeff * (target - mix);
                for (int ch = 0; ch < nc; ++ch)
                {
                    const float dry = bypassDry.getSample (ch, i);
                    const float wet = buffer.getSample (ch, i);
                    buffer.setSample (ch, i, dry * (1.0f - mix) + wet * mix);
                }
            }
        }
        else
            mix = target;
        if (visualize && id == Autotune)
        {
            auto write = tuneOutputCount.load (std::memory_order_relaxed);
            for (int i = 0; i < ns; ++i)
            {
                float sample = buffer.getSample (0, i);
                if (nc > 1) sample = 0.5f * (sample + buffer.getSample (1, i));
                tuneOutputSamples[(size_t) (write++ % tuneSpectrumSize)].store (sample, std::memory_order_relaxed);
            }
            tuneOutputSampleRate.store (getSampleRate(), std::memory_order_relaxed);
            tuneOutputCount.store (write, std::memory_order_release);
        }
        float stageOut = 0.0f;
        if (visualize)
            for (int ch = 0; ch < nc; ++ch)
            stageOut = juce::jmax (stageOut, buffer.getMagnitude (ch, 0, ns));
        if (visualize) stageOutputPeak[(size_t) id].store (stageOut, std::memory_order_relaxed);
        if (visualize && id == DeEsser)
        {
            auto write = deOutputCount.load (std::memory_order_relaxed);
            for (int i = 0; i < ns; ++i)
            {
                float sample = buffer.getSample (0, i);
                if (nc > 1) sample = 0.5f * (sample + buffer.getSample (1, i));
                deOutputSamples[(size_t) (write++ % eqSpectrumSize)].store (sample, std::memory_order_relaxed);
            }
            deOutputCount.store (write, std::memory_order_release);
        }
        if (visualize && id == EQ)
        {
            // Copy the post-bypass EQ output. Read only the first two channels,
            // combine to mono as requested for the single Pro-Q-style spectrum.
            auto write = eqSpectrumWriteCount.load (std::memory_order_relaxed);
            for (int i = 0; i < ns; ++i)
            {
                float value = buffer.getSample (0, i);
                if (nc > 1) value = 0.5f * (value + buffer.getSample (1, i));
                eqSpectrumSamples[(size_t) (write++ % eqSpectrumSize)].store (value, std::memory_order_relaxed);
            }
            eqSpectrumSampleRate.store (getSampleRate(), std::memory_order_relaxed);
            eqSpectrumWriteCount.store (write, std::memory_order_release);
        }
        // This is a block peak-level difference, NOT compressor gain reduction.
        // GR is kept separately by the compressor's detector.
        const float measuredGr = ! visualize ? 0.0f : (id == Compressor)
            ? compressorBlockGrDb * juce::jlimit (0.0f, 1.0f, mix)
            : id == Gate ? (enabled ? gateBlockGrDb : 0.0f)
            : id == DeEsser ? (enabled ? deBlockGrDb : 0.0f)
            : (enabled && stageIn > 1.0e-8f
                ? juce::jmax (0.0f, 20.0f * std::log10 (stageIn / juce::jmax (stageOut, 1.0e-8f)))
                : 0.0f);
        if (visualize) stageReductionDb[(size_t) id].store (measuredGr, std::memory_order_relaxed);
        if (id == Compressor)
            if (visualize) gainReductionMeter.store (measuredGr, std::memory_order_relaxed);
        bypassMix[(size_t) id].store (mix, std::memory_order_relaxed);
    }

    bool hasAutotune = false, hasOctave = false;
    for (int i = 0; i < audioOrderCount; ++i)
    {
        hasAutotune = hasAutotune || audioOrder[(size_t) i] == Autotune;
        hasOctave = hasOctave || audioOrder[(size_t) i] == OctaveShifterId;
    }
    int requestedLatency = 0;
    if (hasAutotune && (enabledParam ("autotuneOn") || bypassMix[(size_t) Autotune].load (std::memory_order_relaxed) > 0.001f))
        requestedLatency += autotune.getLatencySamples();
    if (hasOctave && (enabledParam ("octaveOn") || bypassMix[(size_t) OctaveShifterId].load (std::memory_order_relaxed) > 0.001f))
        requestedLatency += octave.getLatencySamples();
    if (engineLatencyRequested.exchange (requestedLatency, std::memory_order_relaxed) != requestedLatency)
        updateLatencyAsync();

    if (ns <= sendSource.getNumSamples())
    {
        copyToStereoScratch (sendSource, buffer, ns);
        double bpm = 120.0;
        if (auto* head = getPlayHead())
        {
            if (auto pos = head->getPosition())
                if (auto tempo = pos->getBpm()) bpm = *tempo;
        }
        processDelaySend (buffer, bpm);
        processReverbSend (buffer);
    }

    /* parallel send processing is complete; Output Gain is applied after both returns */
    buffer.applyGain (dbToGain (pFast ("outputGain")));
    if (visualize)
    {
    float peakOut = 0.0f;
    for (int ch = 0; ch < nc; ++ch)
        peakOut = juce::jmax (peakOut, buffer.getMagnitude (ch, 0, ns));
    outputMeter.store (peakOut, std::memory_order_relaxed);
    }
}


void UltAudioProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    writeState (dest, true);
}

void UltAudioProcessor::writeState (juce::MemoryBlock& dest, bool includeWindow)
{
    auto state = apvts.copyState();
    if (includeWindow) { state.setProperty ("ultEditorWidth", editorWidth.load(), nullptr); state.setProperty ("ultEditorHeight", editorHeight.load(), nullptr); }
    state.setProperty ("ultSchemaVersion", 9, nullptr);
    juce::ValueTree chain ("ULT_CHAIN");
    const auto order = getChainOrder();
    juce::String encoded;
    for (auto id : order) { if (encoded.isNotEmpty()) encoded << ","; encoded << id; }
    chain.setProperty ("order", encoded, nullptr);
    state.addChild (chain, -1, nullptr);
    if (auto xml = state.createXml()) copyXmlToBinary (*xml, dest);
}

void UltAudioProcessor::setStateInformation (const void* data, int size)
{
    restoreState (data, size, true);
}

void UltAudioProcessor::restoreState (const void* data, int size, bool restoreWindow)
{
    // Reject corrupt, empty, oversized, or unrelated state blobs before APVTS
    // is touched. Hosts may call this while restoring a project.
    constexpr int maxStateBytes = 16 * 1024 * 1024;
    if (data == nullptr || size <= 0 || size > maxStateBytes)
        return;

    std::unique_ptr<juce::XmlElement> xml (getXmlFromBinary (data, size));
    if (xml == nullptr)
        return;

    auto state = juce::ValueTree::fromXml (*xml);
    if (! state.isValid() || ! state.hasType (apvts.state.getType()))
        return;

    std::vector<int> order;
    bool hasExplicitChain = false;
    float legacyModMode = 0.0f;

    for (int i = state.getNumChildren(); --i >= 0;)
    {
        const auto child = state.getChild (i);
        if (child.hasType ("ULT_CHAIN"))
        {
            if (! hasExplicitChain)
            {
                hasExplicitChain = true;
                const auto encoded = child.getProperty ("order").toString();
                juce::StringArray tokens;
                tokens.addTokens (encoded, ",", "");
                for (const auto& rawToken : tokens)
                {
                    const auto token = rawToken.trim();
                    if (token.isEmpty() || ! token.containsOnly ("0123456789"))
                        continue;

                    const int id = token.getIntValue();
                    if (id >= 0 && id < NumEffects && id != Resonance)
                        order.push_back (id);
                }
            }
            state.removeChild (i, nullptr);
            continue;
        }

        const auto parameterId = child.getProperty ("id").toString();
        if (parameterId == "modMode")
            legacyModMode = (float) child.getProperty ("value", 0.0f);

        if (parameterId == "modMode" || parameterId == "monitorMode"
            || parameterId == "resonanceOn" || parameterId == "resonanceAmount"
            || parameterId == "resonanceThreshold")
            state.removeChild (i, nullptr);
    }

    const int incomingSchema = (int) state.getProperty ("ultSchemaVersion", 0);
    if (restoreWindow)
    {
        editorWidth.store ((int) state.getProperty ("ultEditorWidth", 0));
        editorHeight.store ((int) state.getProperty ("ultEditorHeight", 0));
    }
    state.removeProperty ("ultEditorWidth", nullptr);
    state.removeProperty ("ultEditorHeight", nullptr);
    apvts.replaceState (state);
    if (incomingSchema < 9)
        for (int i = 1; i <= 5; ++i)
            if (auto* band = apvts.getParameter ("eqBandEnabled" + juce::String (i)))
                band->setValueNotifyingHost (1.0f);

    // v0.7 adds explicit cut-slope parameters. Older states did not contain
    // these IDs, so migrate both outer bands to the agreed 24 dB/oct default.
    if (incomingSchema < 8)
    {
        for (const auto* id : { "eqSlope1", "eqSlope5" })
            if (auto* slope = apvts.getParameter (id))
                slope->setValueNotifyingHost (slope->convertTo0to1 (2.0f));
    }

    if (incomingSchema < 7)
    {
        if (auto* amount = apvts.getParameter ("deAmount"))
            amount->setValueNotifyingHost (amount->convertTo0to1 (75.0f));
        if (auto* original = apvts.getParameter ("doubleOriginal"))
            original->setValueNotifyingHost (original->convertTo0to1 (100.0f));
    }

    if (incomingSchema < 6)
    {
        // Legacy Choice values can be represented as a raw index or a
        // normalized 0..1 value. Chorus was index 2 in the old four-mode list.
        const int newMode = (legacyModMode == 2.0f
                             || (legacyModMode > 0.5f && legacyModMode < 0.85f)) ? 1 : 0;
        if (auto* modeParameter = apvts.getParameter ("modModeV06"))
            modeParameter->setValueNotifyingHost (modeParameter->convertTo0to1 ((float) newMode));
    }

    if (! hasExplicitChain)
    {
        // v0.3 fixed-chain migration. Removed Resonance is intentionally absent.
        const bool oldDoublerOn = pFast ("doublerOn") >= 0.5f;
        auto setMigrated = [this] (const char* id, float value)
        {
            if (auto* parameter = apvts.getParameter (id))
                parameter->setValueNotifyingHost (parameter->convertTo0to1 (value));
        };
        setMigrated ("modOn", oldDoublerOn ? 1.0f : 0.0f);
        if (oldDoublerOn)
        {
            setMigrated ("modModeV06", 0.0f);
            setMigrated ("modSend", pFast ("doubleMix"));
        }

        order = { EQ, Compressor, DeEsser, Saturator, Modulation };
    }

    setChainOrder (order);

    // Reinitialize all bypass ramps from the restored APVTS values. The
    // reserved Resonance slot maps to no parameter and remains safely bypassed.
    for (int i = 0; i < NumEffects; ++i)
        bypassMix[(size_t) i].store (isEffectEnabled (i) ? 1.0f : 0.0f, std::memory_order_relaxed);

    modPowerResetRequested.store (true, std::memory_order_release);
}

juce::AudioProcessorEditor* UltAudioProcessor::createEditor()
{
    return new UltAudioProcessorEditor (*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new UltAudioProcessor(); }
