#include "PluginEditor.h"
#include "BinaryData.h"
#include <cmath>
#include <algorithm>
#include <limits>

namespace
{
// Monochrome Liquid Glass tokens: the iOS reference is translated into a
// desktop instrument surface, not copied as a mobile control layout.
const juce::Colour bg           { 0xff050505 };
const juce::Colour panel        { 0xff101010 };
const juce::Colour panelTop     { 0xff292929 };
const juce::Colour panelRaised  { 0xff202020 };
const juce::Colour border       { 0x88ffffff };
const juce::Colour borderSoft   { 0x38ffffff };
const juce::Colour text         { 0xfff7f7f7 };
const juce::Colour muted        { 0xffb0b0b0 };
const juce::Colour accent       { 0xffa6ff00 };
const juce::Colour accentDeep   { 0xffa6ff00 };

void setParameter (UltAudioProcessor& processor, const juce::String& id, float value)
{
    if (auto* parameter = processor.apvts.getParameter (id))
    {
        parameter->beginChangeGesture();
        parameter->setValueNotifyingHost (parameter->convertTo0to1 (value));
        parameter->endChangeGesture();
    }
}

float getParameter (UltAudioProcessor& processor, const juce::String& id)
{
    if (auto* p = processor.apvts.getRawParameterValue (id)) return p->load (std::memory_order_relaxed);
    return 0.0f;
}

juce::String bandId (int band) { return juce::String (juce::jlimit (0, 4, band) + 1); }

juce::NormalisableRange<double> makeEqFrequencySliderRange()
{
    constexpr double start = 20.0;
    constexpr double pivot = 1000.0;
    constexpr double end = 20000.0;
    constexpr double extraLowFrequencyExponent = 1.0;

    const double span = end - start;
    const double pivotProportion = (pivot - start) / span;
    const double oldSkewFactor = std::log (0.5) / std::log (pivotProportion);
    const double oldValueExponent = 1.0 / oldSkewFactor;

    auto lowerCurve = [=] (double t)
    {
        // Stay closer to the minimum at low frequencies, but meet the old
        // curve with the same slope at 1 kHz to avoid a speed discontinuity.
        const double exponent = oldValueExponent + extraLowFrequencyExponent;
        return std::pow (t, exponent)
             * (1.0 + extraLowFrequencyExponent * (1.0 - t));
    };

    auto fromProportion = [=] (double rangeStart, double rangeEnd, double proportion)
    {
        juce::ignoreUnused (rangeStart, rangeEnd);
        const double p = juce::jlimit (0.0, 1.0, proportion);

        if (p <= 0.5)
            return start + (pivot - start) * lowerCurve (p * 2.0);

        // Preserve the previous 1 kHz..20 kHz knob response exactly.
        return start + span * std::pow (p, oldValueExponent);
    };

    auto toProportion = [=] (double rangeStart, double rangeEnd, double value)
    {
        juce::ignoreUnused (rangeStart, rangeEnd);
        const double v = juce::jlimit (start, end, value);

        if (v <= pivot)
        {
            if (v <= start) return 0.0;
            if (v >= pivot) return 0.5;

            const double normalized = (v - start) / (pivot - start);
            double low = 0.0, high = 1.0;

            // Invert the monotonic lower curve accurately without a lookup
            // table or any allocations.
            for (int i = 0; i < 28; ++i)
            {
                const double mid = 0.5 * (low + high);
                if (lowerCurve (mid) < normalized) low = mid;
                else high = mid;
            }

            return 0.25 * (low + high);
        }

        return std::pow ((v - start) / span, 1.0 / oldValueExponent);
    };

    auto snap = [] (double rangeStart, double rangeEnd, double value)
    {
        return juce::jlimit (rangeStart, rangeEnd, value);
    };

    return { start, end, fromProportion, toProportion, snap };
}

const juce::StringArray& factoryPresetNames()
{
    static const juce::StringArray names {
        "Clean Vocal", "Warm Tube", "Modern Rap", "Wide Chorus", "Airy Space", "Aggressive OTT", "iMan"
    };
    return names;
}

void drawGlassPanel (juce::Graphics& g, juce::Rectangle<float> bounds, float radius)
{
    // ULT 0.9 Figma: solid flat surface, no gradients or reflections.
    g.setColour (juce::Colour (0xff111111));
    g.fillRoundedRectangle (bounds, radius);
    g.setColour (juce::Colour (0xff414141));
    g.drawRoundedRectangle (bounds.reduced (0.5f), radius, 1.0f);
}

float gainToDbSafe (float gain)
{
    return juce::Decibels::gainToDecibels (juce::jmax (0.0f, gain), -90.0f);
}

juce::Typeface::Ptr interRegularTypeface()
{
    static auto face = juce::Typeface::createSystemTypefaceFor (
        BinaryData::InterRegular_otf, (size_t) BinaryData::InterRegular_otfSize);
    return face;
}

juce::Typeface::Ptr interSemiBoldTypeface()
{
    static auto face = juce::Typeface::createSystemTypefaceFor (
        BinaryData::InterSemiBold_otf, (size_t) BinaryData::InterSemiBold_otfSize);
    return face;
}

juce::Typeface::Ptr interBoldTypeface()
{
    static auto face = juce::Typeface::createSystemTypefaceFor (
        BinaryData::InterBold_otf, (size_t) BinaryData::InterBold_otfSize);
    return face;
}

juce::Font interFont (float height, bool bold = false, bool heavy = false)
{
    const auto face = heavy ? interBoldTypeface() : (bold ? interSemiBoldTypeface() : interRegularTypeface());
    return juce::Font (juce::FontOptions (face).withHeight (height));
}
}

namespace {
class UltAccentPicker final : public juce::Component
{
public:
    UltAccentPicker (juce::Colour colour, std::function<void (juce::Colour)> callback)
        : original (colour), changed (std::move (callback))
    {
        hue = colour.getHue(); saturation = colour.getSaturation(); brightness = colour.getBrightness();
        setSize (440, 300);
        ok.setLookAndFeel (&pickerLook);
        ok.setColour (juce::TextButton::textColourOffId, colour);
        addAndMakeVisible (ok);
        ok.setBounds (334, 246, 94, 32);
        ok.onClick = [this] { if (auto* box = findParentComponentOfClass<juce::CallOutBox>()) box->dismiss(); };
        plane = juce::Image (juce::Image::RGB, 280, 240, false, juce::SoftwareImageType());
        for (int y = 0; y < 240; ++y)
            for (int x = 0; x < 280; ++x)
                plane.setPixelAt (x, y, juce::Colour::fromHSV ((float) x / 279.0f, 1.0f - (float) y / 239.0f, 1.0f, 1.0f));
    }
    ~UltAccentPicker() override { ok.setLookAndFeel (nullptr); }
    void paint (juce::Graphics& g) override
    {
        g.fillAll (juce::Colour (0xff111111));
        g.setColour (juce::Colours::white);
        g.drawImage (plane, field.toFloat());
        g.setColour (juce::Colours::black.withAlpha (1.0f - brightness)); g.fillRect (field);
        auto full = juce::Colour::fromHSV (hue, saturation, 1.0f, 1.0f);
        g.setGradientFill (juce::ColourGradient (full, 0.0f, (float) field.getY(), juce::Colours::black, 0.0f, (float) field.getBottom(), false));
        g.fillRect (value);
        const float x = field.getX() + hue * (field.getWidth() - 1), y = field.getY() + (1.0f - saturation) * (field.getHeight() - 1);
        g.setColour (juce::Colours::black); g.drawEllipse (x - 6, y - 6, 12, 12, 3);
        g.setColour (juce::Colours::white); g.drawEllipse (x - 6, y - 6, 12, 12, 1);
        const float vy = value.getY() + (1.0f - brightness) * (value.getHeight() - 1);
        g.drawRect (value.getX() - 2, (int) vy - 2, value.getWidth() + 4, 5, 1);
        g.setFont (interFont (12.0f, true));
        g.drawText ("NEW", 334, 18, 94, 20, juce::Justification::centred);
        g.setColour (colour()); g.fillRect (334, 40, 94, 66);
        g.setColour (original); g.fillRect (334, 106, 94, 66);
        g.setColour (juce::Colours::white); g.drawText ("CURRENT", 334, 176, 94, 20, juce::Justification::centred);
        g.drawText ("#" + colour().toDisplayString (false), 334, 204, 94, 20, juce::Justification::centred);
        g.drawText ("HUE / SATURATION", 12, 268, 280, 20, juce::Justification::centred);
    }
    void mouseDown (const juce::MouseEvent& e) override
    {
        mode = field.contains (e.getPosition()) ? 1 : value.contains (e.getPosition()) ? 2 : 0;
        mouseDrag (e);
    }
    void mouseDrag (const juce::MouseEvent& e) override
    {
        if (mode == 0) return;
        if (mode == 1) {
            hue = juce::jlimit (0.0f, 0.999999f, (float) (e.x - field.getX()) / (field.getWidth() - 1));
            saturation = 1.0f - juce::jlimit (0.0f, 1.0f, (float) (e.y - field.getY()) / (field.getHeight() - 1));
        } else brightness = 1.0f - juce::jlimit (0.0f, 1.0f, (float) (e.y - value.getY()) / (value.getHeight() - 1));
        ok.setColour (juce::TextButton::textColourOffId, colour());
        changed (colour()); repaint();
    }
    void mouseUp (const juce::MouseEvent&) override { mode = 0; }
private:
    juce::Colour colour() const { return juce::Colour::fromHSV (hue, saturation, brightness, 1.0f); }
    juce::Colour original;
    std::function<void (juce::Colour)> changed;
    UltLookAndFeel pickerLook;
    juce::TextButton ok { "OK" };
    juce::Image plane;
    juce::Rectangle<int> field { 12, 20, 280, 240 }, value { 302, 20, 20, 240 };
    float hue = 0, saturation = 0, brightness = 1;
    int mode = 0;
};
}

//==============================================================================
UltLookAndFeel::UltLookAndFeel()
{
    setDefaultSansSerifTypefaceName ("Inter");
    setColour (juce::Slider::rotarySliderFillColourId, accent);
    setColour (juce::Slider::rotarySliderOutlineColourId, borderSoft);
    setColour (juce::Slider::textBoxTextColourId, text);
    setColour (juce::Slider::textBoxBackgroundColourId, panelRaised);
    setColour (juce::Slider::textBoxOutlineColourId, border);
    setColour (juce::ComboBox::backgroundColourId, panelRaised);
    setColour (juce::ComboBox::textColourId, text);
    setColour (juce::ComboBox::outlineColourId, border);
    setColour (juce::PopupMenu::backgroundColourId, panelRaised);
    setColour (juce::PopupMenu::textColourId, text);
    setColour (juce::TextButton::buttonColourId, panelRaised);
    setColour (juce::TextButton::textColourOffId, text);
    setColour (juce::ToggleButton::textColourId, text);
}

juce::Typeface::Ptr UltLookAndFeel::getTypefaceForFont (const juce::Font& font)
{
    if (font.isBold())
        return font.getHeight() >= 30.0f ? interBoldTypeface() : interSemiBoldTypeface();
    return interRegularTypeface();
}

juce::Font UltLookAndFeel::getTextButtonFont (juce::TextButton& button, int buttonHeight)
{
    if (button.getComponentID() == "addModuleClose") return interFont (22.0f, true);
    const float scale = juce::jmax (0.2f, buttonHeight / 40.0f);
    if (button.getComponentID() == "brandLink") return interFont (46.0f * buttonHeight / 48.0f, true, true);
    if (button.getComponentID() == "signatureLink") return interFont (17.0f * buttonHeight / 22.0f, true);
    return interFont (13.0f * scale, true);
}

juce::Font UltLookAndFeel::getLabelFont (juce::Label& label)
{
    if (auto* slider = dynamic_cast<juce::Slider*> (label.getParentComponent()))
        return interFont (juce::jlimit (13.0f, 28.0f, (float) slider->getHeight() * 0.17f), true);
    return interFont (juce::jlimit (5.0f, 64.0f, label.getHeight() * 0.67f), label.getFont().isBold());
}

juce::Slider::SliderLayout UltLookAndFeel::getSliderLayout (juce::Slider& slider)
{
    auto layout = juce::LookAndFeel_V4::getSliderLayout (slider);
    if (slider.getSliderStyle() == juce::Slider::RotaryHorizontalVerticalDrag
        && ! layout.textBoxBounds.isEmpty())
    {
        // Shorten the dead space above the numeric value for ALL rotary controls,
        // including INPUT GAIN and OUTPUT GAIN.
        const int offset = juce::jmin (11, juce::jmax (0, layout.sliderBounds.getHeight() / 7));
        layout.textBoxBounds.translate (0, -offset);
        layout.sliderBounds.setHeight (layout.sliderBounds.getHeight() + offset);
    }
    return layout;
}

juce::Font UltLookAndFeel::getComboBoxFont (juce::ComboBox& combo)
{
    return interFont (juce::jmax (5.0f, combo.getHeight() * 0.4f), true);
}

juce::Font UltLookAndFeel::getPopupMenuFont()
{
    return interFont (13.0f * popupScale * popupFontMultiplier, false);
}

void UltLookAndFeel::drawPopupMenuBackground (juce::Graphics& g, int w, int h)
{
    g.fillAll (bg);
    auto r = juce::Rectangle<float> (0, 0, (float) w, (float) h).reduced (0.5f);
    g.setColour (panel);
    g.fillRoundedRectangle (r, 7.0f * popupScale);
    g.setColour (juce::Colour (0xff454545));
    g.drawRoundedRectangle (r, 7.0f * popupScale, 1.0f);
}

void UltLookAndFeel::drawPopupMenuItem (juce::Graphics& g, const juce::Rectangle<int>& area,
    bool separator, bool active, bool highlighted, bool ticked, bool submenu,
    const juce::String& item, const juce::String& shortcut, const juce::Drawable* image,
    const juce::Colour* customColour)
{
    juce::ignoreUnused (customColour);
    auto r = area.reduced (4, 1);
    const auto a = findColour (juce::Slider::rotarySliderFillColourId);
    if (separator) { g.setColour (borderSoft); g.fillRect (r.withSizeKeepingCentre (r.getWidth() - 8, 1)); return; }
    if (active && (highlighted || ticked))
    {
        g.setColour (panel.interpolatedWith (a, highlighted ? 0.22f : 0.13f));
        g.fillRoundedRectangle (r.toFloat(), 4.0f * popupScale);
    }
    r.reduce (8, 0);
    g.setColour ((ticked ? a : text).withMultipliedAlpha (active ? 1.0f : 0.4f));
    g.setFont (getPopupMenuFont());
    if (image != nullptr) image->drawWithin (g, r.removeFromLeft (r.getHeight()).toFloat(), juce::RectanglePlacement::centred, active ? 1.0f : 0.4f);
    if (submenu) g.drawText (">", r.removeFromRight (16), juce::Justification::centred);
    if (shortcut.isNotEmpty()) g.drawText (shortcut, r.removeFromRight (juce::jmin (r.getWidth()/2, 100)), juce::Justification::centredRight);
    g.drawFittedText (item, r, juce::Justification::centredLeft, 1);
}

void UltLookAndFeel::drawButtonText (juce::Graphics& g, juce::TextButton& button,
                                     bool isHighlighted, bool isDown)
{
    if (button.getComponentID() == "brandLink" || button.getComponentID() == "signatureLink")
    {
        const auto colourId = button.getToggleState() ? juce::TextButton::textColourOnId
                                                       : juce::TextButton::textColourOffId;
        g.setColour (button.findColour (colourId).withAlpha (isDown ? 0.72f : 1.0f));
        g.setFont (getTextButtonFont (button, button.getHeight()));
        g.drawText (button.getButtonText(), button.getLocalBounds(),
                    juce::Justification::centredLeft, true);
        return;
    }

    juce::LookAndFeel_V4::drawButtonText (g, button, isHighlighted, isDown);
}

void UltLookAndFeel::drawRotarySlider (juce::Graphics& g, int x, int y, int width, int height,
                                       float position, float startAngle, float endAngle,
                                       juce::Slider& slider)
{
    const bool mainGain = slider.getComponentID() == "fixed_inputGain" || slider.getComponentID() == "fixed_outputGain";
    const float reserve = mainGain ? 5.0f : 24.0f;
    const float box = juce::jmin ((float) width, (float) height - reserve);
    const float diameter = juce::jmax (28.0f, box - 3.0f);
    const float radius = diameter * 0.5f - 2.0f;
    const float cx = (float) x + (float) width * 0.5f;
    const float cy = (float) y + juce::jmax (0.0f, (float) height - reserve) * 0.5f + 3.0f;
    const float angle = startAngle + position * (endAngle - startAngle);

    g.setColour (juce::Colour (0xff090909));
    g.fillEllipse (cx - radius, cy - radius, radius * 2.0f, radius * 2.0f);
    g.setColour (juce::Colour (0xff888888));
    g.drawEllipse (cx - radius, cy - radius, radius * 2.0f, radius * 2.0f, 1.5f);

    juce::Path track;
    track.addCentredArc (cx, cy, radius - 3.0f, radius - 3.0f, 0.0f, startAngle, endAngle, true);
    g.setColour (juce::Colour (0xff5a5a5a));
    g.strokePath (track, juce::PathStrokeType (4.0f, juce::PathStrokeType::curved,
                                               juce::PathStrokeType::rounded));

    juce::Path value;
    value.addCentredArc (cx, cy, radius - 3.0f, radius - 3.0f, 0.0f, startAngle, angle, true);
    g.setColour (findColour (juce::Slider::rotarySliderFillColourId));
    g.strokePath (value, juce::PathStrokeType (4.0f, juce::PathStrokeType::curved,
                                               juce::PathStrokeType::rounded));

    // One crisp pointer and a small central bearing keep the value legible.
    const float pointerLength = radius * 0.56f;
    juce::Path pointer;
    pointer.startNewSubPath (cx + std::sin (angle) * 3.0f, cy - std::cos (angle) * 3.0f);
    pointer.lineTo (cx + std::sin (angle) * pointerLength, cy - std::cos (angle) * pointerLength);
    g.setColour (juce::Colours::white);
    g.strokePath (pointer, juce::PathStrokeType (2.2f, juce::PathStrokeType::curved,
                                                 juce::PathStrokeType::rounded));
    g.fillEllipse (cx - 2.0f, cy - 2.0f, 4.0f, 4.0f);
}

void UltLookAndFeel::drawButtonBackground (juce::Graphics& g, juce::Button& button,
                                           const juce::Colour&, bool highlighted, bool down)
{
    if (button.getComponentID() == "brandLink" || button.getComponentID() == "signatureLink")
        return;

    auto bounds = button.getLocalBounds().toFloat().reduced (0.5f);
    const bool on = button.getToggleState();
    const float radius = 10.0f;
    g.setColour (on ? findColour (juce::Slider::rotarySliderFillColourId) : juce::Colour (0xff111111));
    g.fillRoundedRectangle (bounds, radius);
    g.setColour (on ? findColour (juce::Slider::rotarySliderFillColourId) : juce::Colour (0xff414141));
    g.drawRoundedRectangle (bounds.reduced (0.5f), radius, 1.0f);

}

void UltLookAndFeel::drawComboBox (juce::Graphics& g, int width, int height, bool isButtonDown,
                                   int buttonX, int buttonY, int buttonW, int buttonH, juce::ComboBox& box)
{
    juce::ignoreUnused (buttonX, buttonY, buttonW, buttonH, box);
    auto bounds = juce::Rectangle<float> (0.5f, 0.5f, (float) width - 1.0f, (float) height - 1.0f);
    g.setColour (juce::Colour (0xff090909));
    g.fillRoundedRectangle (bounds, 8.0f);
    g.setColour (border);
    g.drawRoundedRectangle (bounds, 8.0f, 1.0f);
    const float cx = (float) width - 17.0f;
    const float cy = (float) height * 0.5f;
    juce::Path arrow;
    arrow.startNewSubPath (cx - 4.0f, cy - 2.0f);
    arrow.lineTo (cx, cy + 2.0f);
    arrow.lineTo (cx + 4.0f, cy - 2.0f);
    g.setColour (findColour (juce::Slider::rotarySliderFillColourId));
    g.strokePath (arrow, juce::PathStrokeType (1.8f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
}

void UltLookAndFeel::drawToggleButton (juce::Graphics& g, juce::ToggleButton& button, bool highlighted, bool down)
{
    auto bounds = button.getLocalBounds().toFloat().reduced (0.5f);
    const bool on = button.getToggleState();
    g.setColour (on ? findColour (juce::Slider::rotarySliderFillColourId).darker (0.15f) : juce::Colour (0xff171717));
    g.fillRoundedRectangle (bounds, 4.0f);
    g.setColour (on ? findColour (juce::Slider::rotarySliderFillColourId) : juce::Colour (0xff555555));
    g.drawRoundedRectangle (bounds, 4.0f, 1.0f);
    g.setColour (on ? juce::Colours::black : (highlighted || down ? text : muted));
    g.setFont (interFont (12.0f, true));
    g.drawText (button.getButtonText(), bounds.toNearestInt(), juce::Justification::centred);
}

//==============================================================================
void UltAudioProcessorEditor::MeterView::refresh()
{
    const float inDb = gainToDbSafe (processor.inputMeter.load (std::memory_order_relaxed));
    const float outDb = gainToDbSafe (processor.outputMeter.load (std::memory_order_relaxed));
    inputHoldDb = juce::jmax (inDb, inputHoldDb - 0.55f);
    outputHoldDb = juce::jmax (outDb, outputHoldDb - 0.55f);
    // Monotonic clock: independent of repaint and timer frequency.
    const auto now = juce::Time::getMillisecondCounterHiRes();
    if (inDb >= 0.0f) inputClipUntil = now + 3000.0;
    if (outDb >= 0.0f) outputClipUntil = now + 3000.0;
    repaint();
}

void UltAudioProcessorEditor::MeterView::paint (juce::Graphics& g)
{
    auto bounds = getLocalBounds().toFloat();
    drawGlassPanel (g, bounds, 10.0f);
    const float labelW = 32.0f, valueW = 60.0f, gap = 8.0f;
    const float barX = bounds.getX() + labelW + gap;
    const float barW = juce::jmax (40.0f, bounds.getWidth() - labelW - valueW - gap * 2.0f);
    const float rowH = (bounds.getHeight() - 8.0f) * 0.5f;
    const float barH = 7.0f;
    auto drawRow = [&] (float y, const juce::String& label, float gain, float holdDb, bool clipping)
    {
        const float db = gainToDbSafe (gain);
        const float norm = juce::jlimit (0.0f, 1.0f, (db + 60.0f) / 60.0f);
        const float hold = juce::jlimit (0.0f, 1.0f, (holdDb + 60.0f) / 60.0f);
        g.setColour (muted);
        g.setFont (interFont (12.0f, true));
        g.drawText (label, (int) bounds.getX(), (int) (y - 6.0f), (int) labelW, 18, juce::Justification::centred);
        auto track = juce::Rectangle<float> (barX, y, barW, barH);
        g.setColour (juce::Colour (0xff111111));
        g.fillRoundedRectangle (track, 3.0f);
        auto fill = track.withWidth (barW * norm);
        juce::ColourGradient gradient (juce::Colour (0xfff4f4f4), fill.getX(), fill.getY(),
                                       juce::Colour (0xffa0a0a0), fill.getRight(), fill.getY(), false);
        g.setGradientFill (gradient);
        g.fillRoundedRectangle (fill, 3.0f);
        const float holdX = barX + barW * hold;
        g.setColour (text.withAlpha (0.9f));
        g.drawLine (holdX, y - 2.0f, holdX, y + barH + 2.0f, 1.3f);
        g.setColour (muted);
        g.setFont (interFont (12.0f, false));
        if (clipping)
        {
            g.setColour (juce::Colour (0xffff6058));
            g.setFont (interFont (11.0f, true));
            g.drawText ("CLIP", (int) (barX + barW + gap), (int) (y - 6.0f), (int) valueW, 18, juce::Justification::centred);
        }
        else
            g.drawText (juce::String (db, 1) + " dB", (int) (barX + barW + gap), (int) (y - 6.0f), (int) valueW, 18, juce::Justification::centred);
    };
    drawRow (bounds.getY() + 8.0f + rowH * 0.25f, "IN", processor.inputMeter.load (std::memory_order_relaxed), inputHoldDb, juce::Time::getMillisecondCounterHiRes() < inputClipUntil);
    drawRow (bounds.getY() + 8.0f + rowH * 1.25f, "OUT", processor.outputMeter.load (std::memory_order_relaxed), outputHoldDb, juce::Time::getMillisecondCounterHiRes() < outputClipUntil);
}

//==============================================================================
class UltAudioProcessorEditor::AddEffectOverlay final : public juce::Component
{
public:
    explicit AddEffectOverlay (UltAudioProcessorEditor& e) : owner (e)
    {
        setWantsKeyboardFocus (true);
        setTitle ("Add effect");
        setDescription ("Choose an insert effect. Use arrow keys to move, Enter to add, and Escape to close.");
        addAndMakeVisible (closeButton);
        closeButton.setComponentID ("addModuleClose");
        closeButton.setButtonText (juce::String::fromUTF8 ("\xC3\x97"));
        closeButton.setTooltip ("Close effect picker");
        closeButton.onClick = [this] { setVisible (false); };
        updateVisibleCards();
    }

    void setInsertPosition (int p) { insertPosition = p; updateVisibleCards(); repaint(); }

    void paint (juce::Graphics& g) override
    {
        g.fillAll (juce::Colour (0xff050505).withAlpha (0.90f));
        modal = getLocalBounds().withSizeKeepingCentre (920, 470);
        drawGlassPanel (g, modal.toFloat(), 20.0f);
        g.setColour (text);
        g.setFont (interFont (22.0f, true));
        g.drawText ("ADD MODULE", modal.getX() + 28, modal.getY() + 18, 420, 30, juce::Justification::centredLeft);
        g.setColour (muted);
        g.setFont (interFont (12.0f, false));
        g.drawText ("Choose a module to insert at the selected point in your chain.",
                    modal.getX() + 29, modal.getY() + 50, 680, 18, juce::Justification::centredLeft);

        const auto currentChain = owner.processor.getChainOrder();
        for (int i = 0; i < (int) visibleIds.size(); ++i)
        {
            const int id = visibleIds[(size_t) i];
            const auto r = cardBounds (i).toFloat();
            const bool hover = i == hoveredCard;
            const bool alreadyAdded = std::find (currentChain.begin(), currentChain.end(), id) != currentChain.end();
            juce::ColourGradient gradient (alreadyAdded ? juce::Colour (0xff0b0b0b) : (hover ? juce::Colour (0xff414141) : juce::Colour (0xff252525)),
                                           r.getX(), r.getY(), panel, r.getX(), r.getBottom(), false);
            g.setGradientFill (gradient);
            g.fillRoundedRectangle (r, 12.0f);
            g.setColour (alreadyAdded ? juce::Colour (0x22ffffff) : (hover ? getLookAndFeel().findColour (juce::Slider::rotarySliderFillColourId) : borderSoft));
            g.drawRoundedRectangle (r.reduced (0.5f), 12.0f, hover && ! alreadyAdded ? 1.5f : 1.0f);

            auto icon = juce::Rectangle<float> (r.getX() + 13.0f, r.getY() + 17.0f, 38.0f, 38.0f);
            g.setColour (getLookAndFeel().findColour (juce::Slider::rotarySliderFillColourId).withAlpha (0.15f));
            g.fillEllipse (icon);
            g.setColour (borderSoft.withAlpha (0.9f));
            g.drawEllipse (icon, 0.8f);
            g.setColour (alreadyAdded ? juce::Colour (0xff666666) : getLookAndFeel().findColour (juce::Slider::rotarySliderFillColourId));
            g.setFont (interFont (12.0f, true));
            juce::String glyph = "FX";
            if (id == UltAudioProcessor::Autotune) glyph = "AT";
            else if (id == UltAudioProcessor::OctaveShifterId) glyph = juce::String::fromUTF8 ("\xC2\xB1") + "12";
            else if (id == UltAudioProcessor::EQ) glyph = "EQ";
            else if (id == UltAudioProcessor::Compressor) glyph = "FET";
            else if (id == UltAudioProcessor::DeEsser) glyph = "DS";
            else if (id == UltAudioProcessor::OTT) glyph = "OTT";
            else if (id == UltAudioProcessor::Modulation) glyph = "MOD";
            g.drawText (glyph, icon.toNearestInt(), juce::Justification::centred);

            g.setColour (alreadyAdded ? juce::Colour (0xff777777) : text);
            g.setFont (interFont (13.0f, true));
            g.drawText (shortName (id), (int) r.getX() + 62, (int) r.getY() + 13,
                        (int) r.getWidth() - 74, 20, juce::Justification::centredLeft);
            g.setColour (muted);
            g.setFont (interFont (12.0f, false));
            g.drawFittedText (description (id), juce::Rectangle<int> ((int) r.getX() + 62,
                (int) r.getY() + 35, (int) r.getWidth() - 76, 27), juce::Justification::centredLeft, 2);
            if (alreadyAdded)
            {
                g.setColour (muted.withAlpha (0.9f));
                g.setFont (interFont (12.0f, true));
                g.drawText ("IN CHAIN", (int) r.getRight() - 74, (int) r.getBottom() - 21, 64, 12, juce::Justification::centredRight);
            }
            else
            {
                g.setColour (getLookAndFeel().findColour (juce::Slider::rotarySliderFillColourId));
                g.setFont (interFont (19.0f, true));
                g.drawText ("+", (int) r.getRight() - 28, (int) r.getY() + 22, 18, 24, juce::Justification::centred);
            }
        }

        if (visibleIds.empty())
        {
            g.setColour (muted);
            g.setFont (interFont (13.0f, false));
            g.drawText ("No insert effects are available.", modal.withY (modal.getY() + 215).withHeight (28), juce::Justification::centred);
        }
        g.setColour (muted.withAlpha (0.9f));
        g.setFont (interFont (12.0f, true));
        g.drawText (juce::String ("INSERT ENABLED  ") + juce::String::fromUTF8 ("\xE2\x80\xA2") + "  REORDER AFTER INSERTION", modal.getX() + 28,
                    modal.getBottom() - 27, modal.getWidth() - 56, 14, juce::Justification::centredLeft);
    }

    void resized() override
    {
        modal = getLocalBounds().withSizeKeepingCentre (920, 470);
        closeButton.setBounds (modal.getRight() - 52, modal.getY() + 16, 30, 28);
    }

    void mouseMove (const juce::MouseEvent& e) override
    {
        int next = -1;
        for (int i = 0; i < (int) visibleIds.size(); ++i)
            if (cardBounds (i).contains (e.getPosition())) { next = i; break; }
        if (next != hoveredCard) { hoveredCard = next; repaint(); }
    }

    void mouseDown (const juce::MouseEvent& e) override
    {
        if (! modal.contains (e.getPosition())) { setVisible (false); return; }
        for (int i = 0; i < (int) visibleIds.size(); ++i)
            if (cardBounds (i).contains (e.getPosition()))
            {
                addEffect (i);
                return;
            }
    }

    bool keyPressed (const juce::KeyPress& key) override
    {
        if (key == juce::KeyPress::escapeKey) { setVisible (false); return true; }
        if (visibleIds.empty()) return false;
        if (hoveredCard < 0) hoveredCard = 0;
        if (key == juce::KeyPress::leftKey) hoveredCard = juce::jmax (0, hoveredCard - 1);
        else if (key == juce::KeyPress::rightKey) hoveredCard = juce::jmin ((int) visibleIds.size() - 1, hoveredCard + 1);
        else if (key == juce::KeyPress::upKey) hoveredCard = juce::jmax (0, hoveredCard - 3);
        else if (key == juce::KeyPress::downKey) hoveredCard = juce::jmin ((int) visibleIds.size() - 1, hoveredCard + 3);
        else if (key == juce::KeyPress::returnKey) { addEffect (hoveredCard); return true; }
        else return false;
        repaint();
        return true;
    }

private:
    void addEffect (int index)
    {
        if (index < 0 || index >= (int) visibleIds.size()) return;
        const int id = visibleIds[(size_t) index];
        if (owner.processor.isInChain (id))
            owner.selectEffect (id); // selecting an existing type jumps to its current card; duplicates are not supported yet
        else
        {
            owner.processor.addEffectAt (id, insertPosition);
            owner.chainView.syncFromProcessor();
            owner.selectEffect (id);
        }
        setVisible (false);
    }

    UltAudioProcessorEditor& owner;
    juce::TextButton closeButton { juce::String::fromUTF8 ("\xC3\x97") };
    std::vector<int> visibleIds;
    juce::Rectangle<int> modal;
    int hoveredCard = -1, insertPosition = 0;

    juce::String shortName (int id) const
    {
        if (id == UltAudioProcessor::Gate) return "Gate / Expander";
        if (id == UltAudioProcessor::Autotune) return "Autotune";
        if (id == UltAudioProcessor::OctaveShifterId) return "Octave Shifter";
        if (id == UltAudioProcessor::EQ) return "EQ";
        if (id == UltAudioProcessor::Compressor) return "FET Compressor";
        if (id == UltAudioProcessor::DeEsser) return "De-Esser";
        if (id == UltAudioProcessor::Saturator) return "Saturator";
        if (id == UltAudioProcessor::OTT) return "OTT";
        return "Modulation";
    }

    juce::String description (int id) const
    {
        switch (id)
        {
            case UltAudioProcessor::Gate: return "Soft background-noise control";
            case UltAudioProcessor::Autotune: return "Real-time vocal pitch correction";
            case UltAudioProcessor::OctaveShifterId: return "Original voice plus octave layers";
            case UltAudioProcessor::EQ: return "Five-band interactive equalizer";
            case UltAudioProcessor::Compressor: return "Fast FET-style vocal compression";
            case UltAudioProcessor::DeEsser: return "Smooth sibilance reduction";
            case UltAudioProcessor::Saturator: return "Triode, Pentode and Tape voicings";
            case UltAudioProcessor::OTT: return "Three-band upward and downward compression";
            case UltAudioProcessor::Modulation: return "Doubler or Chorus in parallel";
            default: return {};
        }
    }

    void updateVisibleCards()
    {
        visibleIds.clear();
        for (int id = 0; id < UltAudioProcessor::NumEffects; ++id)
            if (id != UltAudioProcessor::Resonance) // removed from the v0.6 product surface
                visibleIds.push_back (id);
    }

    juce::Rectangle<int> cardBounds (int index) const
    {
        const int cols = 3, gap = 12, cardW = 270, cardH = 76;
        const int col = index % cols, row = index / cols;
        return { modal.getX() + 28 + col * (cardW + gap), modal.getY() + 94 + row * (cardH + 10), cardW, cardH };
    }
};

//==============================================================================
UltAudioProcessorEditor::ChainView::ChainView (UltAudioProcessorEditor& owner) : editor (owner)
{
    visualOrder = editor.processor.getChainOrder();
    lastChainRevision = editor.processor.getChainRevision();
    setWantsKeyboardFocus (false);
    setTitle ("Insert effect chain");
    setDescription ("Click an effect to edit it. Drag to reorder. Space is reserved for DAW transport.");
}

float UltAudioProcessorEditor::ChainView::targetCardX (int visualIndex) const
{
    const int cardW = 102, plusW = 24;
    const int gap = visualOrder.size() >= 9 ? 10 : 14;
    const int total = (int) visualOrder.size() * cardW + ((int) visualOrder.size() + 1) * (plusW + gap);
    const int start = juce::jmax (4, (getWidth() - total) / 2);
    return (float) (start + plusW + gap + visualIndex * (cardW + plusW + gap));
}

juce::Rectangle<int> UltAudioProcessorEditor::ChainView::cardBounds (int visualIndex) const
{
    if (visualIndex < 0 || visualIndex >= (int) visualOrder.size())
        return {};
    const int id = visualOrder[(size_t) visualIndex];
    const float x = animatedPositionInitialised[(size_t) id] ? animatedX[(size_t) id] : targetCardX (visualIndex);
    return { (int) std::lround (x), 7, 102, getHeight() - 14 };
}

juce::Rectangle<int> UltAudioProcessorEditor::ChainView::plusBounds (int gapIndex) const
{
    const int cardW = 102, plusW = 24;
    const int gap = visualOrder.size() >= 9 ? 10 : 14;
    const int total = (int) visualOrder.size() * cardW + ((int) visualOrder.size() + 1) * (plusW + gap);
    const int start = juce::jmax (4, (getWidth() - total) / 2);
    return { start + 6 + gapIndex * (cardW + plusW + gap), getHeight() / 2 - 12, plusW, plusW };
}

int UltAudioProcessorEditor::ChainView::indexAt (juce::Point<int> point) const
{
    for (int i = 0; i < (int) visualOrder.size(); ++i)
        if (cardBounds (i).contains (point)) return i;
    return -1;
}

void UltAudioProcessorEditor::ChainView::syncFromProcessor (bool forceRefresh)
{
    if (draggedIndex >= 0) return;
    const auto revision = editor.processor.getChainRevision();
    if (! forceRefresh && revision == lastChainRevision) return;

    visualOrder = editor.processor.getChainOrder();
    lastChainRevision = revision;

    if (forceRefresh)
    {
        // Preset/state recall is authoritative: discard stale card positions
        // from the previous chain and lay out the restored snapshot immediately.
        animatedPositionInitialised.fill (false);
        for (int i = 0; i < (int) visualOrder.size(); ++i)
        {
            const int id = visualOrder[(size_t) i];
            animatedX[(size_t) id] = targetCardX (i);
            animatedPositionInitialised[(size_t) id] = true;
        }
        repaint();
        return;
    }

    for (int i = 0; i < (int) visualOrder.size(); ++i)
    {
        const int id = visualOrder[(size_t) i];
        if (! animatedPositionInitialised[(size_t) id])
        {
            animatedX[(size_t) id] = targetCardX (i);
            animatedPositionInitialised[(size_t) id] = true;
        }
    }
    animate();
    repaint();
}

void UltAudioProcessorEditor::ChainView::animate()
{
    bool changed = false;
    for (int i = 0; i < (int) visualOrder.size(); ++i)
    {
        const int id = visualOrder[(size_t) i];
        const float target = targetCardX (i);
        if (! animatedPositionInitialised[(size_t) id])
        {
            animatedX[(size_t) id] = target;
            animatedPositionInitialised[(size_t) id] = true;
            changed = true;
            continue;
        }

        const float delta = target - animatedX[(size_t) id];
        if (std::abs (delta) < 0.45f)
            animatedX[(size_t) id] = target;
        else
        {
            animatedX[(size_t) id] += delta * 0.30f;
            changed = true;
        }
    }
    if (changed)
        repaint();
}

void UltAudioProcessorEditor::ChainView::paint (juce::Graphics& g)
{
    drawGlassPanel (g, getLocalBounds().toFloat(), 18.0f);
    if (visualOrder.empty())
    {
        g.setColour (muted);
        g.setFont (interFont (12.0f, true));
        g.drawText ("BUILD YOUR VOCAL CHAIN", 0, 7, getWidth(), 16, juce::Justification::centred);
        auto plus = plusBounds (0).toFloat();
        g.setColour (juce::Colours::white.withAlpha (0.055f));
        g.fillEllipse (plus.expanded (5.0f));
        g.setColour (borderSoft);
        g.drawEllipse (plus.expanded (5.0f), 0.8f);
        g.setColour (getLookAndFeel().findColour (juce::Slider::rotarySliderFillColourId));
        g.setFont (interFont (22.0f, true));
        g.drawText ("+", plus.toNearestInt(), juce::Justification::centred);
        g.setFont (interFont (12.0f, false));
        g.setColour (muted);
        g.drawText ("SELECT  +  TO ADD THE FIRST MODULE", 0, getHeight() - 19, getWidth(), 12,
                    juce::Justification::centred);
        return;
    }

    for (int gap = 0; gap <= (int) visualOrder.size(); ++gap)
    {
        auto plus = plusBounds (gap).toFloat();
        g.setColour (panelRaised);
        g.fillEllipse (plus);
        g.setColour (getLookAndFeel().findColour (juce::Slider::rotarySliderFillColourId));
        g.setFont (interFont (17.0f, true));
        g.drawText ("+", plus.toNearestInt(), juce::Justification::centred);
    }

    for (int i = 0; i < (int) visualOrder.size(); ++i)
    {
        const int id = visualOrder[(size_t) i];
        const auto r = cardBounds (i).toFloat();
        const bool selected = id == editor.selectedEffect;
        const bool active = editor.processor.isEffectEnabled (id);
        juce::ColourGradient gradient (selected ? juce::Colour (0xff555555) : juce::Colour (0xff292929),
                                       r.getX(), r.getY(), panel, r.getX(), r.getBottom(), false);
        g.setGradientFill (gradient);
        g.fillRoundedRectangle (r, 12.0f);
        g.setColour (selected ? getLookAndFeel().findColour (juce::Slider::rotarySliderFillColourId) : borderSoft);
        g.drawRoundedRectangle (r.reduced (0.5f), 12.0f, selected ? 1.6f : 1.0f);

        // Drag grip
        g.setColour (muted.withAlpha (0.72f));
        for (int row = 0; row < 3; ++row)
            for (int col = 0; col < 2; ++col)
                g.fillEllipse (r.getX() + 9.0f + col * 4.0f, r.getY() + 9.0f + row * 5.0f, 2.0f, 2.0f);

        juce::String title (UltAudioProcessor::effectName (id));
        if (id == UltAudioProcessor::Gate) title = "GATE";
        else if (id == UltAudioProcessor::OctaveShifterId) title = "OCTAVE";
        else if (id == UltAudioProcessor::Compressor) title = "COMPRESSOR";
        else if (id == UltAudioProcessor::DeEsser) title = "DE-ESSER";
        else title = title.toUpperCase();
        g.setColour (text);
        g.setFont (interFont (12.0f, true));
        g.drawFittedText (title, juce::Rectangle<int> ((int) r.getX() + 5, (int) r.getY() + 25,
            (int) r.getWidth() - 10, 20), juce::Justification::centred, 1);

        // Visible state label keeps Power state from relying on colour alone.
        g.setColour (active ? text : muted);
        g.setFont (interFont (12.0f, true));
        g.drawText (active ? "ON" : "BYPASS", (int) r.getX() + 10, (int) r.getBottom() - 22,
                    46, 12, juce::Justification::centredLeft);

        // Use the user-provided power-off.png alpha silhouette as the bypass icon.
        // Alpha-mask rendering tints the BLACK source icon to the requested state colour.
        static const auto powerIcon = juce::SoftwareImageType().convert (juce::ImageFileFormat::loadFrom (
            BinaryData::power_off_png, (size_t) BinaryData::power_off_pngSize));
        const juce::Rectangle<float> iconArea (r.getRight() - 31.0f,
                                                r.getBottom() - 27.0f, 24.0f, 24.0f);
        if (powerIcon.isValid())
        {
            g.setColour (active ? getLookAndFeel().findColour (juce::Slider::rotarySliderFillColourId) : juce::Colour (0xff53565a));
            g.drawImage (powerIcon, iconArea, juce::RectanglePlacement::centred, true);
        }

        // Remove glyph
        g.setColour (muted);
        g.drawLine (r.getRight() - 19.0f, r.getY() + 8.0f, r.getRight() - 11.0f, r.getY() + 16.0f, 1.4f);
        g.drawLine (r.getRight() - 11.0f, r.getY() + 8.0f, r.getRight() - 19.0f, r.getY() + 16.0f, 1.4f);
    }

    if (draggedIndex >= 0 && dragChanged)
    {
        g.setColour (getLookAndFeel().findColour (juce::Slider::rotarySliderFillColourId).withAlpha (0.045f));
        g.fillRoundedRectangle (getLocalBounds().toFloat().reduced (3.0f), 17.0f);
    }
}

void UltAudioProcessorEditor::ChainView::mouseDown (const juce::MouseEvent& e)
{
    for (int gap = 0; gap <= (int) visualOrder.size(); ++gap)
        if (plusBounds (gap).contains (e.getPosition()))
        {
            if (onAddAt) onAddAt (gap);
            return;
        }

    const int index = indexAt (e.getPosition());
    if (index < 0) return;
    const int id = visualOrder[(size_t) index];
    const auto r = cardBounds (index);
    const auto point = e.getPosition();
    if (juce::Rectangle<int> (r.getRight() - 34, r.getBottom() - 30, 30, 28).contains (point))
    {
        editor.processor.setEffectEnabled (id, ! editor.processor.isEffectEnabled (id));
        repaint();
        return;
    }
    if (juce::Rectangle<int> (r.getRight() - 29, r.getY() + 1, 26, 26).contains (point))
    {
        editor.processor.removeEffect (id);
        visualOrder = editor.processor.getChainOrder();
        lastChainRevision = editor.processor.getChainRevision();
        if (editor.selectedEffect == id) editor.selectEffect (-1);
        repaint();
        return;
    }
    draggedIndex = index;
    keyboardSelectedIndex = index;
    dragChanged = false;
    grabKeyboardFocus();
    if (onSelect) onSelect (id);
}

void UltAudioProcessorEditor::ChainView::mouseDrag (const juce::MouseEvent& e)
{
    if (draggedIndex < 0 || visualOrder.empty()) return;
    int target = 0;
    float best = std::numeric_limits<float>::max();
    for (int i = 0; i < (int) visualOrder.size(); ++i)
    {
        const float d = std::abs (e.position.x - (float) cardBounds (i).getCentreX());
        if (d < best) { best = d; target = i; }
    }
    if (target != draggedIndex)
    {
        const int moved = visualOrder[(size_t) draggedIndex];
        visualOrder.erase (visualOrder.begin() + draggedIndex);
        visualOrder.insert (visualOrder.begin() + target, moved);
        draggedIndex = target;
        dragChanged = true;
        animate();
    }
}

void UltAudioProcessorEditor::ChainView::mouseUp (const juce::MouseEvent&)
{
    if (draggedIndex >= 0 && dragChanged)
    {
        editor.processor.setChainOrder (visualOrder); // publish exactly once, after mouse-up
        lastChainRevision = editor.processor.getChainRevision();
    }
    draggedIndex = -1;
    dragChanged = false;
    repaint();
}

bool UltAudioProcessorEditor::ChainView::keyPressed (const juce::KeyPress& key)
{
    if (visualOrder.empty()) return false;
    if (keyboardSelectedIndex < 0 || keyboardSelectedIndex >= (int) visualOrder.size())
        keyboardSelectedIndex = 0;
    const int id = visualOrder[(size_t) keyboardSelectedIndex];

    if (key == juce::KeyPress::deleteKey || key == juce::KeyPress::backspaceKey)
    {
        editor.processor.removeEffect (id);
        visualOrder = editor.processor.getChainOrder();
        lastChainRevision = editor.processor.getChainRevision();
        keyboardSelectedIndex = juce::jlimit (0, juce::jmax (0, (int) visualOrder.size() - 1), keyboardSelectedIndex);
        editor.selectEffect (-1);
        repaint();
        return true;
    }
    if (key == juce::KeyPress::leftKey || key == juce::KeyPress::rightKey)
    {
        const int direction = key == juce::KeyPress::leftKey ? -1 : 1;
        const int target = juce::jlimit (0, (int) visualOrder.size() - 1, keyboardSelectedIndex + direction);
        if (target != keyboardSelectedIndex)
        {
            std::swap (visualOrder[(size_t) keyboardSelectedIndex], visualOrder[(size_t) target]);
            keyboardSelectedIndex = target;
            editor.processor.setChainOrder (visualOrder);
            lastChainRevision = editor.processor.getChainRevision();
            editor.selectEffect (visualOrder[(size_t) keyboardSelectedIndex]);
            repaint();
        }
        return true;
    }
    return false;
}

//==============================================================================
float UltAudioProcessorEditor::EqGraph::xForHz (float hz) const
{
    const float norm = std::log10 (juce::jlimit (20.0f, 20000.0f, hz) / 20.0f) / 3.0f;
    return 16.0f + norm * (getWidth() - 32.0f);
}

float UltAudioProcessorEditor::EqGraph::yForGain (float gain) const
{
    return getHeight() * 0.5f - gain * (getHeight() - 24.0f) / 36.0f;
}

float UltAudioProcessorEditor::EqGraph::nodeYForBand (int band) const
{
    const auto s = bandId (band);
    const bool lowCut = band == 0 && getParameter (processor, "eqType1") < 0.5f;
    const bool highCut = band == 4 && getParameter (processor, "eqType5") < 0.5f;
    if (lowCut || highCut)
        return yForGain (0.0f);
    return yForGain (getParameter (processor, "eqGain" + s));
}

float UltAudioProcessorEditor::EqGraph::responseAt (float hz) const
{
    return processor.getEqResponseDb (hz);
}

void UltAudioProcessorEditor::EqGraph::updateSpectrum()
{
    const auto count = processor.eqSpectrumWriteCount.load (std::memory_order_acquire);
    if (count == spectrumLastCount || count < UltAudioProcessor::eqSpectrumSize)
    {
        // Fade naturally after the host stops supplying samples.
        for (auto& v : spectrumSmoothed) v *= 0.88f;
        return;
    }
    spectrumLastCount = count;
    constexpr auto size = UltAudioProcessor::eqSpectrumSize;
    for (int i = 0; i < size; ++i)
    {
        const auto index = (size_t) ((count - size + (uint64_t) i) % size);
        const float window = 0.5f - 0.5f * std::cos (juce::MathConstants<float>::twoPi * (float) i / (float) (size - 1));
        spectrumWork[(size_t) i] = processor.eqSpectrumSamples[index].load (std::memory_order_relaxed) * window;
    }
    std::fill (spectrumWork.begin() + size, spectrumWork.end(), 0.0f);
    spectrumFft.performFrequencyOnlyForwardTransform (spectrumWork.data());
    for (int i = 0; i < size / 2; ++i)
    {
        const float magnitude = spectrumWork[(size_t) i] * (2.0f / (float) size);
        spectrumSmoothed[(size_t) i] = juce::jmax (magnitude, spectrumSmoothed[(size_t) i] * 0.78f);
    }
}

void UltAudioProcessorEditor::EqGraph::paint (juce::Graphics& g)
{
    if (getWidth() < 34 || getHeight() < 25) return;
    const float scale = juce::jmin (getWidth() / 600.0f, getHeight() / 236.0f);
    const float radius = 8.0f * scale;
    drawGlassPanel (g, getLocalBounds().toFloat(), 13.0f);
    g.setColour (juce::Colour (0xff343434).withAlpha (0.65f));
    for (int db = -18; db <= 18; db += 6)
        g.drawHorizontalLine ((int) yForGain ((float) db), 10.0f, (float) getWidth() - 10.0f);
    for (float hz : { 50.0f, 100.0f, 200.0f, 500.0f, 1000.0f, 2000.0f, 5000.0f, 10000.0f })
        g.drawVerticalLine ((int) xForHz (hz), 8.0f, (float) getHeight() - 8.0f);

    // Live post-EQ spectrum: logarithmic frequency axis, line and translucent fill.
    // Draw beneath the interactive response curve and its draggable nodes.
    if (processor.stagePresent[(size_t) UltAudioProcessor::EQ].load (std::memory_order_relaxed))
    {
        juce::Path spectrum;
        const float sampleRate = (float) processor.eqSpectrumSampleRate.load (std::memory_order_relaxed);
        const float bottom = (float) getHeight() - 10.0f;
        for (int x = 16; x < getWidth() - 16; x += 1)
        {
            const float norm = (float) (x - 16) / juce::jmax (1.0f, (float) getWidth() - 32.0f);
            const float hz = 20.0f * std::pow (1000.0f, norm);
            const float fractionalBin = juce::jlimit (0.0f, (float) (UltAudioProcessor::eqSpectrumSize / 2 - 1),
                hz * (float) UltAudioProcessor::eqSpectrumSize / juce::jmax (1.0f, sampleRate));
            const int bin = (int) fractionalBin;
            const int nextBin = juce::jmin (bin + 1, UltAudioProcessor::eqSpectrumSize / 2 - 1);
            const float fraction = fractionalBin - bin;
            const float mag = spectrumSmoothed[(size_t) bin] * (1.0f - fraction) + spectrumSmoothed[(size_t) nextBin] * fraction;
            const float db = juce::Decibels::gainToDecibels (mag, -90.0f);
            const float y = juce::jmap (juce::jlimit (-90.0f, 0.0f, db), -90.0f, 0.0f, bottom, 10.0f);
            if (x == 16) spectrum.startNewSubPath ((float) x, y);
            else spectrum.lineTo ((float) x, y);
        }
        auto area = spectrum;
        area.lineTo ((float) getWidth() - 16.0f, bottom);
        area.lineTo (16.0f, bottom);
        area.closeSubPath();
        g.setColour (getLookAndFeel().findColour (juce::Slider::rotarySliderFillColourId).withAlpha (0.13f));
        g.fillPath (area);
        g.setColour (getLookAndFeel().findColour (juce::Slider::rotarySliderFillColourId).withAlpha (0.55f));
        g.strokePath (spectrum, juce::PathStrokeType (1.3f * scale));
    }

    juce::Path curve;
    for (int x = 16; x < getWidth() - 16; x += 1)
    {
        const float norm = (float) (x - 16) / juce::jmax (1.0f, (float) getWidth() - 32.0f);
        const float hz = 20.0f * std::pow (1000.0f, norm);
        const float y = juce::jlimit (10.0f, (float) getHeight() - 10.0f, yForGain (responseAt (hz)));
        if (x == 16) curve.startNewSubPath ((float) x, y); else curve.lineTo ((float) x, y);
    }
    g.setColour (getLookAndFeel().findColour (juce::Slider::rotarySliderFillColourId).withAlpha (0.12f));
    juce::Path fill = curve;
    fill.lineTo ((float) getWidth() - 16.0f, yForGain (0.0f));
    fill.lineTo (16.0f, yForGain (0.0f));
    fill.closeSubPath();
    g.fillPath (fill);
    g.setColour (getLookAndFeel().findColour (juce::Slider::rotarySliderFillColourId));
    g.setOpacity (processor.isEffectEnabled (UltAudioProcessor::EQ) ? 1.0f : 0.3f);
    g.strokePath (curve, juce::PathStrokeType (2.2f * scale, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    g.setOpacity (1.0f);
    for (int band = 0; band < 5; ++band)
    {
        const auto s = bandId (band);
        const float x = xForHz (getParameter (processor, "eqFreq" + s));
        const float y = nodeYForBand (band);
        g.setColour (getLookAndFeel().findColour (juce::Slider::rotarySliderFillColourId).withAlpha (processor.isEffectEnabled (UltAudioProcessor::EQ) && getParameter (processor, "eqBandEnabled" + s) >= 0.5f ? (band == selectedBand ? 1.0f : 0.65f) : 0.25f));
        g.fillEllipse (x - radius, y - radius, radius * 2, radius * 2);
        g.setColour (bg);
        g.setFont (interFont (12.0f * scale, true));
        if (radius >= 4.0f) g.drawText (juce::String (band + 1), juce::Rectangle<float> (x - radius, y - radius, radius * 2, radius * 2).toNearestInt(), juce::Justification::centred);
    }
}

void UltAudioProcessorEditor::EqGraph::mouseDown (const juce::MouseEvent& e)
{
    float best = std::numeric_limits<float>::max();
    int nearest = -1;
    for (int band = 0; band < 5; ++band)
    {
        const float x = xForHz (getParameter (processor, "eqFreq" + bandId (band)));
        const float y = nodeYForBand (band);
        const float d = juce::Point<float> (x, y).getDistanceFrom (e.position);
        if (d < best) { best = d; nearest = band; }
    }
    if (nearest >= 0 && best < 36.0f * juce::jmin (getWidth() / 600.0f, getHeight() / 236.0f))
    {
        selectedBand = nearest;
        draggingNode = ! e.mods.isRightButtonDown();
        if (onBandSelected) onBandSelected (selectedBand);
        if (draggingNode) change (e);
        else
        {
            const auto id = "eqBandEnabled" + bandId (selectedBand);
            setParameter (processor, id, getParameter (processor, id) < 0.5f ? 1.0f : 0.0f);
        }
    }
    repaint();
}

void UltAudioProcessorEditor::EqGraph::mouseDrag (const juce::MouseEvent& e)
{
    if (draggingNode) change (e);
}

void UltAudioProcessorEditor::EqGraph::mouseUp (const juce::MouseEvent&)
{
    draggingNode = false;
}

void UltAudioProcessorEditor::EqGraph::change (const juce::MouseEvent& e)
{
    const auto s = bandId (selectedBand);
    const float norm = juce::jlimit (0.0f, 1.0f,
        (e.position.x - 16.0f) / juce::jmax (1.0f, (float) getWidth() - 32.0f));
    setParameter (processor, "eqFreq" + s, 20.0f * std::pow (1000.0f, norm));

    const bool cut = (selectedBand == 0 && getParameter (processor, "eqType1") < 0.5f)
                  || (selectedBand == 4 && getParameter (processor, "eqType5") < 0.5f);
    const float gain = juce::jlimit (-18.0f, 18.0f,
        (getHeight() * 0.5f - e.position.y) * 36.0f / juce::jmax (1.0f, (float) getHeight() - 24.0f));
    if (! cut)
        setParameter (processor, "eqGain" + s, juce::jlimit (-18.0f, 18.0f, gain));
    repaint();
}

void UltAudioProcessorEditor::EqGraph::mouseWheelMove (const juce::MouseEvent& e, const juce::MouseWheelDetails& w)
{
    int nearest = -1;
    float best = 18.0f * juce::jmin (getWidth() / 600.0f, getHeight() / 236.0f);
    for (int band = 0; band < 5; ++band)
    {
        const auto distance = juce::Point<float> (xForHz (getParameter (processor, "eqFreq" + bandId (band))), nodeYForBand (band)).getDistanceFrom (e.position);
        if (distance < best) { best = distance; nearest = band; }
    }
    if (nearest < 0) return;
    selectedBand = nearest;
    if (onBandSelected) onBandSelected (selectedBand);
    const bool cut = (selectedBand == 0 && getParameter (processor, "eqType1") < 0.5f)
                  || (selectedBand == 4 && getParameter (processor, "eqType5") < 0.5f);
    if (! cut)
    {
        const auto id = "eqQ" + bandId (selectedBand);
        setParameter (processor, id, juce::jlimit (0.2f, 12.0f,
            getParameter (processor, id) * std::pow (1.15f, w.deltaY * 5.0f)));
    }
    repaint();
}

//==============================================================================

// Mouse-driven layout editor for the existing JUCE components.
// It does not recreate controls: it moves/resizes the actual live components.
class UltAudioProcessorEditor::LayoutEditOverlay final : public juce::Component
{
public:
    explicit LayoutEditOverlay (UltAudioProcessorEditor& e) : owner (e)
    {
        setInterceptsMouseClicks (true, false);
    }

    void paint (juce::Graphics& g) override
    {
        if (! owner.layoutEditMode) return;
        for (int i = 0; i < owner.getNumChildComponents(); ++i)
        {
            auto* c = owner.getChildComponent (i);
            if (! editable (c) || ! c->isVisible()) continue;
            auto b = c->getBounds().toFloat();
            const bool active = c == selected.getComponent() || containsSelection (c);
            g.setColour (active ? owner.selectedAccent : owner.selectedAccent.withAlpha (0.30f));
            g.drawRect (b, active ? 2.0f : 1.0f);
            // The separate circular resize handle is drawn below, outside the
            // selected component. The original component stays behind the overlay.
        }

        if (marqueeActive)
        {
            auto r = juce::Rectangle<int>::leftTopRightBottom (juce::jmin (down.x, marqueeEnd.x), juce::jmin (down.y, marqueeEnd.y),
                juce::jmax (down.x, marqueeEnd.x), juce::jmax (down.y, marqueeEnd.y));
            g.setColour (owner.selectedAccent.withAlpha (0.20f)); g.fillRect (r);
            g.setColour (owner.selectedAccent); g.drawRect (r, 1);
        }
        if (auto* c = selected.getComponent())
        {
            const auto b = groupBounds();
            g.setColour (owner.selectedAccent);
            // Dedicated resize knob. Its position follows the selected component.
            const auto handle = resizeHandle (b);
            g.setColour (juce::Colour (0xff1c222c));
            g.fillEllipse (handle.toFloat());
            g.setColour (owner.selectedAccent);
            g.drawEllipse (handle.toFloat(), 2.0f);
            const auto center = handle.getCentre().toFloat();
            g.drawLine (center.x - 4.0f, center.y + 4.0f,
                        center.x + 4.0f, center.y - 4.0f, 2.0f);
            g.drawLine (center.x - 1.0f, center.y + 5.0f,
                        center.x + 5.0f, center.y - 1.0f, 1.0f);
            if (guideX >= 0) g.drawVerticalLine (guideX, 0.0f, (float) getHeight());
            if (guideY >= 0) g.drawHorizontalLine (guideY, 0.0f, (float) getWidth());

            if (dragging && ! resizing)
            {
                const auto delta = b.getPosition() - original.getPosition();
                const auto dx = resizing ? b.getWidth() - original.getWidth() : delta.x;
                const auto dy = resizing ? b.getHeight() - original.getHeight() : delta.y;
                const auto centerX = b.getCentreX();
                const auto centerY = b.getCentreY();
                if (dx != 0)
                {
                    const int sign = dx > 0 ? 1 : -1;
                    const int tipX = centerX + sign * 36;
                    g.drawLine ((float) centerX, (float) centerY, (float) tipX, (float) centerY, 2.0f);
                    g.drawLine ((float) tipX, (float) centerY, (float) (tipX - sign * 7), (float) centerY - 5.0f, 2.0f);
                    g.drawLine ((float) tipX, (float) centerY, (float) (tipX - sign * 7), (float) centerY + 5.0f, 2.0f);
                    drawTag (g, juce::String (dx > 0 ? "+" : "") + juce::String (dx) + " px", centerX - 34, centerY - 33, 68);
                }
                if (dy != 0)
                {
                    const int sign = dy > 0 ? 1 : -1;
                    const int tipY = centerY + sign * 36;
                    g.drawLine ((float) centerX, (float) centerY, (float) centerX, (float) tipY, 2.0f);
                    g.drawLine ((float) centerX, (float) tipY, (float) centerX - 5.0f, (float) (tipY - sign * 7), 2.0f);
                    g.drawLine ((float) centerX, (float) tipY, (float) centerX + 5.0f, (float) (tipY - sign * 7), 2.0f);
                    drawTag (g, juce::String (dy > 0 ? "+" : "") + juce::String (dy) + " px", centerX + 13, centerY + 12, 68);
                }
            }

            // Dimensions appear only while resizing, never during ordinary movement.
            if (resizing && dragging)
            {
                drawTag (g, juce::String (b.getWidth()) + " px", b.getCentreX() - 30, b.getY() - 23);
                drawTag (g, juce::String (b.getHeight()) + " px", b.getRight() + 5, b.getCentreY() - 10);
            }

            // Nearest horizontal and vertical gaps to other visible components.
            const juce::Component* nearestX = nullptr;
            const juce::Component* nearestY = nullptr;
            int distanceX = 100000, distanceY = 100000;
            for (int i = 0; i < owner.getNumChildComponents(); ++i)
            {
                auto* other = owner.getChildComponent (i);
                if (! editable (other) || other == c || ! other->isVisible()) continue;
                const auto o = other->getBounds();
                if (juce::jmax (b.getY(), o.getY()) < juce::jmin (b.getBottom(), o.getBottom()))
                {
                    const int gap = o.getX() >= b.getRight() ? o.getX() - b.getRight()
                                  : b.getX() >= o.getRight() ? b.getX() - o.getRight() : -1;
                    if (gap >= 0 && gap < distanceX) { distanceX = gap; nearestX = other; }
                }
                if (juce::jmax (b.getX(), o.getX()) < juce::jmin (b.getRight(), o.getRight()))
                {
                    const int gap = o.getY() >= b.getBottom() ? o.getY() - b.getBottom()
                                  : b.getY() >= o.getBottom() ? b.getY() - o.getBottom() : -1;
                    if (gap >= 0 && gap < distanceY) { distanceY = gap; nearestY = other; }
                }
            }
            if (! resizing && nearestX != nullptr)
            {
                const auto o = nearestX->getBounds();
                const int y = juce::jmax (b.getY(), o.getY()) +
                              (juce::jmin (b.getBottom(), o.getBottom()) -
                               juce::jmax (b.getY(), o.getY())) / 2;
                const int x1 = b.getRight() <= o.getX() ? b.getRight() : o.getRight();
                const int x2 = b.getRight() <= o.getX() ? o.getX() : b.getX();
                g.drawLine ((float) x1, (float) y, (float) x2, (float) y, 1.5f);
                drawTag (g, juce::String (distanceX) + " px", (x1 + x2) / 2 - 26, y - 22);
            }
            if (! resizing && nearestY != nullptr)
            {
                const auto o = nearestY->getBounds();
                const int x = juce::jmax (b.getX(), o.getX()) +
                              (juce::jmin (b.getRight(), o.getRight()) -
                               juce::jmax (b.getX(), o.getX())) / 2;
                const int y1 = b.getBottom() <= o.getY() ? b.getBottom() : o.getBottom();
                const int y2 = b.getBottom() <= o.getY() ? o.getY() : b.getY();
                g.drawLine ((float) x, (float) y1, (float) x, (float) y2, 1.5f);
                drawTag (g, juce::String (distanceY) + " px", x + 6, (y1 + y2) / 2 - 9);
            }
        }
        drawTag (g, "EDIT  |  SHIFT: axis  |  CTRL: no snap  |  ALT: move toolbar  |  SNAP 8 px",
                 10, getHeight() - 25, 550);
    }

    void mouseDown (const juce::MouseEvent& e) override
    {
        if (! owner.layoutEditMode) return;
        grabKeyboardFocus();
        const auto p = e.getEventRelativeTo (this).getPosition();
        if (juce::KeyPress::isKeyCurrentlyDown ('1'))
        {
            marqueeActive = true; down = marqueeEnd = p; dragging = false;
            repaint(); return;
        }
        auto* source = e.originalComponent;
        const bool toolbar = source == &owner.editLayoutButton || source == &owner.saveLayoutButton
                             || source == &owner.resetLayoutButton || source == &owner.layoutMenuButton || source == &owner.accentButton;
        if (toolbar && ! e.mods.isAltDown()) { clearSelection(); return; }
        // Clicking the dedicated resize knob retains the selection.
        // The handle is outside the component, so test it BEFORE hit-testing
        // the other controls.
        if (auto* current = selected.getComponent())
        {
            if (resizeHandle (groupBounds()).contains (p))
            {
                original = groupBounds();
                snapshotBefore = capture();
                dragStartBounds.clear();
                for (const auto& entry : group) if (entry.first != nullptr)
                    dragStartBounds.emplace_back (entry.first, entry.first->getBounds());
                down = p;
                resizing = true;
                guideX = guideY = -1;
                repaint();
                return;
            }
        }

        const bool inGroup = std::any_of (group.begin(), group.end(), [p] (const auto& entry)
            { return entry.first != nullptr && entry.first->getBounds().contains (p); });
        if (! inGroup) group.clear();
        // Preserve the entire multi-selection when clicking any member.
        // Previously every click collapsed the selection to a single control.
        auto* previousSelection = selected.getComponent();
        selected = nullptr;
        if (! inGroup && previousSelection != nullptr && editable (previousSelection)
            && previousSelection->isVisible() && previousSelection->getBounds().contains (p))
            selected = previousSelection;
        if (inGroup)
            for (const auto& entry : group)
                if (entry.first != nullptr && entry.first->getBounds().contains (p))
                { selected = entry.first; break; }
        if (toolbar)
            selected = source;
        for (int i = owner.getNumChildComponents() - 1; selected == nullptr && i >= 0; --i)
        {
            auto* c = owner.getChildComponent (i);
            if (editable (c) && c->isVisible() && c->getBounds().contains (p))
            {
                selected = c;
                break;
            }
        }
        if (auto* c = selected.getComponent())
        {
            original = groupBounds();
            snapshotBefore = capture();
            dragStartBounds.clear();
            for (const auto& entry : group) if (entry.first != nullptr)
                dragStartBounds.emplace_back (entry.first, entry.first->getBounds());
            const auto local = p - original.getPosition();
            resizing = false; // Resize ONLY via the separate circular handle.
            dragging = false;
            dragOffset = local;
            down = p;
            // Do NOT call c->toFront(): that used to move the selected control
            // above this overlay, so subsequent mouseDown events went to the
            // real knob/button instead of the layout editor.
        }
        guideX = guideY = -1;
        repaint();
    }

    void mouseDrag (const juce::MouseEvent& e) override
    {
        if (! owner.layoutEditMode) return;
        if (marqueeActive) { marqueeEnd = e.getPosition(); repaint(); return; }
        if (auto* c = selected.getComponent())
        {
            if (isToolbar (c) && ! e.mods.isAltDown()) return;
            dragging = true;
            auto p = e.getEventRelativeTo (this).getPosition();
            auto delta = p - down;
            if (e.mods.isShiftDown())
            {
                // Shift locks the weaker axis; movement/spacing on the stronger
                // axis stays pixel-precise and remains magnetically snapped.
                if (std::abs (delta.x) >= std::abs (delta.y)) delta.y = 0;
                else delta.x = 0;
            }
            auto b = original;
            if (resizing)
            {
                int newW = juce::jmax (juce::jmin (28, original.getWidth()), original.getWidth() + delta.x);
                int newH = juce::jmax (juce::jmin (22, original.getHeight()), original.getHeight() + delta.y);
                // A group scales uniformly by default: its children keep their
                // proportions and spacing. Ctrl bypasses magnetic snap only.
                if (dragStartBounds.size() > 1 && original.getWidth() > 0 && original.getHeight() > 0)
                {
                    const float sx = (float) newW / (float) original.getWidth();
                    const float sy = (float) newH / (float) original.getHeight();
                    const float scale = std::abs (sx - 1.0f) >= std::abs (sy - 1.0f) ? sx : sy;
                    newW = juce::roundToInt (original.getWidth() * scale);
                    newH = juce::roundToInt (original.getHeight() * scale);
                }
                b.setSize (newW, newH);
            }
            else
                b.setPosition (original.getPosition() + delta);
            guideX = guideY = -1;
            if (! e.mods.isCtrlDown() && ! isToolbar (c))
                snapToNeighbours (b, c, resizing);
            // Ctrl keeps the measurement guides but bypasses magnetic snapping.
            if (e.mods.isShiftDown() && ! (resizing && dragStartBounds.size() > 1))
            {
                if (delta.y == 0) { if (resizing) b.setHeight (original.getHeight()); else b.setY (original.getY()); guideY = -1; }
                if (delta.x == 0) { if (resizing) b.setWidth (original.getWidth()); else b.setX (original.getX()); guideX = -1; }
            }
            // Prevent dragging a selection entirely beyond the editor edges.
            b.setPosition (juce::jlimit (0, juce::jmax (0, 1320 - b.getWidth()), b.getX()),
                           juce::jlimit (0, juce::jmax (0, 740 - b.getHeight()), b.getY()));
            b.setSize (juce::jmin (b.getWidth(), 1320 - b.getX()),
                       juce::jmin (b.getHeight(), 740 - b.getY()));
            if (resizing && dragStartBounds.size() > 1)
            {
                const float scale = juce::jmin ((float) b.getWidth() / original.getWidth(), (float) b.getHeight() / original.getHeight());
                b.setSize (juce::roundToInt (original.getWidth() * scale), juce::roundToInt (original.getHeight() * scale));
            }
            if (b.getWidth() >= 1 && b.getHeight() >= 1)
            {
                if (dragStartBounds.size() > 1)
                {
                    const float sx = (float) b.getWidth() / juce::jmax (1, original.getWidth());
                    const float sy = (float) b.getHeight() / juce::jmax (1, original.getHeight());
                    for (const auto& entry : dragStartBounds)
                    {
                        auto r = entry.second;
                        const int nx = b.getX() + juce::roundToInt ((r.getX() - original.getX()) * sx);
                        const int ny = b.getY() + juce::roundToInt ((r.getY() - original.getY()) * sy);
                        const int nw = resizing ? juce::jmax (1, juce::roundToInt (r.getWidth() * sx)) : r.getWidth();
                        const int nh = resizing ? juce::jmax (1, juce::roundToInt (r.getHeight() * sy)) : r.getHeight();
                        if (entry.first != nullptr) entry.first->setBounds (nx, ny, nw, nh);
                    }
                }
                else c->setBounds (b);
            }
            repaint();
        }
    }

    void mouseUp (const juce::MouseEvent&) override
    {
        if (marqueeActive)
        {
            const auto area = juce::Rectangle<int>::leftTopRightBottom (
                juce::jmin (down.x, marqueeEnd.x), juce::jmin (down.y, marqueeEnd.y),
                juce::jmax (down.x, marqueeEnd.x), juce::jmax (down.y, marqueeEnd.y));
            for (int i = 0; i < owner.getNumChildComponents(); ++i)
            {
                auto* c = owner.getChildComponent (i);
                if (editable (c) && c->isVisible() && area.contains (c->getBounds()) && ! containsSelection (c))
                    group.emplace_back (c, c->getBounds());
            }
            if (! group.empty()) selected = group.front().first;
            marqueeActive = false;
        }
        else if (dragging && ! snapshotBefore.empty())
        {
            undo.push_back (snapshotBefore);
            if (undo.size() > 100) undo.erase (undo.begin());
            redo.clear();
        }
        guideX = guideY = -1;
        dragging = false;
        repaint();
    }

    void mouseWheelMove (const juce::MouseEvent& e, const juce::MouseWheelDetails& wheel) override
    {
        if (! owner.layoutEditMode || ! e.mods.isAltDown()) return;
        std::vector<juce::Component*> hits;
        for (int i = owner.getNumChildComponents() - 1; i >= 0; --i)
            if (auto* c = owner.getChildComponent (i); editable (c) && c->isVisible() && c->getBounds().contains (e.getEventRelativeTo (this).getPosition())) hits.push_back (c);
        if (hits.empty()) return;
        auto it = std::find (hits.begin(), hits.end(), selected.getComponent());
        int index = it == hits.end() ? 0 : ((int) std::distance (hits.begin(), it) + (wheel.deltaY >= 0 ? 1 : (int) hits.size() - 1)) % (int) hits.size();
        group.clear(); selected = hits[(size_t) index]; repaint();
    }

    bool keyPressed (const juce::KeyPress& key) override
    {
        if (owner.layoutEditMode && key.getKeyCode() == '4') return true;
        if (! owner.layoutEditMode || ! key.getModifiers().isCtrlDown()) return false;
        const auto code = juce::CharacterFunctions::toLowerCase ((juce_wchar) key.getKeyCode());
        if (code == 'z' && ! undo.empty())
        {
            redo.push_back (capture()); restore (undo.back()); undo.pop_back(); repaint(); return true;
        }
        if (code == 'y' && ! redo.empty())
        {
            undo.push_back (capture()); restore (redo.back()); redo.pop_back(); repaint(); return true;
        }
        return false;
    }

    void clearSelection() { group.clear(); selected = nullptr; repaint(); }

    // External layout actions form a single undo step, like group transforms.
    void checkpoint()
    {
        undo.push_back (capture());
        if (undo.size() > 100) undo.erase (undo.begin());
        redo.clear();
        clearSelection();
    }


private:
    using Snapshot = std::vector<std::pair<juce::Component::SafePointer<juce::Component>, juce::Rectangle<int>>>;
    using History = std::vector<std::pair<juce::String, juce::Rectangle<int>>>;
    History capture() const
    {
        History result;
        for (int i = 0; i < owner.getNumChildComponents(); ++i)
        {
            auto* c = owner.getChildComponent (i);
            if ((editable (c) || isToolbar (c)) && c->isVisible() && c->getComponentID().isNotEmpty()) result.emplace_back (c->getComponentID(), c->getBounds());
        }
        return result;
    }
    void restore (const History& state)
    {
        owner.captureLayoutDraft();
        for (const auto& entry : state)
        {
            if (owner.layoutDraft != nullptr)
            {
                auto* item = owner.layoutDraft->getChildByAttribute ("id", entry.first);
                if (item == nullptr) item = owner.layoutDraft->createNewChildElement ("COMPONENT");
                item->setAttribute ("id", entry.first);
                item->setAttribute ("x", entry.second.getX());
                item->setAttribute ("y", entry.second.getY());
                item->setAttribute ("w", entry.second.getWidth());
                item->setAttribute ("h", entry.second.getHeight());
            }
            for (int i = 0; i < owner.getNumChildComponents(); ++i)
                if (auto* c = owner.getChildComponent (i); c->getComponentID() == entry.first) c->setBounds (entry.second);
        }
    }
    bool containsSelection (const juce::Component* c) const
    {
        return std::any_of (group.begin(), group.end(), [c] (const auto& entry) { return entry.first == c; });
    }
    juce::Rectangle<int> groupBounds() const
    {
        if (group.size() <= 1)
            return selected != nullptr ? selected->getBounds() : juce::Rectangle<int>();
        juce::Rectangle<int> bounds;
        for (const auto& entry : group) if (entry.first != nullptr) bounds = bounds.isEmpty() ? entry.first->getBounds() : bounds.getUnion (entry.first->getBounds());
        return bounds;
    }

public:

private:
    juce::Rectangle<int> resizeHandle (const juce::Rectangle<int>& bounds) const
    {
        // Keep the entire handle inside the editor, even for edge controls.
        constexpr int diameter = 22;
        return { juce::jlimit (0, juce::jmax (0, getWidth() - diameter),
                              bounds.getRight() + 2),
                 juce::jlimit (0, juce::jmax (0, getHeight() - diameter),
                              bounds.getBottom() + 2),
                 diameter, diameter };
    }

    bool isToolbar (const juce::Component* c) const
    {
        return c == &owner.editLayoutButton || c == &owner.saveLayoutButton
               || c == &owner.resetLayoutButton || c == &owner.layoutMenuButton || c == &owner.accentButton;
    }
    bool editable (const juce::Component* c) const
    {
        return c != nullptr && c != this && ! isToolbar (c)
            && c != owner.addEffectOverlay.get()
            && dynamic_cast<const juce::ResizableCornerComponent*> (c) == nullptr;
    }

    void drawTag (juce::Graphics& g, const juce::String& value,
                         int x, int y, int width = 64)
    {
        g.setColour (juce::Colour (0xee171c24));
        g.fillRoundedRectangle ((float) x, (float) y, (float) width, 19.0f, 4.0f);
        g.setColour (owner.selectedAccent);
        g.setFont (12.0f);
        g.drawText (value, x + 3, y + 1, width - 6, 17, juce::Justification::centred);
    }

    void snapToNeighbours (juce::Rectangle<int>& b, const juce::Component* selectedComponent,
                           bool resize) 
    {
        constexpr int threshold = 8;
        int bestX = threshold + 1, bestY = threshold + 1;
        int newX = resize ? b.getRight() : b.getX();
        int newY = resize ? b.getBottom() : b.getY();
        for (int i = 0; i < owner.getNumChildComponents(); ++i)
        {
            auto* other = owner.getChildComponent (i);
            if (! editable (other) || other == selectedComponent || containsSelection (other) || ! other->isVisible()) continue;
            const auto o = other->getBounds();
            const int xs[] = { o.getX(), o.getCentreX(), o.getRight() };
            const int ys[] = { o.getY(), o.getCentreY(), o.getBottom() };
            const int movingX[] = { b.getX(), b.getCentreX(), b.getRight() };
            const int movingY[] = { b.getY(), b.getCentreY(), b.getBottom() };
            for (int target : xs)
                for (int k = resize ? 2 : 0; k < 3; ++k)
                {
                    const int difference = target - movingX[k];
                    if (std::abs (difference) < bestX)
                    {
                        bestX = std::abs (difference);
                        newX = (resize ? b.getRight() : b.getX()) + difference;
                        guideX = target;
                    }
                }
            for (int target : ys)
                for (int k = resize ? 2 : 0; k < 3; ++k)
                {
                    const int difference = target - movingY[k];
                    if (std::abs (difference) < bestY)
                    {
                        bestY = std::abs (difference);
                        newY = (resize ? b.getBottom() : b.getY()) + difference;
                        guideY = target;
                    }
                }
        }
        if (bestX <= threshold)
        {
            if (resize) b.setWidth (juce::jmax (28, newX - b.getX()));
            else b.setX (newX);
        }
        else guideX = -1;
        if (bestY <= threshold)
        {
            if (resize) b.setHeight (juce::jmax (22, newY - b.getY()));
            else b.setY (newY);
        }
        else guideY = -1;
    }

    UltAudioProcessorEditor& owner;
    juce::Component::SafePointer<juce::Component> selected;
    juce::Rectangle<int> original;
    juce::Point<int> dragOffset, down;
    int guideX = -1, guideY = -1;
    bool resizing = false, dragging = false, marqueeActive = false;
    juce::Point<int> marqueeEnd;
    Snapshot group, dragStartBounds;
    History snapshotBefore;
    std::vector<History> undo, redo;
};

// --- v0.9.13 stage-aware history (UI thread, nominal 60 FPS) ---
void UltAudioProcessorEditor::StageHistoryGraph::updateDeSpectrum()
{
    constexpr int size = UltAudioProcessor::eqSpectrumSize;
    auto update = [&] (const auto& samples, const auto& counter, uint64_t& previous,
                     std::array<float, size / 2>& spectrum)
    {
        const auto current = counter.load (std::memory_order_acquire);
        if (current == previous || current < size)
        {
            for (auto& value : spectrum) value *= 0.88f;
            return;
        }
        previous = current;
        for (int i = 0; i < size; ++i)
        {
            const auto index = (size_t) ((current - size + (uint64_t) i) % size);
            const float window = 0.5f - 0.5f * std::cos (juce::MathConstants<float>::twoPi * (float) i / (float) (size - 1));
            deWork[(size_t) i] = samples[index].load (std::memory_order_relaxed) * window;
        }
        std::fill (deWork.begin() + size, deWork.end(), 0.0f);
        deFft.performFrequencyOnlyForwardTransform (deWork.data());
        for (int i = 0; i < size / 2; ++i)
        {
            const float mag = deWork[(size_t) i] * (2.0f / (float) size);
            spectrum[(size_t) i] = juce::jmax (mag, spectrum[(size_t) i] * 0.78f);
        }
    };
    update (processor.deInputSamples, processor.deInputCount, deLastInput, deInputSpectrum);
    update (processor.deOutputSamples, processor.deOutputCount, deLastOutput, deOutputSpectrum);
}

void UltAudioProcessorEditor::StageHistoryGraph::tick()
{
    if (effectId < 0 || effectId >= UltAudioProcessor::NumEffects) return;
    if (effectId == UltAudioProcessor::DeEsser) updateDeSpectrum();
    const auto index = (size_t) effectId;
    const bool present = processor.stagePresent[index].load (std::memory_order_relaxed);
    const float in = present ? processor.stageInputPeak[index].load (std::memory_order_relaxed) : 0.0f;
    const float out = present ? processor.stageOutputPeak[index].load (std::memory_order_relaxed) : 0.0f;
    historyTime[(size_t) writeIndex] = juce::Time::getMillisecondCounterHiRes();
    inputHistory[(size_t) writeIndex] = in;
    outputHistory[(size_t) writeIndex] = out;
    writeIndex = (writeIndex + 1) % historySize;
    count = juce::jmin (historySize, count + 1);
    repaint();
}

void UltAudioProcessorEditor::StageHistoryGraph::paint (juce::Graphics& g)
{
    if (getWidth() <= 0 || getHeight() <= 0) return;
    juce::Graphics::ScopedSaveState saved (g);
    g.addTransform (juce::AffineTransform::scale (getWidth() / 600.0f, getHeight() / 236.0f));
    auto bounds = juce::Rectangle<float> (0, 0, 600, 236).reduced (1.0f);
    const auto themeAccent = getLookAndFeel().findColour (juce::Slider::rotarySliderFillColourId);
    g.setColour (juce::Colour (0xff101010).interpolatedWith (themeAccent, 0.035f));
    g.fillRoundedRectangle (bounds, 7.0f);
    g.setColour (juce::Colour (0xff303030).interpolatedWith (themeAccent, .12f));
    g.drawRoundedRectangle (bounds, 7.0f, 1.0f);
    if (effectId < 0 || effectId >= UltAudioProcessor::NumEffects) return;
    const bool enabled = processor.isEffectEnabled (effectId);
    const auto bright = getLookAndFeel().findColour (juce::Slider::rotarySliderFillColourId).withAlpha (enabled ? 0.95f : 0.32f);
    const auto dim = getLookAndFeel().findColour (juce::Slider::rotarySliderFillColourId).interpolatedWith (juce::Colours::grey, 0.55f).withAlpha (enabled ? 0.85f : 0.28f);
    const float left = 30.0f, top = 30.0f, right = 524.0f;
    const float bottom = 209.0f;
    const float height = juce::jmax (1.0f, bottom - top);
    const float width = juce::jmax (1.0f, right - left);
    auto levelY = [=] (float amplitude)
    {
        const float db = juce::Decibels::gainToDecibels (juce::jmax (amplitude, 1.0e-6f), -72.0f);
        return bottom - juce::jlimit (0.0f, 1.0f, (db + 72.0f) / 78.0f) * height;
    };
    g.setFont (11.0f);
    for (int db : { 0, -24, -48, -72 })
    {
        const float y = effectId == UltAudioProcessor::DeEsser
            ? juce::jmap ((float) db, -90.0f, 0.0f, bottom, top)
            : levelY (juce::Decibels::decibelsToGain ((float) db));
        g.setColour (juce::Colour (0xff292929).interpolatedWith (themeAccent, .08f)); g.drawHorizontalLine ((int) y, left, right);
        g.setColour (juce::Colour (0xff999999).interpolatedWith (themeAccent, .08f));
        g.drawText (juce::String (db), 2, (int) y - 7, 27, 14, juce::Justification::centredRight);
    }
    auto drawHistory = [&] (const std::array<float, historySize>& data, juce::Colour colour)
    {
        if (count < 2) return;
        juce::Path path;
        const double now = juce::Time::getMillisecondCounterHiRes();
        double previous = -1.0;
        for (int i = 0; i < count; ++i)
        {
            const int index = (writeIndex - count + i + historySize) % historySize;
            const double stamp = historyTime[(size_t) index];
            const double age = now - stamp;
            if (age > 5000.0 || age < 0.0) continue;
            const float x = right - (float) (age / 5000.0) * width;
            const float y = levelY (data[(size_t) index]);
            if (previous < 0.0 || stamp - previous > 250.0) path.startNewSubPath (x, y); else path.lineTo (x, y);
            previous = stamp;
        }
        g.setColour (colour); g.strokePath (path, juce::PathStrokeType (1.6f));
    };
    if (effectId == UltAudioProcessor::DeEsser)
    {
        // One logarithmic frequency plot, pre/post spectrum in distinct accent shades.
        const float sampleRate = (float) processor.deSpectrumSampleRate.load (std::memory_order_relaxed);
        auto freqX = [=] (float hz)
        {
            return left + juce::jlimit (0.0f, 1.0f,
                std::log (juce::jmax (20.0f, hz) / 20.0f) / std::log (1000.0f)) * width;
        };
        const float center = processor.apvts.getRawParameterValue ("deFreq")->load();
        const float centerX = freqX (center);
        g.setColour (bright.withAlpha (enabled ? 0.10f : 0.05f));
        g.fillRect (juce::Rectangle<float> (juce::jmax (left, freqX (center * 0.72f)), top,
            juce::jmax (1.0f, juce::jmin (right, freqX (center * 1.4f)) - juce::jmax (left, freqX (center * 0.72f))), height));
        g.setColour (bright.withAlpha (0.7f));
        g.drawVerticalLine ((int) centerX, top, bottom);
        auto drawSpectrum = [&] (const std::array<float, UltAudioProcessor::eqSpectrumSize / 2>& bins, juce::Colour colour)
        {
            juce::Path path;
            for (int x = (int) left; x <= (int) right; x += 1)
            {
                const float norm = ((float) x - left) / width;
                const float hz = 20.0f * std::pow (1000.0f, norm);
                const float fractionalBin = juce::jlimit (0.0f, (float) (UltAudioProcessor::eqSpectrumSize / 2 - 1),
                hz * (float) UltAudioProcessor::eqSpectrumSize / juce::jmax (1.0f, sampleRate));
            const int bin = (int) fractionalBin;
            const int nextBin = juce::jmin (bin + 1, UltAudioProcessor::eqSpectrumSize / 2 - 1);
            const float fraction = fractionalBin - bin;
                const float db = juce::Decibels::gainToDecibels (bins[(size_t) bin] * (1.0f - fraction) + bins[(size_t) nextBin] * fraction, -90.0f);
                const float y = juce::jmap (juce::jlimit (-90.0f, 0.0f, db), -90.0f, 0.0f, bottom, top);
                if (x == (int) left) path.startNewSubPath ((float) x, y);
                else path.lineTo ((float) x, y);
            }
            g.setColour (colour);
            g.strokePath (path, juce::PathStrokeType (1.5f));
        };
        drawSpectrum (deInputSpectrum, dim);
        drawSpectrum (deOutputSpectrum, bright);
        g.setColour (juce::Colour (0xffbbbbbb).interpolatedWith (themeAccent, .08f));
        g.drawText (juce::String ((int) center) + " Hz", (int) centerX - 38, (int) top, 76, 16,
                    juce::Justification::centred);
    }
    else
    {
        drawHistory (inputHistory, dim);
        drawHistory (outputHistory, bright);
    }
    if (effectId == UltAudioProcessor::Compressor)
    {
        // Static transfer characteristic of the actual FET DSP calibration.
        // This is not an animated estimate: the processing path uses -18 dB,
        // hard knee, including input drive but excluding output makeup.
        const float inputDrive = processor.apvts.getRawParameterValue ("compInput")->load (std::memory_order_relaxed);
        const int ratioIndex = (int) processor.apvts.getRawParameterValue ("compRatio")->load (std::memory_order_relaxed);
        const float ratio = ratioIndex == 0 ? 4.0f : (ratioIndex == 1 ? 8.0f : 20.0f);
        const auto xFor = [&] (float db) { return left + (db + 72.0f) / 78.0f * width; };
        const auto yFor = [&] (float db) { return levelY (juce::Decibels::decibelsToGain (db)); };
        juce::Path unity, compressed;
        for (int i = 0; i <= 78; ++i)
        {
            const float inputDb = -72.0f + (float) i;
            const float knee = -18.0f - inputDrive;
            const float compressedDb = inputDb <= knee ? inputDb : knee + (inputDb - knee) / ratio;
            const float x = xFor (inputDb);
            const float straightY = yFor (inputDb);
            const float compressedY = juce::jlimit (top, bottom, yFor (compressedDb));
            if (i == 0) { unity.startNewSubPath (x, straightY); compressed.startNewSubPath (x, compressedY); }
            else { unity.lineTo (x, straightY); compressed.lineTo (x, compressedY); }
        }
        g.setColour (juce::Colours::grey.withAlpha (enabled ? 0.28f : 0.85f));
        g.strokePath (unity, juce::PathStrokeType (1.1f));
        g.setColour (themeAccent.interpolatedWith (juce::Colours::white, 0.55f).withAlpha (enabled ? 0.92f : 0.20f));
        g.strokePath (compressed, juce::PathStrokeType (1.8f));
        g.setColour (juce::Colour (0xffbbbbbb).interpolatedWith (themeAccent, .08f));
        g.setFont (10.0f);
        g.drawText ("TRANSFER: -72 to +6 dB", (int) left, (int) top, (int) width, 14, juce::Justification::centredRight);
    }
    if (effectId == UltAudioProcessor::Gate)
    {
        if (auto* param = processor.apvts.getRawParameterValue ("gateThreshold"))
        {
            const float threshold = param->load (std::memory_order_relaxed);
            const float y = levelY (juce::Decibels::decibelsToGain (threshold));
            float dashes[] { 5.0f, 4.0f };
            g.setColour (juce::Colour (0xffffd071).withAlpha (enabled ? 0.95f : 0.4f));
            g.drawDashedLine ({ left, y, right, y }, dashes, 2, 1.3f);
            g.drawText (juce::String (threshold, 1) + " dB", (int) right - 82, (int) y - 19, 82, 17,
                        juce::Justification::centredRight);
        }
    }
    const auto stage = (size_t) effectId;
    const float in = processor.stageInputPeak[stage].load (std::memory_order_relaxed);
    const float out = processor.stageOutputPeak[stage].load (std::memory_order_relaxed);
    const float reduction = processor.stageReductionDb[stage].load (std::memory_order_relaxed);
    auto meter = [&] (float x, float value, juce::Colour colour, const juce::String& label)
    {
        g.setColour (juce::Colour (0xff252525).interpolatedWith (themeAccent, .08f)); g.fillRoundedRectangle (x, top, 12.0f, height, 2.0f);
        const float y = levelY (value);
        g.setColour (colour); g.fillRoundedRectangle (x, y, 12.0f, juce::jmax (0.0f, bottom - y), 2.0f);
        g.setColour (juce::Colour (0xffbbbbbb).interpolatedWith (themeAccent, .08f)); g.drawText (label, (int) x - 4, (int) bottom + 3, 23, 15,
                                                           juce::Justification::centred);
    };
    meter (right + 10, in, dim, "IN");
    meter (right + 29, out, bright, "OUT");
    if (effectId == UltAudioProcessor::Compressor || effectId == UltAudioProcessor::DeEsser)
    {
        const float maxGr = effectId == UltAudioProcessor::DeEsser ? 48.0f : 36.0f;
        const float gr = enabled ? juce::jlimit (0.0f, maxGr, reduction) : 0.0f;
        const float x = right + 49.0f;
        g.setColour (juce::Colour (0xff252525).interpolatedWith (themeAccent, .08f)); g.fillRoundedRectangle (x, top, 12.0f, height, 2.0f);
        g.setColour (juce::Colour (0xffffc56c).withAlpha (enabled ? 1.0f : 0.35f));
        g.fillRoundedRectangle (x, top, 12.0f, gr / maxGr * height, 2.0f);
        g.setColour (juce::Colour (0xffbbbbbb).interpolatedWith (themeAccent, .08f)); g.drawText ("GR", (int) x - 4, (int) bottom + 3, 23, 15,
                                                             juce::Justification::centred);
    }
    g.setColour (juce::Colour (0xffbbbbbb).interpolatedWith (themeAccent, .08f));
    const juce::String title = effectId == UltAudioProcessor::Gate ? "GATE" :
                               effectId == UltAudioProcessor::Compressor ? "1176 COMPRESSOR" : "DE-ESSER";
    g.drawText (title + (enabled ? "" : "  /  BYPASS"), (int) left, 7, 230, 19,
                juce::Justification::centredLeft);
    if (effectId != UltAudioProcessor::DeEsser) {
    g.drawText ("-5s", (int) left, (int) bottom + 5, 38, 15, juce::Justification::centredLeft);
    g.drawText ("NOW", (int) right - 40, (int) bottom + 5, 40, 15, juce::Justification::centredRight);
    } else {
        for (int hz : { 20, 100, 1000, 10000, 20000 }) {
            const float x = left + std::log ((float) hz / 20.0f) / std::log (1000.0f) * width;
            g.drawText (hz >= 1000 ? juce::String (hz / 1000) + "k" : juce::String (hz), (int) x - 16, (int) bottom + 5, 32, 15, juce::Justification::centred);
        }
    }
    if (effectId == UltAudioProcessor::Gate)
    {
        const bool open = processor.gateDetectorOpen.load (std::memory_order_relaxed);
        g.setColour (open && enabled ? bright : juce::Colour (0xff999999).interpolatedWith (themeAccent, .08f));
        g.drawText (open && enabled ? "OPEN" : "CLOSED", (int) right - 82, 7, 82, 19,
                    juce::Justification::centredRight);
    }
    if (effectId == UltAudioProcessor::DeEsser || effectId == UltAudioProcessor::Compressor || effectId == UltAudioProcessor::Gate)
    {
        g.setColour (juce::Colour (0xffbbbbbb).interpolatedWith (themeAccent, .08f));
        g.drawText ("GR " + juce::String (enabled ? reduction : 0.0f, 1) + " dB",
                    (int) left + 235, 7, 145, 19, juce::Justification::centredLeft);
    }
}

void UltAudioProcessorEditor::StageHistoryGraph::dragThreshold (const juce::MouseEvent& e)
{
    if (effectId != UltAudioProcessor::Gate || ! processor.isEffectEnabled (effectId)) return;
    const float top = 30.0f, bottom = 209.0f;
    const float t = juce::jlimit (0.0f, 1.0f, (bottom - (e.position.y * 236.0f / juce::jmax (1, getHeight()))) / juce::jmax (1.0f, bottom - top));
    const float db = juce::jlimit (-70.0f, -20.0f, -72.0f + t * 78.0f);
    if (auto* parameter = processor.apvts.getParameter ("gateThreshold"))
        parameter->setValueNotifyingHost (parameter->convertTo0to1 (db));
}
void UltAudioProcessorEditor::StageHistoryGraph::dragDeFrequency (const juce::MouseEvent& e)
{
    if (effectId != UltAudioProcessor::DeEsser || ! processor.isEffectEnabled (effectId)) return;
    const float left = 30.0f, right = 524.0f;
    const float norm = juce::jlimit (0.0f, 1.0f, ((e.position.x * 600.0f / juce::jmax (1, getWidth())) - left) / juce::jmax (1.0f, right - left));
    const float hz = 20.0f * std::pow (1000.0f, norm);
    if (auto* parameter = processor.apvts.getParameter ("deFreq"))
        parameter->setValueNotifyingHost (parameter->convertTo0to1 (hz));
}
void UltAudioProcessorEditor::StageHistoryGraph::mouseDown (const juce::MouseEvent& e)
{
    if (effectId == UltAudioProcessor::DeEsser) dragDeFrequency (e);
    else dragThreshold (e);
}
void UltAudioProcessorEditor::StageHistoryGraph::mouseDrag (const juce::MouseEvent& e)
{
    if (effectId == UltAudioProcessor::DeEsser) dragDeFrequency (e);
    else dragThreshold (e);
}

UltAudioProcessorEditor::UltAudioProcessorEditor (UltAudioProcessor& p)
    : AudioProcessorEditor (&p), processor (p), chainView (*this), eqGraph (p), stageHistory (p), pitchDisplay (p), meter (p)
{
    setLookAndFeel (&look);
    setWantsKeyboardFocus (true);
    setResizable (true, true);
    setResizeLimits (990, 555, 2640, 1480);
    if (auto* constrainer = getConstrainer())
        constrainer->setFixedAspectRatio (1320.0 / 740.0);
    auto windowFile = getLayoutFile().getSiblingFile ("window.xml");
    auto windowXml = juce::XmlDocument::parse (windowFile);
    const int initialW = processor.editorWidth.load() > 0 ? processor.editorWidth.load() : windowXml != nullptr ? windowXml->getIntAttribute ("width", 1238) : 1238;
    const int initialH = processor.editorHeight.load() > 0 ? processor.editorHeight.load() : windowXml != nullptr ? windowXml->getIntAttribute ("height", 694) : 694;
    setSize (juce::jlimit (990, 2640, initialW), juce::jlimit (555, 1480, initialH));

    addAndMakeVisible (brand);
    brand.setButtonText ("ULT");
    brand.setComponentID ("brandLink");
    brand.setTooltip ("Open swagghazard on Telegram");
    brand.setDescription ("Open https://t.me/hazardexcitesme");
    brand.setColour (juce::TextButton::textColourOffId, text);
    brand.setColour (juce::TextButton::textColourOnId, text);
    brand.setColour (juce::TextButton::buttonColourId, juce::Colours::transparentBlack);
    brand.setMouseCursor (juce::MouseCursor::PointingHandCursor);
    brand.onClick = [] { juce::URL ("https://t.me/hazardexcitesme").launchInDefaultBrowser(); };

    addAndMakeVisible (signature);
    signature.setButtonText ("swagghazard");
    signature.setComponentID ("signatureLink");
    signature.setTooltip ("Open swagghazard on Telegram");
    signature.setDescription ("Open https://t.me/hazardexcitesme");
    signature.setColour (juce::TextButton::textColourOffId, muted);
    signature.setColour (juce::TextButton::textColourOnId, text);
    signature.setColour (juce::TextButton::buttonColourId, juce::Colours::transparentBlack);
    signature.setMouseCursor (juce::MouseCursor::PointingHandCursor);
    signature.onClick = [] { juce::URL ("https://t.me/hazardexcitesme").launchInDefaultBrowser(); };

    addAndMakeVisible (inputGain);
    inputGain.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    inputGain.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 82, 21);
    inputGain.setColour (juce::Slider::textBoxBackgroundColourId, juce::Colours::transparentBlack);
    inputGain.setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    inputGain.setRange (-24.0, 24.0, 0.1);
    inputGain.setTooltip ("Input gain before the insert chain");
    inputGainAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (processor.apvts, "inputGain", inputGain);
    addAndMakeVisible (inputGainLabel);
    inputGainLabel.setText ("INPUT GAIN", juce::dontSendNotification);
    inputGainLabel.setColour (juce::Label::textColourId, muted);
    inputGainLabel.setFont (interFont (12.0f, true));
    inputGainLabel.setJustificationType (juce::Justification::centred);

    addAndMakeVisible (outputGain);
    outputGain.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    outputGain.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 82, 21);
    outputGain.setColour (juce::Slider::textBoxBackgroundColourId, juce::Colours::transparentBlack);
    outputGain.setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    outputGain.setRange (-24.0, 24.0, 0.1);
    outputGain.setTooltip ("Output gain after all insert and send processing");
    outputGainAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (processor.apvts, "outputGain", outputGain);
    addAndMakeVisible (outputGainLabel);
    outputGainLabel.setText ("OUTPUT GAIN", juce::dontSendNotification);
    outputGainLabel.setColour (juce::Label::textColourId, muted);
    outputGainLabel.setFont (interFont (12.0f, true));
    outputGainLabel.setJustificationType (juce::Justification::centred);

    configureValue (inputGain, inputGainValue, "inputGain", true);
    configureValue (outputGain, outputGainValue, "outputGain", true);
    addAndMakeVisible (meter);
    meter.setTitle ("Input and output meters");
    meter.setDescription ("Real input and output peak levels in dBFS with peak hold.");

    addAndMakeVisible (presetSelector);
    presetSelector.setButtonText ("PRESETS");
    presetSelector.setTooltip ("Current preset. An asterisk indicates modified settings. Click to choose another preset.");
    presetSelector.setTitle ("Presets");
    presetSelector.setDescription ("Shows the selected preset name. An asterisk indicates changed parameters or effect order. Click to open the downward-only factory and user preset menu.");
    presetSelector.onClick = [this] { showPresetMenu(); };
    addAndMakeVisible (savePreset);
    savePreset.setDescription ("Save the current effect chain and all parameter values as a user preset.");
    savePreset.onClick = [this] { savePresetFile(); };

    editLayoutButton.setComponentID ("ult_edit_layout");
    saveLayoutButton.setComponentID ("ult_save_layout");
    resetLayoutButton.setComponentID ("ult_reset_layout");
    addAndMakeVisible (editLayoutButton);
    editLayoutButton.setVisible (false);
    editLayoutButton.setTooltip ("Toggle mouse-based editing of the existing ULT controls");
    editLayoutButton.onClick = [this]
    {
        if (juce::ModifierKeys::getCurrentModifiersRealtime().isAltDown()) return;
        if (layoutEditMode)
        {
            // Discard unsaved geometry. Window dimensions remain independent.
            layoutEditMode = false;
            layoutDraft.reset();
            // Restore both the saved geometry and the saved accent. The window
            // size is intentionally independent of SAVE LAYOUT.
            setAccentColour (juce::Colour (0xffa6ff00));
            if (auto saved = juce::parseXML (getLayoutFile()))
                if (validLayout (*saved) && saved->hasAttribute ("accent"))
                    setAccentColour (juce::Colour::fromString (saved->getStringAttribute ("accent")));
            resized();
            if (layoutEditOverlay) layoutEditOverlay->clearSelection();
        }
        else
        {
            layoutEditMode = true;
            layoutDraft = juce::XmlDocument::parse (getLayoutFile());
            captureLayoutDraft();
            if (layoutEditOverlay) layoutEditOverlay->setVisible (true); layoutEditOverlay->grabKeyboardFocus();
        }
        editLayoutButton.setVisible (layoutEditMode);
        editLayoutButton.setButtonText (layoutEditMode ? "EXIT EDIT" : "EDIT LAYOUT");
        saveLayoutButton.setVisible (layoutEditMode);
        resetLayoutButton.setVisible (layoutEditMode);
        layoutMenuButton.setVisible (layoutEditMode);
        accentButton.setVisible (layoutEditMode);
        if (layoutEditOverlay != nullptr) layoutEditOverlay->setVisible (layoutEditMode);
    };
    addAndMakeVisible (saveLayoutButton);
    addAndMakeVisible (resetLayoutButton);
    addAndMakeVisible (layoutMenuButton);
    addAndMakeVisible (accentButton);
    accentButton.setComponentID ("ult_accent_color");
    accentButton.onClick = [this]
    {
        if (juce::ModifierKeys::getCurrentModifiersRealtime().isAltDown()) return;
        auto picker = std::make_unique<UltAccentPicker> (selectedAccent,
            [safe = juce::Component::SafePointer<UltAudioProcessorEditor> (this)] (juce::Colour colour)
            {
                if (safe != nullptr && safe->layoutEditMode) safe->setAccentColour (colour);
            });
        juce::CallOutBox::launchAsynchronously (std::move (picker), accentButton.getScreenBounds(), nullptr);
    };
    layoutMenuButton.setComponentID ("ult_layout_menu");
    layoutMenuButton.onClick = [this] { if (! juce::ModifierKeys::getCurrentModifiersRealtime().isAltDown()) showLayoutMenu(); };
    saveLayoutButton.setVisible (false);
    resetLayoutButton.setVisible (false);
    layoutMenuButton.setVisible (false);
    accentButton.setVisible (false);
    resetLayoutButton.setTooltip ("Delete saved layout and restore original ULT geometry");
    resetLayoutButton.onClick = [this]
    {
        if (juce::ModifierKeys::getCurrentModifiersRealtime().isAltDown()) return;
        juce::NativeMessageBox::showOkCancelBox (
            juce::AlertWindow::QuestionIcon, "Reset ULT Layout",
            "Restore the default layout, window size and accent colour?",
            this, juce::ModalCallbackFunction::create ([safe = juce::Component::SafePointer<UltAudioProcessorEditor> (this)] (int result)
            {
                if (result == 0 || safe == nullptr) return;
                if (safe->layoutEditOverlay) safe->layoutEditOverlay->checkpoint();
                safe->layoutDraft.reset();
                safe->layoutForceReload = true;
                safe->getLayoutFile().deleteFile();
                safe->observeCurrentLayoutFile();
                safe->setAccentColour (juce::Colour (0xffa6ff00));
                safe->setSize (1238, 694);
                safe->resized();
                safe->layoutForceReload = false;
                safe->layoutDraft = safe->captureLayout();
            }));
    };
    saveLayoutButton.setTooltip ("Save the current positions and sizes of existing ULT components");
    saveLayoutButton.onClick = [this] { if (juce::ModifierKeys::getCurrentModifiersRealtime().isAltDown()) return; saveCurrentLayout(); if (layoutEditOverlay) layoutEditOverlay->clearSelection(); };
    layoutEditOverlay = std::make_unique<LayoutEditOverlay> (*this);
    addAndMakeVisible (*layoutEditOverlay);
    layoutEditOverlay->setVisible (false);
    editLayoutButton.addMouseListener (layoutEditOverlay.get(), false);
    saveLayoutButton.addMouseListener (layoutEditOverlay.get(), false);
    resetLayoutButton.addMouseListener (layoutEditOverlay.get(), false);
    layoutMenuButton.addMouseListener (layoutEditOverlay.get(), false);
    accentButton.addMouseListener (layoutEditOverlay.get(), false);

    refreshPresetList();

    addAndMakeVisible (chainView);
    chainView.onSelect = [this] (int id) { selectEffect (id); };
    chainView.onAddAt = [this] (int position) { showAddEffectWindow (position); };
    addAndMakeVisible (panelTitle);
    panelTitle.setColour (juce::Label::textColourId, text);
    panelTitle.setFont (interFont (16.5f, true));
    addAndMakeVisible (pitchDisplay);
    pitchDisplay.setVisible (false);
    addAndMakeVisible (stageHistory);
    stageHistory.setVisible (false);
    addAndMakeVisible (eqGraph);
    eqGraph.setTitle ("EQ response graph");
    eqGraph.setDescription ("Drag a band point to adjust frequency and gain. Right-click a point to toggle its band. In Cut mode, choose the filter slope with the dedicated control.");
    eqGraph.setVisible (false);
    eqGraph.onBandSelected = [this] (int band)
    {
        selectedEqBand = band;
        eqBandSelector.setSelectedItemIndex (band, juce::dontSendNotification);
        rebuildParameterControls();
    };
    addAndMakeVisible (eqBandSelector);
    eqBandSelector.setTooltip ("Select the EQ band to edit");
    eqBandSelector.setDescription ("Select one of the five equalizer bands.");
    eqBandSelector.addItem ("BAND 1", 1); eqBandSelector.addItem ("BAND 2", 2);
    eqBandSelector.addItem ("BAND 3", 3); eqBandSelector.addItem ("BAND 4", 4);
    eqBandSelector.addItem ("BAND 5", 5);
    eqBandSelector.onChange = [this]
    {
        selectedEqBand = eqBandSelector.getSelectedItemIndex();
        eqGraph.selectedBand = selectedEqBand;
        rebuildParameterControls();
    };
    addAndMakeVisible (eqBandLabel);
    eqBandLabel.setText ("BAND", juce::dontSendNotification);
    eqBandLabel.setColour (juce::Label::textColourId, muted);
    eqBandLabel.setVisible (false);
    eqBandSelector.setVisible (false);

    addAndMakeVisible (delayPower);
    addAndMakeVisible (reverbPower);
    delayPower.setTooltip ("Enable or bypass the parallel delay return");
    delayPower.setDescription ("Enable or bypass the parallel delay return.");
    reverbPower.setTooltip ("Enable or bypass the parallel reverb return");
    reverbPower.setDescription ("Enable or bypass the parallel reverb return.");
    delayPowerAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (processor.apvts, "delayOn", delayPower);
    reverbPowerAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (processor.apvts, "reverbOn", reverbPower);
    buildSendControls();
    rebuildParameterControls();
    resized();

    currentPresetName = processor.apvts.state.getProperty ("ultPresetName", "Init").toString();
    if (currentPresetName.isEmpty())
    {
        setCurrentPresetName ("Init");
    }
    else
    {
        presetStateSnapshot = processor.apvts.state.getProperty ("ultPresetBaseline").toString();
        if (presetStateSnapshot.isEmpty())
        {
            presetStateSnapshot = makePresetFingerprint();
            processor.apvts.state.setProperty ("ultPresetBaseline", presetStateSnapshot, nullptr);
        }
        presetSelector.setButtonText (currentPresetName);
    }

    chainView.syncFromProcessor (true);
    windowPersistenceReady = true;
    lastWindowWidth = getWidth(); lastWindowHeight = getHeight();
    processor.editorWidth.store (getWidth()); processor.editorHeight.store (getHeight());
    startTimerHz (60);
}

void UltAudioProcessorEditor::visibilityChanged()
{
    processor.visualizationActive.store (isShowing(), std::memory_order_relaxed);
}

void UltAudioProcessorEditor::parentHierarchyChanged()
{
    visibilityChanged();
   #if JUCE_WINDOWS
    // JUCE's Direct2D renderer may enter the NVIDIA D3D11 driver during
    // native window teardown. For this diagnostic build, switch the plugin
    // window to JUCE's CPU-backed software renderer as soon as its peer exists.
    // This intentionally does not change audio DSP, parameters, or presets.
    if (auto* peer = getPeer())
        peer->setCurrentRenderingEngine (0); // index 0: Software Renderer
   #endif
}

UltAudioProcessorEditor::~UltAudioProcessorEditor()
{
    processor.visualizationActive.store (false, std::memory_order_relaxed);
    stopTimer();
    juce::PopupMenu::dismissAllActiveMenus();
    // Detach listeners and attachments before their target components disappear.
    for (auto* button : { &editLayoutButton, &saveLayoutButton, &resetLayoutButton, &layoutMenuButton, &accentButton })
        button->removeMouseListener (layoutEditOverlay.get());
    layoutEditOverlay.reset();
    chooser.reset();
    addEffectOverlay.reset();
    for (auto* group : { &dynamicControls, &delayControls, &reverbControls })
    {
        for (auto& c : *group)
        {
            if (c->combo) c->combo->onChange = nullptr;
            if (c->value) { c->value->onTextChange = nullptr; c->value->hideEditor (true); }
        }
        group->clear();
    }
    inputGainValue.onTextChange = nullptr;
    outputGainValue.onTextChange = nullptr;
    inputGainValue.hideEditor (true);
    outputGainValue.hideEditor (true);
    inputGainAttachment.reset();
    outputGainAttachment.reset();
    delayPowerAttachment.reset();
    reverbPowerAttachment.reset();
    setLookAndFeel (nullptr);
}

void UltAudioProcessorEditor::configureValue (juce::Slider& slider, juce::Label& value, const juce::String& id, bool editable)
{
    slider.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    if (auto* parameter = processor.apvts.getParameter (id))
        slider.setDoubleClickReturnValue (true, parameter->convertFrom0to1 (parameter->getDefaultValue()));
    value.setComponentID ("value_" + id);
    value.setJustificationType (juce::Justification::centred);
    value.setColour (juce::Label::textColourId, text);
    value.setEditable (false, editable, false);
    value.setText (slider.getTextFromValue (slider.getValue()), juce::dontSendNotification);
    value.onTextChange = [&slider, &value]
    {
        slider.setValue (slider.getValueFromText (value.getText()), juce::sendNotificationSync);
        value.setText (slider.getTextFromValue (slider.getValue()), juce::dontSendNotification);
    };
    addAndMakeVisible (value);
}

void UltAudioProcessorEditor::addFloatControl (std::vector<std::unique_ptr<Control>>& destination,
                                                const juce::String& id, const juce::String& caption,
                                                float min, float max, float step)
{
    auto c = std::make_unique<Control>();
    c->slider = std::make_unique<juce::Slider>();
    c->label = std::make_unique<juce::Label>();
    c->slider->setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    c->slider->setTextBoxStyle (juce::Slider::TextBoxBelow, false, 82, 21);
    c->slider->setColour (juce::Slider::textBoxTextColourId, juce::Colours::white);
    c->slider->setRange (min, max, step);
    c->slider->setColour (juce::Slider::textBoxTextColourId, text);
    c->slider->setColour (juce::Slider::textBoxBackgroundColourId, juce::Colours::transparentBlack);
    c->slider->setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    c->slider->setTooltip (caption);
    c->slider->setDescription (caption);
    c->slider->setComponentID ("knob_" + id);
    c->label->setComponentID ("label_" + id);
    if (id == "deFreq") c->slider->setSkewFactorFromMidPoint (6000.0);
    c->label->setText (caption, juce::dontSendNotification);
    c->label->setFont (interFont (12.0f, true));
    c->label->setColour (juce::Label::textColourId, muted);
    c->label->setJustificationType (juce::Justification::centred);
    c->sliderAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (processor.apvts, id, *c->slider);
    if (id.startsWith ("eqFreq"))
    {
        c->slider->setNormalisableRange (makeEqFrequencySliderRange());
        c->slider->setNumDecimalPlacesToDisplay (2);
        c->slider->textFromValueFunction = [] (double value)
        {
            return juce::String (value, 2);
        };
        // Force the textbox to repaint using the formatter immediately after
        // the attachment has supplied the initial/default/preset value.
        c->slider->updateText();
    }
    addAndMakeVisible (*c->slider);
    addAndMakeVisible (*c->label);
    c->value = std::make_unique<juce::Label>();
    configureValue (*c->slider, *c->value, id, true);
    destination.push_back (std::move (c));
}

void UltAudioProcessorEditor::addChoiceControl (std::vector<std::unique_ptr<Control>>& destination,
                                                 const juce::String& id, const juce::String& caption,
                                                 const juce::StringArray& options)
{
    auto c = std::make_unique<Control>();
    c->combo = std::make_unique<juce::ComboBox>();
    c->label = std::make_unique<juce::Label>();
    c->combo->addItemList (options, 1);
    c->combo->setTooltip (caption);
    c->combo->setDescription (caption);
    c->combo->setComponentID ("choice_" + id);
    c->label->setComponentID ("label_" + id);
    c->label->setText (caption, juce::dontSendNotification);
    c->label->setFont (interFont (12.0f, true));
    c->label->setColour (juce::Label::textColourId, muted);
    c->label->setJustificationType (juce::Justification::centred);
    c->comboAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (processor.apvts, id, *c->combo);
    if (id == "modModeV06" || id == "eqType1" || id == "eqType5")
    {
        juce::Component::SafePointer<UltAudioProcessorEditor> safeThis (this);
        c->combo->onChange = [safeThis]
        {
            if (safeThis != nullptr)
                juce::MessageManager::callAsync ([safeThis]
                {
                    if (safeThis != nullptr) safeThis->rebuildParameterControls();
                });
        };
    }
    addAndMakeVisible (*c->combo);
    addAndMakeVisible (*c->label);
    destination.push_back (std::move (c));
}

void UltAudioProcessorEditor::addChoiceKnobControl (std::vector<std::unique_ptr<Control>>& destination,
                                                        const juce::String& id, const juce::String& caption,
                                                        const juce::StringArray& options)
{
    auto c = std::make_unique<Control>();
    c->slider = std::make_unique<juce::Slider>();
    c->label = std::make_unique<juce::Label>();
    c->slider->setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    c->slider->setTextBoxStyle (juce::Slider::TextBoxBelow, true, 82, 21);
    c->slider->setRange (0.0, (double) juce::jmax (0, options.size() - 1), 1.0);
    c->slider->setColour (juce::Slider::textBoxTextColourId, text);
    c->slider->setColour (juce::Slider::textBoxBackgroundColourId, juce::Colours::transparentBlack);
    c->slider->setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    c->slider->setTooltip (caption);
    c->slider->setDescription (caption);
    c->slider->setComponentID ("knob_" + id);
    c->label->setComponentID ("label_" + id);
    const auto displayOptions = options;
    c->slider->textFromValueFunction = [displayOptions] (double value)
    {
        const int index = juce::jlimit (0, juce::jmax (0, displayOptions.size() - 1), (int) std::lround (value));
        return displayOptions[index];
    };
    c->slider->setDoubleClickReturnValue (true, 2.0);
    c->label->setText (caption, juce::dontSendNotification);
    c->label->setFont (interFont (12.0f, true));
    c->label->setColour (juce::Label::textColourId, muted);
    c->label->setJustificationType (juce::Justification::centred);
    c->sliderAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (processor.apvts, id, *c->slider);
    if (id.startsWith ("eqFreq"))
    {
        c->slider->setNormalisableRange (makeEqFrequencySliderRange());
        c->slider->setNumDecimalPlacesToDisplay (2);
        c->slider->textFromValueFunction = [] (double value)
        {
            return juce::String (value, 2);
        };
        // Force the textbox to repaint using the formatter immediately after
        // the attachment has supplied the initial/default/preset value.
        c->slider->updateText();
    }
    addAndMakeVisible (*c->slider);
    addAndMakeVisible (*c->label);
    c->value = std::make_unique<juce::Label>();
    configureValue (*c->slider, *c->value, id, false);
    destination.push_back (std::move (c));
}

void UltAudioProcessorEditor::buildSendControls()
{
    addChoiceControl (delayControls, "delayMode", "MODE", { "STANDARD", "PING PONG" });
    addChoiceControl (delayControls, "delayNote", "TIME", { "1/64", "1/32", "1/16", "1/8", "1/4", "1/2", "1/1" });
    addChoiceControl (delayControls, "delayFeel", "FEEL", { "STRAIGHT", "DOTTED", "TRIPLET" });
    addFloatControl (delayControls, "delayFeedback", "FEEDBACK %", 0.0f, 90.0f, 1.0f);
    addFloatControl (delayControls, "delayMix", "SEND %", 0.0f, 100.0f, 1.0f);

    addChoiceControl (reverbControls, "reverbMode", "SPACE", { "ROOM", "HALL", "SPACE" });
    addFloatControl (reverbControls, "reverbDecay", "DECAY ms", 100.0f, 10000.0f, 1.0f);
    addFloatControl (reverbControls, "reverbCharacter", "CHARACTER", 0.0f, 100.0f, 1.0f);
    addFloatControl (reverbControls, "reverbMix", "SEND %", 0.0f, 100.0f, 1.0f);
    addFloatControl (reverbControls, "reverbDucking", "SMART DUCK %", 0.0f, 100.0f, 1.0f);
}

void UltAudioProcessorEditor::selectEffect (int id)
{
    selectedEffect = id;
    if (id == UltAudioProcessor::EQ)
    {
        eqBandSelector.setSelectedItemIndex (selectedEqBand, juce::dontSendNotification);
        eqGraph.selectedBand = selectedEqBand;
    }
    rebuildParameterControls();
}

void UltAudioProcessorEditor::rebuildParameterControls()
{
    captureLayoutDraft();
    if (layoutEditOverlay) layoutEditOverlay->clearSelection();
    const juce::ScopedValueSetter<bool> rebuilding (layoutRebuilding, true);
    for (auto& c : dynamicControls)
    {
        if (c->slider) { removeChildComponent (c->slider.get()); removeChildComponent (c->label.get()); }
        if (c->combo) { removeChildComponent (c->combo.get()); removeChildComponent (c->label.get()); }
    }
    dynamicControls.clear();

    const bool isEq = selectedEffect == UltAudioProcessor::EQ;
    eqGraph.setVisible (isEq);
    const bool hasHistory = selectedEffect == UltAudioProcessor::Gate
                         || selectedEffect == UltAudioProcessor::Compressor
                         || selectedEffect == UltAudioProcessor::DeEsser;
    stageHistory.setVisible (hasHistory);
    pitchDisplay.setVisible (selectedEffect == UltAudioProcessor::Autotune);
    if (hasHistory) stageHistory.setEffect (selectedEffect);
    stageHistory.setComponentID ("fixed_stageHistory_" + juce::String (selectedEffect));
    eqBandSelector.setVisible (isEq);
    eqBandLabel.setVisible (isEq);
    if (selectedEffect < 0 || selectedEffect == UltAudioProcessor::Resonance)
    {
        panelTitle.setText ("SELECT AN EFFECT TO EDIT", juce::dontSendNotification);
        resized(); repaint(); return;
    }

    panelTitle.setText (juce::String (UltAudioProcessor::effectName (selectedEffect)).toUpperCase(), juce::dontSendNotification);
    switch (selectedEffect)
    {
        case UltAudioProcessor::Gate:
            addFloatControl (dynamicControls, "gateThreshold", "THRESHOLD dB", -70, -20, 0.1f);
            addFloatControl (dynamicControls, "gateRelease", "RELEASE ms", 10, 500, 1);
            break;
        case UltAudioProcessor::Autotune:
            addChoiceControl (dynamicControls, "tuneKey", "KEY", { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" });
            addChoiceControl (dynamicControls, "tuneScale", "SCALE", { "MAJOR", "MINOR" });
            addFloatControl (dynamicControls, "tuneDetune", "REFERENCE Hz", 415, 467, 0.1f);
            addFloatControl (dynamicControls, "tuneRetune", "RETUNE ms", 0, 500, 0.1f);
            addFloatControl (dynamicControls, "tuneHumanize", "HUMANIZE", 0, 100, 1);
            addChoiceControl (dynamicControls, "tuneVoice", "VOICE", { "MALE", "FEMALE" });
            break;
        case UltAudioProcessor::OctaveShifterId:
            addFloatControl (dynamicControls, "octaveOriginal", "ORIGINAL %", 0, 100, 1);
            addFloatControl (dynamicControls, "octaveDown", "OCTAVE DOWN %", 0, 100, 1);
            addFloatControl (dynamicControls, "octaveUp", "OCTAVE UP %", 0, 100, 1);
            break;
        case UltAudioProcessor::EQ:
        {
            const auto s = bandId (selectedEqBand);
            const bool cut = (selectedEqBand == 0 && getParameter (processor, "eqType1") < 0.5f)
                          || (selectedEqBand == 4 && getParameter (processor, "eqType5") < 0.5f);
            addFloatControl (dynamicControls, "eqFreq" + s, "FREQUENCY Hz", 20, 20000, 0.0f);
            if (! cut) addFloatControl (dynamicControls, "eqGain" + s, "GAIN dB", -18, 18, 0.1f);
            if (cut)
            {
                const juce::String slopeId = selectedEqBand == 0 ? "eqSlope1" : "eqSlope5";
                addChoiceKnobControl (dynamicControls, slopeId, "SLOPE", { "12 dB/oct", "18 dB/oct", "24 dB/oct", "36 dB/oct", "48 dB/oct" });
            }
            else
                addFloatControl (dynamicControls, "eqQ" + s, "Q", 0.2f, 12, 0.01f);
            if (selectedEqBand == 0) addChoiceControl (dynamicControls, "eqType1", "FILTER TYPE", { "LOW CUT", "LOW SHELF", "BELL" });
            if (selectedEqBand == 4) addChoiceControl (dynamicControls, "eqType5", "FILTER TYPE", { "HIGH CUT", "HIGH SHELF", "BELL" });
            break;
        }
        case UltAudioProcessor::Compressor:
            addFloatControl (dynamicControls, "compInput", "INPUT dB", -12, 36, 0.1f);
            addFloatControl (dynamicControls, "compOutput", "OUTPUT dB", -24, 12, 0.1f);
            addChoiceControl (dynamicControls, "compRatio", "RATIO", { "4:1", "8:1", "20:1" });
            break;
        case UltAudioProcessor::DeEsser:
            addFloatControl (dynamicControls, "deFreq", "FREQUENCY Hz", 2000, 12000, 1);
            addFloatControl (dynamicControls, "deThreshold", "THRESHOLD dB", -48, 0, 0.1f);
            addFloatControl (dynamicControls, "deAmount", "AMOUNT %", 0, 100, 1);
            break;
        case UltAudioProcessor::Saturator:
            addChoiceControl (dynamicControls, "satMode", "VOICING", { "TRIODE", "PENTODE", "TAPE" });
            addFloatControl (dynamicControls, "satDrive", "DRIVE dB", 0, 48, 0.1f);
            addFloatControl (dynamicControls, "satMix", "MIX %", 0, 100, 1);
            addFloatControl (dynamicControls, "satCharacter", "CHARACTER", 0, 100, 1);
            break;
        case UltAudioProcessor::OTT:
            addFloatControl (dynamicControls, "ottDepth", "DEPTH %", 0, 100, 1);
            addFloatControl (dynamicControls, "ottTime", "TIME %", 0, 1000, 1);
            addFloatControl (dynamicControls, "ottInput", "INPUT dB", -24, 19.1f, 0.1f);
            addFloatControl (dynamicControls, "ottOutput", "OUTPUT dB", -24, 19.1f, 0.1f);
            addFloatControl (dynamicControls, "ottUpward", "UPWARD %", 0, 200, 1);
            addFloatControl (dynamicControls, "ottDownward", "DOWNWARD %", 0, 200, 1);
            addFloatControl (dynamicControls, "ottThresholdLow", "LOW THRESH %", 0, 200, 1);
            addFloatControl (dynamicControls, "ottThresholdMid", "MID THRESH %", 0, 200, 1);
            addFloatControl (dynamicControls, "ottThresholdHigh", "HIGH THRESH %", 0, 200, 1);
            addFloatControl (dynamicControls, "ottGainLow", "LOW GAIN dB", -24, 6, 0.1f);
            addFloatControl (dynamicControls, "ottGainMid", "MID GAIN dB", -24, 6, 0.1f);
            addFloatControl (dynamicControls, "ottGainHigh", "HIGH GAIN dB", -24, 6, 0.1f);
            break;
        case UltAudioProcessor::Modulation:
            addChoiceControl (dynamicControls, "modModeV06", "MODE", { "DOUBLER", "CHORUS" });
            addFloatControl (dynamicControls, "modSend", "SEND %", 0, 100, 1);
            if (getParameter (processor, "modModeV06") < 0.5f)
            {
                addFloatControl (dynamicControls, "doubleOriginal", "ORIGINAL %", 0, 100, 1);
                addFloatControl (dynamicControls, "doubleDetune", "DOUBLER DETUNE cents", 0, 50, 0.1f);
                addFloatControl (dynamicControls, "doubleDelay", "DOUBLER DELAY ms", 0, 50, 0.1f);
            }
            else
                addFloatControl (dynamicControls, "modCharacter", "CHORUS CHARACTER", 0, 100, 1);
            break;
        default: break;
    }
    resized();
}

void UltAudioProcessorEditor::showAddEffectWindow (int position)
{
    if (addEffectOverlay == nullptr)
    {
        addEffectOverlay = std::make_unique<AddEffectOverlay> (*this);
        addAndMakeVisible (*addEffectOverlay);
    }
    addEffectOverlay->setTransform (juce::AffineTransform());
    addEffectOverlay->setInsertPosition (position);
    addEffectOverlay->setBounds (getLocalBounds());
    addEffectOverlay->setVisible (true);
    addEffectOverlay->toFront (false);
    addEffectOverlay->grabKeyboardFocus();
}

juce::File UltAudioProcessorEditor::getPresetFolder() const
{
    return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
        .getChildFile ("swagghazard").getChildFile ("ult").getChildFile ("Presets");
}

void UltAudioProcessorEditor::refreshPresetList()
{
    const auto folder = getPresetFolder();
    folder.createDirectory();
    presetFiles.clear();
    const auto files = folder.findChildFiles (juce::File::findFiles, false, "*.ultpreset");
    for (const auto& file : files) presetFiles.push_back (file);
    std::sort (presetFiles.begin(), presetFiles.end(), [] (const juce::File& a, const juce::File& b)
    {
        return a.getFileName().compareIgnoreCase (b.getFileName()) < 0;
    });
}

juce::String UltAudioProcessorEditor::makePresetFingerprint() const
{
    const auto state = processor.apvts.copyState();
    juce::String fingerprint;

    for (int i = 0; i < state.getNumChildren(); ++i)
    {
        const auto parameter = state.getChild (i);
        const auto id = parameter.getProperty ("id").toString();
        if (id.isNotEmpty())
            fingerprint << id << "=" << parameter.getProperty ("value").toString() << ";";
    }

    fingerprint << "|chain=";
    for (const auto id : processor.getChainOrder())
        fingerprint << id << ",";

    return fingerprint;
}

void UltAudioProcessorEditor::setCurrentPresetName (const juce::String& name)
{
    currentPresetName = name.isNotEmpty() ? name : "Init";
    processor.apvts.state.setProperty ("ultPresetName", currentPresetName, nullptr);
    presetStateSnapshot = makePresetFingerprint();
    processor.apvts.state.setProperty ("ultPresetBaseline", presetStateSnapshot, nullptr);
    presetSelector.setButtonText (currentPresetName);
}

void UltAudioProcessorEditor::updatePresetDisplay()
{
    const auto storedName = processor.apvts.state.getProperty ("ultPresetName").toString();
    if (storedName.isNotEmpty() && storedName != currentPresetName)
    {
        currentPresetName = storedName;
        presetStateSnapshot = processor.apvts.state.getProperty ("ultPresetBaseline").toString();
        if (presetStateSnapshot.isEmpty())
            presetStateSnapshot = makePresetFingerprint();
    }

    const bool modified = makePresetFingerprint() != presetStateSnapshot;
    const auto displayName = currentPresetName + (modified ? "*" : "");
    if (presetSelector.getButtonText() != displayName)
        presetSelector.setButtonText (displayName);
}

void UltAudioProcessorEditor::showPresetMenu()
{
    if (! presetSelector.isEnabled()) return;
    juce::PopupMenu menu;
    presetLook.popupScale = look.popupScale;
    presetLook.popupFontMultiplier = 1.25f;
    presetLook.setColour (juce::Slider::rotarySliderFillColourId, selectedAccent);
    menu.setLookAndFeel (&presetLook);
    menu.addSectionHeader ("FACTORY");
    for (int i = 0; i < factoryPresetNames().size(); ++i)
    {
        const auto name = factoryPresetNames()[i];
        menu.addItem (i + 2, name, true, name == currentPresetName);
    }

    if (! presetFiles.empty())
    {
        menu.addSeparator();
        menu.addSectionHeader ("USER");
        for (int i = 0; i < (int) presetFiles.size(); ++i)
        {
            const auto name = presetFiles[(size_t) i].getFileNameWithoutExtension();
            menu.addItem (100 + i, name, true, name == currentPresetName);
        }
    }

    // Disable the trigger for the entire lifetime of the popup. The popup is
    // anchored to the header and explicitly prefers a downward opening.
    presetSelector.setEnabled (false);
    juce::Component::SafePointer<UltAudioProcessorEditor> safeThis (this);
    const auto buttonScreenBounds = presetSelector.getScreenBounds();
    const auto* display = juce::Desktop::getInstance().getDisplays().getDisplayForRect (buttonScreenBounds);
    const int displayTop = display != nullptr ? (int) std::lround (display->userBounds.getY()) : 0;
    // Make the target area start at the top of the current display and end at
    // the button's bottom edge. JUCE therefore always has more room below the
    // target than above it; long lists scroll rather than flipping upwards.
    const auto downwardAnchor = juce::Rectangle<int> (buttonScreenBounds.getX(), displayTop,
        buttonScreenBounds.getWidth(), juce::jmax (1, buttonScreenBounds.getBottom() - displayTop));
    const auto options = juce::PopupMenu::Options()
        .withTargetComponent (&presetSelector)
        .withTargetScreenArea (downwardAnchor)
        .withMinimumWidth (buttonScreenBounds.getWidth())
        .withStandardItemHeight (juce::jmax (1, juce::roundToInt (26.0f * look.popupScale)))
        .withPreferredPopupDirection (juce::PopupMenu::Options::PopupDirection::downwards);
    menu.showMenuAsync (options, [safeThis] (int selectedId)
    {
        if (safeThis == nullptr) return;
        safeThis->presetSelector.setEnabled (true);
        if (selectedId >= 2 && selectedId < 2 + factoryPresetNames().size())
            safeThis->loadFactoryPreset (selectedId - 2);
        else if (selectedId >= 100)
        {
            const int index = selectedId - 100;
            if (index >= 0 && index < (int) safeThis->presetFiles.size())
                safeThis->loadPresetFile (safeThis->presetFiles[(size_t) index]);
        }
    });
}

void UltAudioProcessorEditor::savePresetFile()
{
    auto folder = getPresetFolder();
    folder.createDirectory();
    chooser = std::make_unique<juce::FileChooser> ("Save ult preset",
        folder.getChildFile ("My Vocal.ultpreset"), "*.ultpreset");
    juce::Component::SafePointer<UltAudioProcessorEditor> safeThis (this);
    chooser->launchAsync (juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles
                          | juce::FileBrowserComponent::warnAboutOverwriting,
        [safeThis] (const juce::FileChooser& fc)
        {
            if (safeThis == nullptr) return;
            auto file = fc.getResult();
            if (file == juce::File()) return;
            file = file.withFileExtension (".ultpreset");
            const auto previousName = safeThis->currentPresetName;
            safeThis->setCurrentPresetName (file.getFileNameWithoutExtension());
            juce::MemoryBlock state;
            safeThis->processor.writeState (state, false);
            if (! file.replaceWithData (state.getData(), state.getSize()))
            {
                safeThis->setCurrentPresetName (previousName);
                juce::AlertWindow::showMessageBoxAsync (juce::AlertWindow::WarningIcon, "ult", "Could not save preset.");
                return;
            }
            safeThis->refreshPresetList();
        });
}

void UltAudioProcessorEditor::loadFactoryPreset (int presetIndex)
{
    const int index = juce::jlimit (0, factoryPresetNames().size() - 1, presetIndex);
    if (index == 6)
    {
        // The user's original iMan state is embedded as a factory resource.
        processor.restoreState (BinaryData::iMan_ultpreset, BinaryData::iMan_ultpresetSize, false);
        // The refreshed user preset contains the new EQ slope schema. The
        // missing optional slope-5 value in the supplied file uses the 24 dB/oct default.
        setParameter (processor, "eqSlope5", 2.0f);
        setCurrentPresetName (factoryPresetNames()[index]);
        const auto order = processor.getChainOrder();
        selectEffect (std::find (order.begin(), order.end(), selectedEffect) != order.end() ? selectedEffect : (order.empty() ? -1 : order.front()));
        chainView.syncFromProcessor (true);
        chainView.repaint();
        repaint();
        return;
    }
    auto set = [this] (const juce::String& id, float value) { setParameter (processor, id, value); };

    // Start from a deterministic neutral state. Presets are complete snapshots,
    // not partial patches, so switching between factory presets is predictable.
    for (int id : { UltAudioProcessor::Gate, UltAudioProcessor::Autotune,
                    UltAudioProcessor::OctaveShifterId, UltAudioProcessor::EQ,
                    UltAudioProcessor::Compressor, UltAudioProcessor::DeEsser,
                    UltAudioProcessor::Saturator, UltAudioProcessor::OTT,
                    UltAudioProcessor::Modulation })
        processor.setEffectEnabled (id, false);

    set ("delayOn", 0.0f);
    set ("reverbOn", 0.0f);
    set ("inputGain", 0.0f);
    set ("outputGain", 0.0f);
    set ("gateThreshold", -52.0f);
    set ("gateRelease", 120.0f);
    set ("tuneKey", 0.0f); set ("tuneScale", 1.0f); set ("tuneDetune", 440.0f);
    set ("tuneRetune", 35.0f); set ("tuneHumanize", 12.0f); set ("tuneVoice", 0.0f);
    set ("octaveOriginal", 100.0f); set ("octaveDown", 0.0f); set ("octaveUp", 0.0f);
    for (int i = 1; i <= 5; ++i) set ("eqBandEnabled" + juce::String (i), 1.0f);
    set ("eqFreq1", 80.0f); set ("eqFreq2", 220.0f); set ("eqFreq3", 950.0f);
    set ("eqFreq4", 3500.0f); set ("eqFreq5", 11000.0f);
    set ("eqGain1", 0.0f); set ("eqGain2", 0.0f); set ("eqGain3", 0.0f);
    set ("eqGain4", 0.0f); set ("eqGain5", 0.0f);
    set ("eqQ1", 0.85f); set ("eqQ2", 0.85f); set ("eqQ3", 0.85f);
    set ("eqQ4", 0.85f); set ("eqQ5", 0.85f);
    set ("eqType1", 0.0f); set ("eqType5", 0.0f);
    set ("eqSlope1", 2.0f); set ("eqSlope5", 2.0f);
    set ("compInput", 12.0f); set ("compOutput", 0.0f); set ("compRatio", 0.0f);
    set ("deFreq", 6500.0f); set ("deThreshold", -22.0f);
    set ("satMode", 0.0f); set ("satDrive", 6.0f); set ("satMix", 28.0f); set ("satCharacter", 55.0f);
    set ("ottDepth", 55.0f); set ("ottTime", 100.0f); set ("ottInput", 0.0f); set ("ottOutput", 0.0f);
    set ("ottUpward", 100.0f); set ("ottDownward", 100.0f);
    set ("ottThresholdLow", 100.0f); set ("ottThresholdMid", 100.0f); set ("ottThresholdHigh", 100.0f);
    set ("ottGainLow", 0.0f); set ("ottGainMid", 0.0f); set ("ottGainHigh", 0.0f);
    set ("modModeV06", 0.0f); set ("modSend", 0.0f); set ("doubleDetune", 23.0f);
    set ("doubleDelay", 7.0f); set ("doubleOriginal", 100.0f); set ("modCharacter", 55.0f);
    set ("deAmount", 75.0f);
    set ("delayMode", 0.0f); set ("delayNote", 3.0f); set ("delayFeel", 0.0f);
    set ("delayFeedback", 24.0f); set ("delayMix", 15.0f);
    set ("reverbMode", 1.0f); set ("reverbDecay", 1700.0f); set ("reverbCharacter", 60.0f);
    set ("reverbMix", 18.0f); set ("reverbDucking", 35.0f);

    std::vector<int> order;
    switch (index)
    {
        case 0: // Clean Vocal
            order = { UltAudioProcessor::Gate, UltAudioProcessor::Autotune, UltAudioProcessor::EQ,
                      UltAudioProcessor::Compressor, UltAudioProcessor::DeEsser };
            set ("compInput", 2.0f); set ("deThreshold", -26.0f);
            set ("eqFreq2", 250.0f); set ("eqGain2", -1.5f);
            break;

        case 1: // Warm Tube
            order = { UltAudioProcessor::Gate, UltAudioProcessor::EQ, UltAudioProcessor::Compressor,
                      UltAudioProcessor::Saturator, UltAudioProcessor::DeEsser, UltAudioProcessor::Modulation };
            set ("satMode", 0.0f); set ("satDrive", 8.0f); set ("satMix", 38.0f);
            set ("satCharacter", 68.0f); set ("modModeV06", 0.0f); set ("modSend", 10.0f);
            set ("reverbMix", 12.0f); set ("reverbOn", 1.0f);
            break;

        case 2: // Modern Rap
            order = { UltAudioProcessor::Gate, UltAudioProcessor::Autotune, UltAudioProcessor::EQ,
                      UltAudioProcessor::Compressor, UltAudioProcessor::DeEsser, UltAudioProcessor::OTT };
            set ("tuneRetune", 8.0f); set ("compInput", 10.0f); set ("compRatio", 1.0f);
            set ("ottDepth", 42.0f); set ("ottUpward", 85.0f); set ("ottDownward", 115.0f);
            set ("delayMix", 10.0f); set ("delayOn", 1.0f);
            set ("reverbMix", 8.0f); set ("reverbOn", 1.0f);
            break;

        case 3: // Wide Chorus
            order = { UltAudioProcessor::Autotune, UltAudioProcessor::EQ, UltAudioProcessor::Compressor,
                      UltAudioProcessor::Modulation };
            set ("modModeV06", 1.0f); set ("modCharacter", 72.0f); set ("modSend", 28.0f);
            set ("reverbMix", 16.0f); set ("reverbOn", 1.0f);
            break;

        case 4: // Airy Space
            order = { UltAudioProcessor::EQ, UltAudioProcessor::DeEsser, UltAudioProcessor::Modulation,
                      UltAudioProcessor::OTT };
            set ("modModeV06", 1.0f); set ("modCharacter", 62.0f); set ("modSend", 18.0f);
            set ("ottDepth", 32.0f); set ("reverbMode", 2.0f); set ("reverbDecay", 5200.0f);
            set ("reverbMix", 30.0f); set ("reverbDucking", 24.0f); set ("reverbOn", 1.0f);
            set ("delayMode", 1.0f); set ("delayFeel", 1.0f); set ("delayMix", 12.0f); set ("delayOn", 1.0f);
            break;

        case 5: // Aggressive OTT
            order = { UltAudioProcessor::Gate, UltAudioProcessor::EQ, UltAudioProcessor::Saturator,
                      UltAudioProcessor::OTT, UltAudioProcessor::Compressor };
            set ("satMode", 1.0f); set ("satDrive", 14.0f); set ("satMix", 48.0f);
            set ("ottDepth", 100.0f); set ("ottUpward", 145.0f); set ("ottDownward", 150.0f);
            set ("compInput", 12.0f); set ("compRatio", 2.0f);
            break;
        default:
            order = { UltAudioProcessor::Gate, UltAudioProcessor::EQ, UltAudioProcessor::Compressor };
            break;
    }

    // All factory presets use the agreed standard compressor calibration.
    set ("compInput", 18.0f);
    set ("compOutput", 0.0f);

    processor.setChainOrder (order);
    for (const int id : order)
        processor.setEffectEnabled (id, true);

    setCurrentPresetName (factoryPresetNames()[index]);

    // Complete the parameter panel first, then publish a forced visual chain
    // snapshot. This prevents a preset switch from leaving stale/empty cards.
    selectEffect (std::find (order.begin(), order.end(), selectedEffect) != order.end() ? selectedEffect : (order.empty() ? -1 : order.front()));
    chainView.syncFromProcessor (true);
    chainView.repaint();
    repaint();
}

void UltAudioProcessorEditor::loadPresetFile (const juce::File& file)
{
    if (! file.existsAsFile()) return;
    juce::MemoryBlock state;
    if (file.loadFileAsData (state))
    {
        processor.restoreState (state.getData(), (int) state.getSize(), false);
        setParameter (processor, "compInput", 18.0f);
        // Preserve the output gain stored in user presets.
        setCurrentPresetName (file.getFileNameWithoutExtension());
        const auto order = processor.getChainOrder();
        selectEffect (std::find (order.begin(), order.end(), selectedEffect) != order.end() ? selectedEffect : (order.empty() ? -1 : order.front()));
        chainView.syncFromProcessor (true);
        chainView.repaint();
        repaint();
    }
}


// v0.9.15: monophonic output pitch indicator. All estimation is on the UI thread.
void UltAudioProcessorEditor::PitchDisplay::tick()
{
    if (! processor.isEffectEnabled (UltAudioProcessor::Autotune)
        || ! processor.stagePresent[(size_t) UltAudioProcessor::Autotune].load (std::memory_order_relaxed))
    {
        hasPitch = false; smoothedMidi = -1.0f; repaint(); return;
    }
    const auto count = processor.tuneOutputCount.load (std::memory_order_acquire);
    if (count == lastCount || count < (uint64_t) UltAudioProcessor::tuneSpectrumSize)
    {
        hasPitch = false; repaint(); return;
    }
    lastCount = count;
    constexpr int N = UltAudioProcessor::tuneSpectrumSize;
    std::array<float, N> samples {};
    double energy = 0.0;
    for (int i = 0; i < N; ++i)
    {
        const auto index = (size_t) ((count - N + (uint64_t) i) % N);
        samples[(size_t) i] = processor.tuneOutputSamples[index].load (std::memory_order_relaxed);
        energy += (double) samples[(size_t) i] * samples[(size_t) i];
    }
    if (energy / N < 0.000003)
    {
        hasPitch = false; smoothedMidi = -1.0f; repaint(); return;
    }
    const double sampleRate = processor.tuneOutputSampleRate.load (std::memory_order_relaxed);
    const int minLag = juce::jmax (2, (int) (sampleRate / 1000.0));
    const int maxLag = juce::jmin (N / 2, (int) (sampleRate / 75.0));
    float best = 0.0f;
    int bestLag = 0;
    std::array<float, N / 2 + 1> scores {};
    // Normalised autocorrelation avoids choosing a lag simply due to amplitude.
    for (int lag = minLag; lag <= maxLag; ++lag)
    {
        double corr = 0.0, a = 0.0, b = 0.0;
        for (int i = 0; i < N - lag; i += 2)
        {
            const double x = samples[(size_t) i], y = samples[(size_t) (i + lag)];
            corr += x * y; a += x * x; b += y * y;
        }
        const float score = (float) (corr / std::sqrt (a * b + 1.0e-20));
        scores[(size_t) lag] = score;
        if (score > best) { best = score; bestLag = lag; }
    }
    if (bestLag == 0 || best < 0.82f)
    {
        hasPitch = false; smoothedMidi = -1.0f; repaint(); return;
    }
    for (int lag = minLag + 1; lag < maxLag; ++lag)
        if (scores[(size_t) lag] >= best * 0.94f && scores[(size_t) lag] >= scores[(size_t) lag - 1] && scores[(size_t) lag] >= scores[(size_t) lag + 1]) { bestLag = lag; break; }
    float refinedLag = (float) bestLag;
    if (bestLag > minLag && bestLag < maxLag)
    {
        const float a = scores[(size_t) bestLag - 1], b = scores[(size_t) bestLag], c = scores[(size_t) bestLag + 1];
        const float denominator = a - 2.0f * b + c;
        if (std::abs (denominator) > 1.0e-8f) refinedLag += juce::jlimit (-0.5f, 0.5f, 0.5f * (a - c) / denominator);
    }
    const float hz = (float) (sampleRate / refinedLag);
    const float midi = 69.0f + 12.0f * std::log2 (hz / processor.apvts.getRawParameterValue ("tuneDetune")->load());
    smoothedMidi = smoothedMidi < 0.0f ? midi : (0.75f * midi + 0.25f * smoothedMidi);
    hasPitch = true;
    repaint();
}

void UltAudioProcessorEditor::PitchDisplay::paint (juce::Graphics& g)
{
    if (getWidth() <= 0 || getHeight() <= 0) return;
    juce::Graphics::ScopedSaveState saved (g);
    g.addTransform (juce::AffineTransform::scale (getWidth() / 600.0f, getHeight() / 236.0f));
    const auto r = juce::Rectangle<float> (0, 0, 600, 236).reduced (4.0f);
    g.setColour (juce::Colour (0xff101010).interpolatedWith (getLookAndFeel().findColour (juce::Slider::rotarySliderFillColourId), 0.035f)); g.fillRoundedRectangle (r, 8.0f);
    const auto accent = getLookAndFeel().findColour (juce::Slider::rotarySliderFillColourId);
    g.setColour (juce::Colours::white.withAlpha (0.5f));
    g.setFont (13.0f);
    g.drawText ("CORRECTED PITCH", r.toNearestInt().removeFromTop (28), juce::Justification::centred);
    const float cx = r.getCentreX(), half = juce::jmin (220.0f, r.getWidth() * 0.42f);
    const float y = r.getCentreY() + 40.0f;
    g.setColour (juce::Colours::white.withAlpha (0.25f));
    g.drawLine (cx - half, y, cx + half, y, 1.0f);
    for (int cents = -100; cents <= 100; cents += 50)
    {
        const float x = cx + half * cents / 100.0f;
        g.setColour (cents == 0 ? accent.withAlpha (0.8f) : juce::Colours::white.withAlpha (0.4f));
        g.drawLine (x, y - 8.0f, x, y + 8.0f, 1.5f);
        g.setFont (11.0f);
        g.drawText (juce::String (cents), (int) x - 22, (int) y + 10, 44, 18, juce::Justification::centred);
    }
    if (! hasPitch) return;
    static constexpr const char* names[] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
    const int note = (int) std::round (smoothedMidi);
    const int cents = juce::jlimit (-100, 100, (int) std::round ((smoothedMidi - note) * 100.0f));
    const int octave = note / 12 - 1;
    g.setColour (accent); g.setFont (juce::Font (34.0f, juce::Font::bold));
    g.drawText (juce::String (names[((note % 12) + 12) % 12]) + juce::String (octave),
                (int) cx - 80, (int) y - 95, 160, 48, juce::Justification::centred);
    const float x = cx + half * cents / 100.0f;
    g.fillEllipse (x - 5.0f, y - 5.0f, 10.0f, 10.0f);
    g.setFont (13.0f);
    g.drawText (juce::String (cents > 0 ? "+" : "") + juce::String (cents) + " cents",
                (int) cx - 80, (int) y - 45, 160, 24, juce::Justification::centred);
}

void UltAudioProcessorEditor::timerCallback()
{
    synchronizeSharedLayout();
    const bool showing = isShowing();
    processor.visualizationActive.store (showing, std::memory_order_relaxed);
    if (! showing) return;
    if (! juce::KeyPress::isKeyCurrentlyDown ('4')) editShortcutDown = false;
    auto refreshValue = [] (juce::Slider& slider, juce::Label& value)
    {
        if (! value.isBeingEdited())
            value.setText (slider.getTextFromValue (slider.getValue()), juce::dontSendNotification);
    };
    refreshValue (inputGain, inputGainValue);
    refreshValue (outputGain, outputGainValue);
    for (auto* group : { &dynamicControls, &delayControls, &reverbControls })
        for (auto& c : *group)
            if (c->slider && c->value) refreshValue (*c->slider, *c->value);
    meter.refresh();
    chainView.syncFromProcessor();
    chainView.animate();
    updatePresetDisplay();
    if (eqGraph.isShowing()) { eqGraph.updateSpectrum(); eqGraph.repaint(); }
    if (stageHistory.isShowing()) stageHistory.tick();
    if (pitchDisplay.isShowing()) pitchDisplay.tick();
}


juce::File UltAudioProcessorEditor::getLayoutFile() const
{
    auto folder = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
                      .getChildFile ("ULT").getChildFile ("Layouts");
    folder.createDirectory();
    return folder.getChildFile ("default.xml");
}

void UltAudioProcessorEditor::observeCurrentLayoutFile()
{
    const auto file = getLayoutFile();
    layoutFileWasPresent = file.existsAsFile();
    observedLayoutModification = layoutFileWasPresent ? file.getLastModificationTime() : juce::Time();
    observedLayoutSize = layoutFileWasPresent ? file.getSize() : -1;
    layoutSyncInitialized = true;
}

void UltAudioProcessorEditor::synchronizeSharedLayout()
{
    const auto file = getLayoutFile();
    const bool present = file.existsAsFile();
    const auto modified = present ? file.getLastModificationTime() : juce::Time();
    const auto size = present ? file.getSize() : -1;
    if (! layoutSyncInitialized)
    {
        observeCurrentLayoutFile();
        return;
    }
    if (present == layoutFileWasPresent && modified == observedLayoutModification
        && size == observedLayoutSize)
        return;

    // Keep each editor's own window size. A shared layout update changes geometry only.
    observeCurrentLayoutFile();
    if (layoutEditOverlay != nullptr)
        layoutEditOverlay->clearSelection();
    // A remote save/reset wins over local uncommitted layout edits.
    // In edit mode resized() intentionally preserves the local geometry, so
    // force the shared snapshot to be applied first.
    setAccentColour (juce::Colour (0xffa6ff00));
    layoutDraft.reset();
    const juce::ScopedValueSetter<bool> reload (layoutForceReload, true);
    resized();
    applySavedLayout();
}

void UltAudioProcessorEditor::setAccentColour (juce::Colour colour)
{
    selectedAccent = colour;
    look.setColour (juce::PopupMenu::highlightedBackgroundColourId, panel.interpolatedWith (colour, 0.22f));
    look.setColour (juce::PopupMenu::highlightedTextColourId, colour);
    look.setColour (juce::Slider::rotarySliderFillColourId, colour);
    accentButton.setColour (juce::TextButton::textColourOffId, colour);
    repaint();
    for (int i = 0; i < getNumChildComponents(); ++i)
        getChildComponent (i)->repaint();
}

void UltAudioProcessorEditor::assignLayoutIds()
{
    if (brand.getComponentID().isEmpty()) brand.setComponentID ("fixed_brand");
    if (signature.getComponentID().isEmpty()) signature.setComponentID ("fixed_signature");
    if (panelTitle.getComponentID().isEmpty()) panelTitle.setComponentID ("fixed_panelTitle");
    if (inputGain.getComponentID().isEmpty()) inputGain.setComponentID ("fixed_inputGain");
    if (outputGain.getComponentID().isEmpty()) outputGain.setComponentID ("fixed_outputGain");
    if (inputGainLabel.getComponentID().isEmpty()) inputGainLabel.setComponentID ("fixed_inputGainLabel");
    if (outputGainLabel.getComponentID().isEmpty()) outputGainLabel.setComponentID ("fixed_outputGainLabel");
    if (meter.getComponentID().isEmpty()) meter.setComponentID ("fixed_meter");
    if (presetSelector.getComponentID().isEmpty()) presetSelector.setComponentID ("fixed_presetSelector");
    if (savePreset.getComponentID().isEmpty()) savePreset.setComponentID ("fixed_savePreset");
    if (editLayoutButton.getComponentID().isEmpty()) editLayoutButton.setComponentID ("fixed_editLayoutButton");
    if (saveLayoutButton.getComponentID().isEmpty()) saveLayoutButton.setComponentID ("fixed_saveLayoutButton");
    if (resetLayoutButton.getComponentID().isEmpty()) resetLayoutButton.setComponentID ("fixed_resetLayoutButton");
    if (layoutMenuButton.getComponentID().isEmpty()) layoutMenuButton.setComponentID ("fixed_layoutMenuButton");
    if (accentButton.getComponentID().isEmpty()) accentButton.setComponentID ("fixed_accentButton");
    if (chainView.getComponentID().isEmpty()) chainView.setComponentID ("fixed_chainView");
    if (eqGraph.getComponentID().isEmpty()) eqGraph.setComponentID ("fixed_eqGraph");
    if (stageHistory.getComponentID().isEmpty()) stageHistory.setComponentID ("fixed_stageHistory");
    if (pitchDisplay.getComponentID().isEmpty()) pitchDisplay.setComponentID ("fixed_pitchDisplay");
    if (eqBandLabel.getComponentID().isEmpty()) eqBandLabel.setComponentID ("fixed_eqBandLabel");
    if (eqBandSelector.getComponentID().isEmpty()) eqBandSelector.setComponentID ("fixed_eqBandSelector");
    if (delayPower.getComponentID().isEmpty()) delayPower.setComponentID ("fixed_delayPower");
    if (reverbPower.getComponentID().isEmpty()) reverbPower.setComponentID ("fixed_reverbPower");
}

bool UltAudioProcessorEditor::validLayout (const juce::XmlElement& xml) const
{
    const auto integer = [] (const juce::XmlElement& element, const juce::String& name)
    {
        const auto value = element.getStringAttribute (name);
        return value.isNotEmpty() && value.length() <= 4 && value.containsOnly ("0123456789");
    };
    if (! xml.hasTagName ("ULT_LAYOUT") || xml.getStringAttribute ("format_version") != "2"
        || ! integer (xml, "window_width") || ! integer (xml, "window_height")) return false;
    const auto colour = xml.getStringAttribute ("accent");
    if (colour.length() != 8 || ! colour.containsOnly ("0123456789abcdefABCDEF")) return false;
    const int ww = xml.getIntAttribute ("window_width"), wh = xml.getIntAttribute ("window_height");
    if (ww < 990 || ww > 2640 || wh < 555 || wh > 1480) return false;
    juce::StringArray ids;
    for (auto* item : xml.getChildIterator())
    {
        if (item->getNumChildElements() != 0 || ! integer (*item, "x") || ! integer (*item, "y")
            || ! integer (*item, "w") || ! integer (*item, "h")) return false;
        const auto id = item->getStringAttribute ("id");
        bool known = id == "biohazard" || id == "fixed_biohazardButton" || id == "fixed_stageHistory_0" || id == "fixed_stageHistory_5" || id == "fixed_stageHistory_6" || id == "fixed_stageHistory";
        for (auto prefix : { "knob_", "label_", "choice_", "value_" })
            if (id.startsWith (prefix) && processor.apvts.getParameter (id.substring (juce::String (prefix).length())) != nullptr) known = true;
        for (int i = 0; i < getNumChildComponents(); ++i)
            if (getChildComponent (i)->getComponentID() == id && id.isNotEmpty()) known = true;
        const int x = item->getIntAttribute ("x", -1), y = item->getIntAttribute ("y", -1);
        const int w = item->getIntAttribute ("w", -1), h = item->getIntAttribute ("h", -1);
        if (! item->hasTagName ("COMPONENT") || ! known || ids.contains (id)
            || x < 0 || y < 0 || w < 1 || h < 1 || x > 1320 || y > 740 || w > 1320 - x || h > 740 - y) return false;
        ids.add (id);
    }
    return ! ids.isEmpty();
}

std::unique_ptr<juce::XmlElement> UltAudioProcessorEditor::captureLayout (const juce::XmlElement* previous) const
{
    auto xml = std::make_unique<juce::XmlElement> ("ULT_LAYOUT");
    xml->setAttribute ("format_version", 2);
    xml->setAttribute ("accent", selectedAccent.toString());
    xml->setAttribute ("window_width", getWidth());
    xml->setAttribute ("window_height", getHeight());
    auto defaults = juce::XmlDocument::parse (juce::String::fromUTF8 (BinaryData::DefaultLayout_xml, BinaryData::DefaultLayout_xmlSize));
    if (previous == nullptr || ! validLayout (*previous)) previous = defaults.get();
    if (previous != nullptr && validLayout (*previous))
        for (auto* item : previous->getChildIterator())
            if (item->getStringAttribute ("id") != "biohazard" && item->getStringAttribute ("id") != "fixed_biohazardButton")
                xml->addChildElement (new juce::XmlElement (*item));
    for (int i = 0; i < getNumChildComponents(); ++i)
    {
        auto* c = getChildComponent (i);
        const auto id = c->getComponentID();
        if (id.isEmpty() || ! c->isVisible() || c == layoutEditOverlay.get() || c == addEffectOverlay.get()) continue;
        auto bounds = c->getBounds();
        if (bounds.isEmpty()) continue;
        bounds = bounds.getIntersection ({ 0, 0, 1320, 740 });
        if (bounds.isEmpty()) continue;
        juce::XmlElement* entry = nullptr;
        for (auto* item : xml->getChildIterator()) if (item->getStringAttribute ("id") == id) { entry = item; break; }
        if (entry == nullptr) entry = xml->createNewChildElement ("COMPONENT");
        entry->setAttribute ("id", id);
        entry->setAttribute ("x", bounds.getX()); entry->setAttribute ("y", bounds.getY());
        entry->setAttribute ("w", bounds.getWidth()); entry->setAttribute ("h", bounds.getHeight());
    }
    return xml;
}

void UltAudioProcessorEditor::saveCurrentLayout()
{
    auto previous = juce::XmlDocument::parse (getLayoutFile());
    auto xml = captureLayout (layoutDraft ? layoutDraft.get() : previous.get());
    // Atomic replacement avoids other instances observing a half-written XML.
    const auto destination = getLayoutFile();
    const auto temporary = destination.getSiblingFile ("default.xml.tmp");
    const bool saved = validLayout (*xml) && xml->writeTo (temporary) && temporary.replaceFileIn (destination);
    if (! saved)
    {
        juce::NativeMessageBox::showMessageBoxAsync (juce::AlertWindow::WarningIcon,
            "Layout Save Failed", "ULT could not save the layout file.", this);
        return;
    }
    layoutDraft = std::make_unique<juce::XmlElement> (*xml);
    observeCurrentLayoutFile();
    saveLayoutButton.setButtonText ("SAVED");
    juce::Timer::callAfterDelay (1200, [safe = juce::Component::SafePointer<UltAudioProcessorEditor> (this)]
    {
        if (safe != nullptr) safe->saveLayoutButton.setButtonText ("SAVE LAYOUT");
    });
}

void UltAudioProcessorEditor::showLayoutMenu()
{
    juce::PopupMenu menu;
    menu.setLookAndFeel (&look);
    menu.addItem (1, "Load Layout...");
    menu.addItem (2, "Save Layout As...");
    menu.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&layoutMenuButton),
                        [safe = juce::Component::SafePointer<UltAudioProcessorEditor> (this)] (int choice)
    {
        if (safe == nullptr || choice == 0) return;
        if (choice == 1)
        {
            safe->chooser = std::make_unique<juce::FileChooser> ("Load ULT Layout", safe->getLayoutFile().getParentDirectory(), "*.xml");
            safe->chooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
                                       [safe] (const juce::FileChooser& fc)
            {
                if (safe == nullptr) return;
                const auto file = fc.getResult();
                if (! file.existsAsFile()) return;
                auto xml = juce::XmlDocument::parse (file);
                if (xml == nullptr || ! safe->validLayout (*xml))
                {
                    juce::NativeMessageBox::showMessageBoxAsync (juce::AlertWindow::WarningIcon,
                        "Invalid Layout", "Invalid or incompatible ULT layout (stable-ID format 2 required).", safe.getComponent());
                    return;
                }
                const int requestedWidth = xml->getIntAttribute ("window_width");
                const int requestedHeight = xml->getIntAttribute ("window_height");
                if (safe->layoutEditOverlay) safe->layoutEditOverlay->checkpoint();
                const auto destination = safe->getLayoutFile();
                const auto temporary = destination.getSiblingFile ("import.xml.tmp");
                const bool imported = (file == destination)
                    || (file.copyFileTo (temporary) && temporary.replaceFileIn (destination));
                if (! imported)
                {
                    juce::NativeMessageBox::showMessageBoxAsync (juce::AlertWindow::WarningIcon,
                        "Layout Import Failed", "Could not replace the active layout.", safe.getComponent());
                    return;
                }
                safe->layoutDraft.reset();
                const juce::ScopedValueSetter<bool> reload (safe->layoutForceReload, true);
                safe->observeCurrentLayoutFile();
                safe->setSize (requestedWidth, requestedHeight);
                safe->resized();
                safe->applySavedLayout();
            });
        }
        else if (choice == 2)
        {
            safe->chooser = std::make_unique<juce::FileChooser> ("Export ULT Layout", safe->getLayoutFile().getParentDirectory(), "*.xml");
            safe->chooser->launchAsync (juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles | juce::FileBrowserComponent::warnAboutOverwriting,
                                       [safe] (const juce::FileChooser& fc)
            {
                if (safe == nullptr) return;
                auto target = fc.getResult();
                if (target == juce::File()) return;
                target = target.withFileExtension ("xml");
                // Export the active geometry, without changing the global saved layout.
                auto previous = juce::XmlDocument::parse (safe->getLayoutFile());
                auto xml = safe->captureLayout (safe->layoutDraft ? safe->layoutDraft.get() : previous.get());
                if (! safe->validLayout (*xml) || ! xml->writeTo (target))
                    juce::NativeMessageBox::showMessageBoxAsync (juce::AlertWindow::WarningIcon,
                        "Export Failed", "Could not export ULT layout.", safe.getComponent());
            });
        }
    });
}

void UltAudioProcessorEditor::applySavedLayout()
{
    assignLayoutIds();
    auto file = getLayoutFile();
    auto xml = juce::XmlDocument::parse (file);
    if (xml == nullptr || ! validLayout (*xml))
        xml = juce::XmlDocument::parse (juce::String::fromUTF8 (BinaryData::DefaultLayout_xml, BinaryData::DefaultLayout_xmlSize));
    if (xml == nullptr || ! validLayout (*xml)) return;
    if (xml->hasAttribute ("accent"))
        setAccentColour (juce::Colour::fromString (xml->getStringAttribute ("accent")));
    applyLayoutGeometry (*xml);
}

void UltAudioProcessorEditor::captureLayoutDraft()
{
    if (layoutEditMode && ! layoutForceReload && ! layoutRebuilding)
    {
        assignLayoutIds();
        layoutDraft = captureLayout (layoutDraft.get());
    }
}

void UltAudioProcessorEditor::applyLayoutGeometry (const juce::XmlElement& layout)
{
    const auto* xml = &layout;
    for (auto* item : xml->getChildIterator())
    {
        if (! item->hasTagName ("COMPONENT")) continue;
        auto id = item->getStringAttribute ("id");
        for (int i = 0; i < getNumChildComponents(); ++i)
        {
            auto* c = getChildComponent (i);
            if (c->getComponentID() == id || (c == &stageHistory && id == "fixed_stageHistory" && xml->getChildByAttribute ("id", c->getComponentID()) == nullptr))
            {
                auto x = item->getIntAttribute ("x"), y = item->getIntAttribute ("y");
                auto w = item->getIntAttribute ("w"), h = item->getIntAttribute ("h");
                if (w >= 1 && h >= 1)
                    c->setBounds (juce::Rectangle<int> (x, y, w, h).getIntersection ({ 0, 0, 1320, 740 }));
                break;
            }
        }
    }
}

void UltAudioProcessorEditor::mouseDown (const juce::MouseEvent&) { grabKeyboardFocus(); }

bool UltAudioProcessorEditor::keyPressed (const juce::KeyPress& key)
{
    if (key.getKeyCode() != '4' || key.getModifiers().isAnyModifierKeyDown()) return false;
    if (! editShortcutDown && ! layoutEditMode)
        editLayoutButton.setVisible (! editLayoutButton.isVisible());
    editShortcutDown = true;
    return true;
}

void UltAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xff050505));
    const float scale = juce::jmin (getWidth() / 1320.0f, getHeight() / 740.0f);
    const float offsetX = (getWidth() - 1320.0f * scale) * 0.5f;
    const float offsetY = (getHeight() - 740.0f * scale) * 0.5f;
    g.addTransform (juce::AffineTransform::scale (scale).translated (offsetX, offsetY));
    g.setColour (juce::Colour (0xffbcbcbc));
    g.setFont (interFont (12.0f, true));
    g.drawText ("INSERT CHAIN", 24, 96, 220, 16, juce::Justification::centredLeft);
    g.drawText ("PARALLEL SENDS", 24, 540, 240, 16, juce::Justification::centredLeft);
    drawGlassPanel (g, panelArea.toFloat(), 12.0f);
    const int sendGap = 14;
    const int sendWidth = (sendsArea.getWidth() - sendGap) / 2;
    const juce::Rectangle<int> delayPanel (sendsArea.getX(), sendsArea.getY(), sendWidth, sendsArea.getHeight());
    const juce::Rectangle<int> reverbPanel (sendsArea.getX() + sendWidth + sendGap,
                                           sendsArea.getY(), sendWidth, sendsArea.getHeight());
    drawGlassPanel (g, delayPanel.toFloat(), 12.0f);
    drawGlassPanel (g, reverbPanel.toFloat(), 12.0f);
    g.setColour (juce::Colour (0xffaaaaaa));
    g.drawText ("EFFECT CONTROLS", panelArea.getRight() - 185, panelArea.getY() + 12, 160, 16,
                juce::Justification::centredRight);
    g.setColour (juce::Colour (0xff414141));
    g.drawLine ((float) panelArea.getX() + 18.0f, (float) panelArea.getY() + 40.0f,
                (float) panelArea.getRight() - 18.0f, (float) panelArea.getY() + 40.0f);
}

void UltAudioProcessorEditor::resized()
{
    captureLayoutDraft();
    // Fixed-size desktop composition: all four working zones remain visible
    // together, with no scroll area or user resizing that can hide sends.
    // Always lay out the design in the original 1320x740 coordinate system.
    // Scale the whole composition uniformly; never reflow individual columns.
    const int w = 1320;
    brand.setBounds (24, 2, 132, 48);
    signature.setBounds (24, 50, 140, 22);

    inputGainLabel.setBounds (180, 4, 120, 19);
    inputGain.setBounds (180, 23, 120, 42);
    inputGainValue.setBounds (180, 66, 120, 25);
    outputGainLabel.setBounds (305, 4, 120, 19);
    outputGain.setBounds (305, 23, 120, 42);
    outputGainValue.setBounds (305, 66, 120, 25);
    meter.setBounds (455, 17, 310, 55);

    presetSelector.setBounds (790, 20, 270, 40);
    savePreset.setBounds (1076, 20, 124, 40);
    editLayoutButton.setBounds (w - 340, 68, 104, 26);
    saveLayoutButton.setBounds (w - 230, 68, 108, 26);
    resetLayoutButton.setBounds (w - 116, 68, 108, 26);
    layoutMenuButton.setBounds (w - 458, 68, 112, 26);
    accentButton.setBounds (w - 574, 68, 110, 26);

    chainArea = { 20, 116, w - 40, 90 };
    chainView.setBounds (chainArea);

    panelArea = { 20, 234, w - 40, 298 };
    panelTitle.setBounds (40, 241, 420, 25);
    eqGraph.setBounds (panelArea.getX() + 18, panelArea.getY() + 48, 600, panelArea.getHeight() - 62);
    stageHistory.setBounds (panelArea.getX() + 18, panelArea.getY() + 48, 600, panelArea.getHeight() - 62);
    pitchDisplay.setBounds (panelArea.getX() + 18, panelArea.getY() + 48, 600, panelArea.getHeight() - 62);
    eqBandLabel.setBounds (panelArea.getX() + 642, panelArea.getY() + 49, 58, 20);
    eqBandSelector.setBounds (panelArea.getX() + 700, panelArea.getY() + 46, 150, 30);

    if (selectedEffect == UltAudioProcessor::EQ || selectedEffect == UltAudioProcessor::Gate
        || selectedEffect == UltAudioProcessor::Compressor || selectedEffect == UltAudioProcessor::DeEsser)
    {
        const int rightX = panelArea.getX() + 640;
        const int rightW = panelArea.getRight() - rightX - 18;
        const int count = (int) dynamicControls.size();
        const int cols = juce::jmax (1, count);
        const int slotW = rightW / cols;
        const int controlY = panelArea.getY() + 104;
        for (int i = 0; i < count; ++i)
        {
            auto& c = *dynamicControls[(size_t) i];
            const int x = rightX + i * slotW;
            if (c.label) c.label->setBounds (x, controlY, slotW - 4, 18);
            if (c.slider) c.slider->setBounds (x + (slotW - 108) / 2, controlY + 15, 108, 126);
            if (c.combo) c.combo->setBounds (x + (slotW - 144) / 2, controlY + 18, 144, 32);
        }
    }
    else
    {
        const int count = (int) dynamicControls.size();
        const int cols = selectedEffect == UltAudioProcessor::OTT ? 6 : (count >= 9 ? 4 : (count >= 5 ? 3 : juce::jmax (1, count)));
        const int rows = juce::jmax (1, (count + cols - 1) / cols);
        const bool tune = selectedEffect == UltAudioProcessor::Autotune;
        const int areaX = panelArea.getX() + (tune ? 640 : 20);
        const int areaY = panelArea.getY() + 43;
        const int areaW = panelArea.getRight() - areaX - 20;
        const int areaH = panelArea.getHeight() - 55;
        const int slotW = areaW / cols;
        const int slotH = areaH / rows;
        for (int i = 0; i < count; ++i)
        {
            auto& c = *dynamicControls[(size_t) i];
            const int layoutIndex = tune ? (i == 5 ? 2 : (i >= 2 ? i + 1 : i)) : i;
            const int col = layoutIndex % cols, row = layoutIndex / cols;
            const int x = areaX + col * slotW;
            const int y = areaY + row * slotH;
            if (c.label) c.label->setBounds (x + 4, y, slotW - 8, 18);
            if (c.slider)
            {
                const int knobW = juce::jmin (144, slotW - 12);
                c.slider->setBounds (x + (slotW - knobW) / 2, y + 14, knobW, slotH - 14);
            }
            if (c.combo)
            {
                const int comboW = juce::jmin (204, slotW - 24);
                c.combo->setBounds (x + (slotW - comboW) / 2, y + 30, comboW, 32);
            }
        }
    }

    sendsArea = { 20, 560, w - 40, 166 };
    const int sendGap = 14;
    const int sendWidth = (sendsArea.getWidth() - sendGap) / 2;
    const int reverbX = sendsArea.getX() + sendWidth + sendGap;
    delayPower.setBounds (sendsArea.getX() + 18, sendsArea.getY() + 8, 124, 28);
    reverbPower.setBounds (reverbX + 18, sendsArea.getY() + 8, 124, 28);

    auto layoutSendGroup = [&] (std::vector<std::unique_ptr<Control>>& controls, int x, int width)
    {
        const int count = (int) controls.size();
        const int slotW = width / juce::jmax (1, count);
        for (int i = 0; i < count; ++i)
        {
            auto& c = *controls[(size_t) i];
            const int xx = x + i * slotW;
            if (c.label) c.label->setBounds (xx, sendsArea.getY() + 49, slotW - 4, 17);
            if (c.slider)
            {
                const int knobW = juce::jmin (112, slotW - 8);
                c.slider->setBounds (xx + (slotW - knobW) / 2, sendsArea.getY() + 64, knobW, 94);
            }
            if (c.combo)
            {
                const int comboW = juce::jmin (116, slotW - 8);
                c.combo->setBounds (xx + (slotW - comboW) / 2, sendsArea.getY() + 72, comboW, 31);
            }
        }
    };
    layoutSendGroup (delayControls, sendsArea.getX() + 18, sendWidth - 36);
    layoutSendGroup (reverbControls, reverbX + 18, sendWidth - 36);
    auto splitKnob = [] (juce::Slider& slider, juce::Label& value, juce::Label& caption)
    {
        auto bounds = slider.getBounds();
        value.setBounds (bounds.removeFromBottom (juce::jmin (21, bounds.getHeight() / 3)).translated (0, -6));
        slider.setBounds (bounds);
        caption.setBounds (bounds.getX(), caption.getY(), bounds.getWidth(), caption.getHeight());
    };

    for (auto* group : { &dynamicControls, &delayControls, &reverbControls })
        for (auto& c : *group)
            if (c->slider && c->value && c->label) splitKnob (*c->slider, *c->value, *c->label);
    if (addEffectOverlay != nullptr) addEffectOverlay->setBounds (getLocalBounds());

    if (layoutEditOverlay != nullptr)
    {
        assignLayoutIds();
        if (! layoutEditMode || layoutForceReload) applySavedLayout();
        else if (layoutDraft) applyLayoutGeometry (*layoutDraft);
        layoutEditOverlay->setBounds (0, 0, 1320, 740);
        layoutEditOverlay->setVisible (layoutEditMode);
        layoutEditOverlay->toFront (false);
        editLayoutButton.toFront (false);
        saveLayoutButton.toFront (false);
        resetLayoutButton.toFront (false);
        layoutMenuButton.toFront (false);
        accentButton.toFront (false);
    }
    // The original logical layout is transformed as a whole.
    // This preserves all gaps, sizes, positions, and the saved XML coordinates.
    const float layoutScale = juce::jmin (getWidth() / 1320.0f, getHeight() / 740.0f);
    look.popupScale = layoutScale;
    const float layoutOffsetX = (getWidth() - 1320.0f * layoutScale) * 0.5f;
    const float layoutOffsetY = (getHeight() - 740.0f * layoutScale) * 0.5f;
    const auto layoutTransform = juce::AffineTransform::scale (layoutScale)
                                      .translated (layoutOffsetX, layoutOffsetY);
    for (int i = 0; i < getNumChildComponents(); ++i)
    {
        auto* child = getChildComponent (i);
        if (child == addEffectOverlay.get() || dynamic_cast<juce::ResizableCornerComponent*> (child) != nullptr)
        {
            child->setTransform (juce::AffineTransform());
            continue;
        }
        child->setTransform (layoutTransform);
    }

    // Keep the native resize triangle glued to the real window corner.
    for (int i = 0; i < getNumChildComponents(); ++i)
        if (auto* corner = dynamic_cast<juce::ResizableCornerComponent*> (getChildComponent (i)))
            corner->setBounds (getWidth() - 18, getHeight() - 18, 18, 18);

    // Do not overwrite the last user size during construction or geometry-only relayout.
    if (! windowPersistenceReady || (lastWindowWidth == getWidth() && lastWindowHeight == getHeight())) return;
    lastWindowWidth = getWidth(); lastWindowHeight = getHeight();
    processor.editorWidth.store (getWidth()); processor.editorHeight.store (getHeight());
    juce::XmlElement window ("ULT_WINDOW");
    window.setAttribute ("width", getWidth());
    window.setAttribute ("height", getHeight());
    const auto windowFile = getLayoutFile().getSiblingFile ("window.xml");
    // Avoid rewriting the same file on every repaint/layout pass.
    const auto existingWindow = juce::XmlDocument::parse (windowFile);
    if (existingWindow == nullptr || ! existingWindow->hasTagName ("ULT_WINDOW")
        || existingWindow->getIntAttribute ("width") != getWidth()
        || existingWindow->getIntAttribute ("height") != getHeight())
        window.writeTo (windowFile);
}
