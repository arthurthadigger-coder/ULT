#pragma once
#include <JuceHeader.h>
#include "DSP/FaustOtt.h"
#include "DSP/OctaveShifter.h"
#include "DSP/UltReverb.h"
#include "ThirdParty/SnapTune/AutoTuneEngine.h"
#include "ThirdParty/Touchstone/refcomp/Engine.h"
#include <array>
#include <cstdint>
#include <atomic>
#include <vector>
#include <memory>
#include <map>
#include <string>


class UltAudioProcessor final : public juce::AudioProcessor, private juce::Timer
{
public:
    enum EffectId { Gate = 0, Autotune, OctaveShifterId, EQ, Resonance /* reserved for v0.5 state compatibility */, Compressor, DeEsser, Saturator, OTT, Modulation, NumEffects };
    static constexpr int maxEffects = NumEffects;

    UltAudioProcessor();
    ~UltAudioProcessor() override;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "ult"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 20.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}
    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;
    void restoreState (const void*, int, bool restoreWindow);
    void writeState (juce::MemoryBlock&, bool includeWindow);
    std::atomic<int> editorWidth { 0 }, editorHeight { 0 };
    bool isBusesLayoutSupported (const BusesLayout&) const override;

    juce::AudioProcessorValueTreeState apvts;
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();

    std::vector<int> getChainOrder() const;
    uint32_t getChainRevision() const noexcept { return chainRevision.load (std::memory_order_acquire); }
    void setChainOrder (const std::vector<int>& newOrder);
    bool isInChain (int id) const;
    void addEffectAt (int id, int position);
    void removeEffect (int id);
    bool isEffectEnabled (int id) const;
    float getEqResponseDb (float hz) const noexcept;
    void setEffectEnabled (int id, bool enabled);
    static const char* effectName (int id) noexcept;
    static const char* enabledParameterId (int id) noexcept;

    std::atomic<bool> visualizationActive { false };
    std::atomic<float> inputMeter { 0.0f }, outputMeter { 0.0f };
    std::atomic<float> gainReductionMeter { 0.0f };

    // Lock-free stage telemetry. Each slot follows its effect in the actual chain,
    // not the unprocessed plugin input. UI reads these atomics at its own rate.
    std::array<std::atomic<float>, NumEffects> stageInputPeak {};
    std::array<std::atomic<float>, NumEffects> stageOutputPeak {};
    std::array<std::atomic<float>, NumEffects> stageReductionDb {};
    std::atomic<bool> gateDetectorOpen { false };
    std::array<std::atomic<bool>, NumEffects> stagePresent {};

    // v0.9.12: single-producer / single-reader EQ post-stage audio tap.
    // Atomic samples avoid races with the editor; FFT is never run on the audio thread.
    static constexpr int eqSpectrumSize = 8192;
    std::array<std::atomic<float>, eqSpectrumSize> eqSpectrumSamples {};
    std::atomic<uint64_t> eqSpectrumWriteCount { 0 };
    std::atomic<double> eqSpectrumSampleRate { 44100.0 };

    // v0.9.15: corrected Autotune output tap. Pitch estimation runs on UI thread.
    static constexpr int tuneSpectrumSize = 2048;
    std::array<std::atomic<float>, tuneSpectrumSize> tuneOutputSamples {};
    std::atomic<uint64_t> tuneOutputCount { 0 };
    std::atomic<double> tuneOutputSampleRate { 44100.0 };

    // v0.9.14: stage-specific pre/post De-Esser FFT taps; audio thread only copies samples.
    std::array<std::atomic<float>, eqSpectrumSize> deInputSamples {}, deOutputSamples {};
    std::atomic<uint64_t> deInputCount { 0 }, deOutputCount { 0 };
    std::atomic<double> deSpectrumSampleRate { 44100.0 };




private:
    struct Biquad
    {
        float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0;
        float tb0 = 1, tb1 = 0, tb2 = 0, ta1 = 0, ta2 = 0;
        float z1 = 0, z2 = 0, smoothing = 1.0f;
        bool coefficientsInitialised = false;
        void reset() noexcept { z1 = z2 = 0.0f; coefficientsInitialised = false; }
        void setSmoothing (float coefficient) noexcept { smoothing = juce::jlimit (0.0f, 1.0f, coefficient); }
        float process (float x) noexcept
        {
            if (! coefficientsInitialised)
            {
                b0 = tb0; b1 = tb1; b2 = tb2; a1 = ta1; a2 = ta2;
                coefficientsInitialised = true;
            }
            else
            {
                b0 += smoothing * (tb0 - b0); b1 += smoothing * (tb1 - b1); b2 += smoothing * (tb2 - b2);
                a1 += smoothing * (ta1 - a1); a2 += smoothing * (ta2 - a2);
            }
            const float y = b0 * x + z1;
            z1 = b1 * x - a1 * y + z2;
            z2 = b2 * x - a2 * y;
            return y;
        }
        void setIdentity() noexcept { tb0 = 1.0f; tb1 = tb2 = ta1 = ta2 = 0.0f; }
        void setFirstOrderLowPass (double sr, float hz) noexcept;
        void setFirstOrderHighPass (double sr, float hz) noexcept;
        void setLowPass (double sr, float hz, float q) noexcept;
        void setHighPass (double sr, float hz, float q) noexcept;
        void setBandPass (double sr, float hz, float q) noexcept;
        void setPeak (double sr, float hz, float q, float gainDb) noexcept;
        void setLowShelf (double sr, float hz, float q, float gainDb) noexcept;
        void setHighShelf (double sr, float hz, float q, float gainDb) noexcept;
    };
    struct Envelope
    {
        float value = 0.0f;
        float process (float x, float attackCoeff, float releaseCoeff) noexcept
        {
            const float c = x > value ? attackCoeff : releaseCoeff;
            value += c * (x - value);
            return value;
        }
    };

    float pFast (const char* id) const noexcept;
    bool enabledParam (const char* id) const noexcept;
    void consumeChainOrder() noexcept;
    void updateLatencyAsync();
    void timerCallback() override;
    void updateEqIfNeeded() noexcept;
    void processGate (juce::AudioBuffer<float>& buffer) noexcept;
    void processAutotune (juce::AudioBuffer<float>& buffer) noexcept;
    void processOctaveShifter (juce::AudioBuffer<float>& buffer) noexcept;
    void processEq (juce::AudioBuffer<float>& buffer) noexcept;
    void processCompressor (juce::AudioBuffer<float>& buffer) noexcept;
    void processDeEsser (juce::AudioBuffer<float>& buffer) noexcept;
    void processSaturator (juce::AudioBuffer<float>& buffer) noexcept;
    void processOtt (juce::AudioBuffer<float>& buffer) noexcept;
    void processModulation (juce::AudioBuffer<float>& buffer) noexcept;
    void processDelaySend (juce::AudioBuffer<float>& buffer, double bpm) noexcept;
    void processReverbSend (juce::AudioBuffer<float>& buffer) noexcept;

    double sr = 44100.0;
    int maxBlock = 512;
    int preparedChannels = 2;
    std::array<std::atomic<int>, maxEffects> publishedOrder {};
    std::atomic<int> publishedCount { 0 };
    std::atomic<unsigned int> orderSequence { 0 };
    std::atomic<uint32_t> chainRevision { 0 };
    std::array<int, maxEffects> audioOrder {};
    int audioOrderCount = 0;

    std::array<std::array<std::array<Biquad, 4>, 5>, 2> eqFilters;
    std::array<int, 5> eqStageCounts { 1, 1, 1, 1, 1 };
    std::array<Envelope, 2> gateEnvelope;
    std::array<float, 2> gateGainEnvelope {};
    float gateBlockGrDb = 0.0f, deBlockGrDb = 0.0f;
    std::array<float, 2> deEssLowpass {}, deEssEnvelope {}, deEssGain { 1.0f, 1.0f };
    std::array<float, 2> reverbDuckEnvelope {};
    std::array<std::vector<float>, 2> delayBuffer;
    std::vector<float> reverbPowerCurve;
    std::array<int, 2> delayWrite {};
    juce::AudioBuffer<float> tempA, tempB, bypassDry, sendSource;
    OctaveShifter octave;
    UltReverb reverb;
    snaptune::AutoTuneEngine autotune;
    refcomp::Engine<float, refcomp::FastMath> fetCompressor;
    // Preallocated detector tap: never allocates in processBlock.
    std::vector<float> compressorGrTap;
    float compressorBlockGrDb = 0.0f;
    FaustOtt ott;

    void* airDeBess = nullptr;
    void* airDensity3 = nullptr;
    void* airDoubler = nullptr;
    void* airChorus = nullptr;

    std::map<std::string, std::atomic<float>*, std::less<>> parameterCache;
    std::array<float, 24> lastEqValues {};
    bool eqValuesInitialised = false;
    int lastReportedLatency = -1; // message-thread only
    std::atomic<int> engineLatencyRequested { -1 };
    std::atomic<bool> latencyUpdateRequested { true };
    // releaseResources() only marks the processor inactive; DSP handles stay
    // alive until the next prepareToPlay() or final processor destruction.
    std::atomic<bool> resourcesPrepared { false };
    std::array<std::atomic<float>, NumEffects> bypassMix {};
    float bypassCoeff = 0.0f;
    float delayPowerMix = 0.0f, delayPowerCoeff = 0.0f;
    float reverbPowerMix = 0.0f, reverbPowerCoeff = 0.0f;
    float modPowerMix = 0.0f, modPowerCoeff = 0.0f;
    std::atomic<bool> modPowerResetRequested { false };
    int modCurrentMode = 0, modPreviousMode = 0, modTransitionRemaining = 0, modTransitionTotal = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (UltAudioProcessor)
};
