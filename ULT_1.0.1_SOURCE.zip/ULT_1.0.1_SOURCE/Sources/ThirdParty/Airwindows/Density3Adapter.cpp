#include "Compat/audioeffectx.h"
#define createEffectInstance createEffectInstance_Density3
#include "Original/Density3/Density3.cpp"
#include "Original/Density3/Density3Proc.cpp"
#undef createEffectInstance
extern "C" void* ult_Density3_create (double sampleRate)
{
    auto* instance = new Density3 (nullptr);
    instance->setSampleRate ((float) sampleRate);
    return instance;
}
extern "C" void ult_Density3_destroy (void* handle) { delete static_cast<Density3*> (handle); }
extern "C" void ult_Density3_set (void* handle, int index, float value)
{
    if (handle != nullptr) static_cast<Density3*> (handle)->setParameter (index, value);
}
extern "C" void ult_Density3_process (void* handle, float* left, float* right, int samples)
{
    if (handle == nullptr || left == nullptr || right == nullptr || samples <= 0) return;
    float* inputs[2] = { left, right };
    float* outputs[2] = { left, right };
    static_cast<Density3*> (handle)->processReplacing (inputs, outputs, samples);
}
