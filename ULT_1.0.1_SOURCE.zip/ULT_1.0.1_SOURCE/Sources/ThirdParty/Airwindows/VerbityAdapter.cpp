#include "Compat/audioeffectx.h"
#define createEffectInstance createEffectInstance_Verbity
#include "Original/Verbity/Verbity.cpp"
#include "Original/Verbity/VerbityProc.cpp"
#undef createEffectInstance
extern "C" void* ult_Verbity_create (double sampleRate)
{
    auto* instance = new Verbity (nullptr);
    instance->setSampleRate ((float) sampleRate);
    return instance;
}
extern "C" void ult_Verbity_destroy (void* handle) { delete static_cast<Verbity*> (handle); }
extern "C" void ult_Verbity_set (void* handle, int index, float value)
{
    if (handle != nullptr) static_cast<Verbity*> (handle)->setParameter (index, value);
}
extern "C" void ult_Verbity_process (void* handle, float* left, float* right, int samples)
{
    if (handle == nullptr || left == nullptr || right == nullptr || samples <= 0) return;
    float* inputs[2] = { left, right };
    float* outputs[2] = { left, right };
    static_cast<Verbity*> (handle)->processReplacing (inputs, outputs, samples);
}
