#include "Compat/audioeffectx.h"
#define createEffectInstance createEffectInstance_StereoDoubler
#include "Original/StereoDoubler/StereoDoubler.cpp"
#include "Original/StereoDoubler/StereoDoublerProc.cpp"
#undef createEffectInstance
extern "C" void* ult_StereoDoubler_create (double sampleRate)
{
    auto* instance = new StereoDoubler (nullptr);
    instance->setSampleRate ((float) sampleRate);
    return instance;
}
extern "C" void ult_StereoDoubler_destroy (void* handle) { delete static_cast<StereoDoubler*> (handle); }
extern "C" void ult_StereoDoubler_set (void* handle, int index, float value)
{
    if (handle != nullptr) static_cast<StereoDoubler*> (handle)->setParameter (index, value);
}
extern "C" void ult_StereoDoubler_process (void* handle, float* left, float* right, int samples)
{
    if (handle == nullptr || left == nullptr || right == nullptr || samples <= 0) return;
    float* inputs[2] = { left, right };
    float* outputs[2] = { left, right };
    static_cast<StereoDoubler*> (handle)->processReplacing (inputs, outputs, samples);
}
