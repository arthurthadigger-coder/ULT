#pragma once
extern "C"
{
void* ult_DeBess_create (double); void ult_DeBess_destroy (void*); void ult_DeBess_set (void*, int, float); void ult_DeBess_process (void*, float*, float*, int);
void* ult_Density3_create (double); void ult_Density3_destroy (void*); void ult_Density3_set (void*, int, float); void ult_Density3_process (void*, float*, float*, int);
void* ult_StereoDoubler_create (double); void ult_StereoDoubler_destroy (void*); void ult_StereoDoubler_set (void*, int, float); void ult_StereoDoubler_process (void*, float*, float*, int);
void* ult_StereoChorus_create (double); void ult_StereoChorus_destroy (void*); void ult_StereoChorus_set (void*, int, float); void ult_StereoChorus_process (void*, float*, float*, int);
void* ult_Verbity_create (double); void ult_Verbity_destroy (void*); void ult_Verbity_set (void*, int, float); void ult_Verbity_process (void*, float*, float*, int);
}
