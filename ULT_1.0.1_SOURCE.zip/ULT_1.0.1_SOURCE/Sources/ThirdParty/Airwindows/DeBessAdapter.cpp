#include "Compat/audioeffectx.h"
#define createEffectInstance createEffectInstance_DeBess
#include "Original/DeBess/DeBess.cpp"
#include "Original/DeBess/DeBessProc.cpp"
#undef createEffectInstance
extern "C" void* ult_DeBess_create (double sampleRate)
{
    auto* instance = new DeBess (nullptr);
    instance->setSampleRate ((float) sampleRate);
    return instance;
}
extern "C" void ult_DeBess_destroy (void* handle) { delete static_cast<DeBess*> (handle); }
extern "C" void ult_DeBess_set (void* handle, int index, float value)
{
    if (handle != nullptr) static_cast<DeBess*> (handle)->setParameter (index, value);
}
extern "C" void ult_DeBess_process (void* handle, float* left, float* right, int samples)
{
    if (handle == nullptr || left == nullptr || right == nullptr || samples <= 0) return;
    float* inputs[2] = { left, right };
    float* outputs[2] = { left, right };
    static_cast<DeBess*> (handle)->processReplacing (inputs, outputs, samples);
}
