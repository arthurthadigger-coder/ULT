#include "Compat/audioeffectx.h"
#define createEffectInstance createEffectInstance_StereoChorus
#include "Original/StereoChorus/StereoChorus.cpp"
#include "Original/StereoChorus/StereoChorusProc.cpp"
#undef createEffectInstance
extern "C" void* ult_StereoChorus_create (double sampleRate)
{
    auto* instance = new StereoChorus (nullptr);
    instance->setSampleRate ((float) sampleRate);
    return instance;
}
extern "C" void ult_StereoChorus_destroy (void* handle) { delete static_cast<StereoChorus*> (handle); }
extern "C" void ult_StereoChorus_set (void* handle, int index, float value)
{
    if (handle != nullptr) static_cast<StereoChorus*> (handle)->setParameter (index, value);
}
extern "C" void ult_StereoChorus_process (void* handle, float* left, float* right, int samples)
{
    if (handle == nullptr || left == nullptr || right == nullptr || samples <= 0) return;
    float* inputs[2] = { left, right };
    float* outputs[2] = { left, right };
    static_cast<StereoChorus*> (handle)->processReplacing (inputs, outputs, samples);
}
