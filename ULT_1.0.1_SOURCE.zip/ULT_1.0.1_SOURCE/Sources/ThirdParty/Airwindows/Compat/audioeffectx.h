#pragma once
// Minimal compatibility surface for compiling Airwindows' original LinuxVST DSP
// classes without bundling the legacy VST2 SDK. ult calls only processReplacing.
#define __audioeffect__ 1
#include <cstdint>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <cstdlib>
using VstInt32 = int32_t;
using audioMasterCallback = void*;
constexpr int kVstMaxProgNameLen = 24;
constexpr int kVstMaxParamStrLen = 8;
constexpr int kVstMaxProductStrLen = 64;
constexpr int kVstMaxVendorStrLen = 64;
enum VstPlugCategory { kPlugCategEffect = 1 };
class AudioEffect { public: virtual ~AudioEffect() = default; };
class AudioEffectX : public AudioEffect
{
public:
    AudioEffectX (audioMasterCallback, int, int) {}
    void setNumInputs (int) noexcept {}
    void setNumOutputs (int) noexcept {}
    void setUniqueID (unsigned long) noexcept {}
    void canProcessReplacing() noexcept {}
    void canDoubleReplacing() noexcept {}
    void programsAreChunks (bool) noexcept {}
    double getSampleRate() const noexcept { return sampleRate; }
    void setSampleRate (float value) noexcept { sampleRate = value; }
private:
    double sampleRate = 44100.0;
};
inline void vst_strncpy (char* dst, const char* src, int n)
{
    if (dst != nullptr && src != nullptr && n > 0) { std::strncpy (dst, src, (size_t) n); dst[n - 1] = '\0'; }
}
inline void float2string (float value, char* dst, int n)
{
    if (dst != nullptr && n > 0) std::snprintf (dst, (size_t) n, "%.4f", value);
}
